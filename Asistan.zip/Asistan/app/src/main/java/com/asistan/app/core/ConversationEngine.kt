package com.asistan.app.core

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.asistan.app.notify.AppMessage
import com.asistan.app.phone.TURKISH
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

/**
 * Asistanın beyni: dinler (konuşmayı yazıya çevirir), Claude'a sorar, gerekirse
 * telefondaki araçları çalıştırır ve cevabı sesli okur.
 * Tüm public fonksiyonlar ana iş parçacığında çağrılmalıdır.
 */
class ConversationEngine(
    private val ctx: Context,
    private val scope: CoroutineScope,
    private val onIdle: () -> Unit
) {
    private val settings = AppSettings(ctx)
    private val claude = ClaudeClient(settings)
    private val tools = ToolExecutor(ctx)
    private val main = Handler(Looper.getMainLooper())

    private val history = ArrayList<JSONObject>()
    private var lastInteraction = 0L
    private var webSearchBroken = false

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var tone: ToneGenerator? = null
    private var job: Job? = null

    private val pendingActions = ArrayList<() -> Unit>()
    private var listenAfterSpeech = false
    private var utteranceCounter = 0
    private var currentUtterance = ""

    fun init() {
        tone = try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 60)
        } catch (e: Exception) {
            null
        }
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(TURKISH) ?: TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = true
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    AssistantState.info.value =
                        "Telefonda Türkçe ses paketi yok. Ayarlar > Metin okuma (TTS) bölümünden Türkçe sesi indir."
                }
                tts?.setSpeechRate(1.05f)
            } else {
                AssistantState.info.value = "Metin okuma motoru başlatılamadı."
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                main.post { if (utteranceId == currentUtterance) onSpeechDone() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post { if (utteranceId == currentUtterance) onSpeechDone() }
            }
        })
    }

    val isBusy: Boolean
        get() = AssistantState.status.value.let {
            it == Status.LISTENING || it == Status.THINKING || it == Status.SPEAKING
        }

    // ------------------------------------------------------------------
    // Dinleme
    // ------------------------------------------------------------------

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            AssistantState.info.value =
                "Bu telefonda konuşma tanıma servisi yok. Google uygulamasını yükleyip güncelleyin."
            finishIdle()
            return
        }
        stopSpeakingSilently()
        job?.cancel()
        recognizer?.destroy()

        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                AssistantState.status.value = Status.LISTENING
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                AssistantState.level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                AssistantState.level.value = 0f
            }

            override fun onError(error: Int) {
                AssistantState.level.value = 0f
                AssistantState.partial.value = ""
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> Unit // Kullanıcı bir şey demedi
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        AssistantState.info.value = "Mikrofon izni gerekli."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        AssistantState.info.value = "Konuşma tanıma için internet bağlantısı gerekli."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                        AssistantState.info.value = "Mikrofon meşgul, tekrar dene."
                    else -> Log.w(TAG, "SpeechRecognizer hata kodu: $error")
                }
                finishIdle()
            }

            override fun onResults(results: Bundle?) {
                AssistantState.level.value = 0f
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                AssistantState.partial.value = ""
                if (text.isBlank()) finishIdle() else handleUserText(text)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!p.isNullOrBlank()) AssistantState.partial.value = p
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        AssistantState.info.value = null
        AssistantState.status.value = Status.LISTENING
        AssistantState.partial.value = ""
        try {
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        } catch (_: Exception) {
        }
        r.startListening(intent)
    }

    /** Klavyeyle yazılan mesajlar için. */
    fun submitText(text: String) {
        if (text.isBlank()) return
        stopSpeakingSilently()
        recognizer?.cancel()
        job?.cancel()
        handleUserText(text.trim())
    }

    /** Ekrandaki küreye dokununca: ne yapıyorsa durdur. */
    fun interrupt() {
        job?.cancel()
        recognizer?.cancel()
        stopSpeakingSilently()
        pendingActions.clear()
        finishIdle()
    }

    // ------------------------------------------------------------------
    // Claude ile konuşma
    // ------------------------------------------------------------------

    private fun handleUserText(text: String) {
        AssistantState.add(ChatLine(fromUser = true, text = text))
        val now = System.currentTimeMillis()
        if (now - lastInteraction > 5 * 60_000) history.clear() // 5 dk sessizlikten sonra yeni sohbet
        lastInteraction = now
        trimHistory()

        val mark = history.size
        history.add(JSONObject().put("role", "user").put("content", text))
        pendingActions.clear()
        AssistantState.status.value = Status.THINKING

        job = scope.launch {
            try {
                val reply = withContext(Dispatchers.IO) { agentLoop() }
                lastInteraction = System.currentTimeMillis()
                AssistantState.add(ChatLine(fromUser = false, text = reply))
                speak(reply, listenAfter = reply.trim().endsWith("?"))
            } catch (e: CancellationException) {
                rollback(mark)
                throw e
            } catch (e: ClaudeException) {
                rollback(mark)
                val msg = when (e.code) {
                    -1 -> e.message ?: "API anahtarı eksik."
                    401 -> "API anahtarı geçersiz görünüyor. Ayarlardan kontrol eder misin?"
                    402, 403 -> "Claude hesabında sorun var, kredi bakiyeni kontrol et."
                    429 -> "Çok fazla istek gönderildi, biraz sonra tekrar dene."
                    529, 500, 503 -> "Claude şu an yoğun, birazdan tekrar dene."
                    else -> "Bir hata oluştu: ${e.message}"
                }
                AssistantState.info.value = e.message
                AssistantState.add(ChatLine(fromUser = false, text = msg))
                speak(msg, listenAfter = false)
            } catch (e: IOException) {
                rollback(mark)
                val msg = "İnternet bağlantısı yok gibi görünüyor."
                AssistantState.add(ChatLine(fromUser = false, text = msg))
                speak(msg, listenAfter = false)
            } catch (e: Exception) {
                rollback(mark)
                Log.e(TAG, "Beklenmeyen hata", e)
                val msg = "Beklenmeyen bir hata oldu."
                AssistantState.info.value = e.toString()
                AssistantState.add(ChatLine(fromUser = false, text = msg))
                speak(msg, listenAfter = false)
            }
        }
    }

    /** Claude'a sorar; araç isterse çalıştırır ve sonucu geri verir. Cevap metni hazır olunca döner. */
    private fun agentLoop(): String {
        repeat(8) {
            val resp = callClaude()
            val content = resp.getJSONArray("content")
            history.add(JSONObject().put("role", "assistant").put("content", content))

            when (resp.optString("stop_reason")) {
                "tool_use" -> {
                    val results = JSONArray()
                    for (i in 0 until content.length()) {
                        val block = content.getJSONObject(i)
                        if (block.optString("type") != "tool_use") continue
                        val name = block.getString("name")
                        val input = block.optJSONObject("input") ?: JSONObject()
                        Log.d(TAG, "Araç: $name $input")
                        val outcome = tools.execute(name, input)
                        outcome.afterSpeech?.let { action -> main.post { pendingActions.add(action) } }
                        val r = JSONObject()
                            .put("type", "tool_result")
                            .put("tool_use_id", block.getString("id"))
                            .put("content", outcome.content)
                        if (outcome.isError) r.put("is_error", true)
                        results.put(r)
                    }
                    history.add(JSONObject().put("role", "user").put("content", results))
                }
                "pause_turn" -> Unit // Sunucu tarafı araç (web araması) devam ediyor; tekrar sor.
                else -> {
                    val text = textOf(content)
                    return text.ifBlank { "Tamam." }
                }
            }
        }
        return "Bu isteği tamamlayamadım, tekrar dener misin?"
    }

    private fun callClaude(): JSONObject {
        val useWeb = settings.webSearch && !webSearchBroken
        return try {
            claude.createMessage(systemPrompt(), JSONArray(history), tools.definitions(useWeb))
        } catch (e: ClaudeException) {
            // Web araması hesabında kapalıysa, onsuz tekrar dene.
            if (useWeb && e.code == 400 && (e.message ?: "").contains("web_search", ignoreCase = true)) {
                webSearchBroken = true
                claude.createMessage(systemPrompt(), JSONArray(history), tools.definitions(false))
            } else throw e
        }
    }

    private fun textOf(content: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        return sb.toString().trim()
    }

    private fun rollback(mark: Int) {
        while (history.size > mark) history.removeAt(history.size - 1)
    }

    /** Geçmişi kısa tut; her zaman düz bir kullanıcı mesajıyla başlasın. */
    private fun trimHistory() {
        while (history.size > 30 || (history.isNotEmpty() && !isPlainUser(history[0]))) {
            history.removeAt(0)
        }
    }

    private fun isPlainUser(m: JSONObject) =
        m.optString("role") == "user" && m.opt("content") is String

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("d MMMM yyyy EEEE, HH:mm", TURKISH).format(Date())
        val tz = TimeZone.getDefault().id
        val name = settings.userName.ifBlank { null }
        val city = settings.city.ifBlank { null }
        return buildString {
            appendLine("Sen \"Asistan\" adında, kullanıcının Android telefonunda çalışan Türkçe sesli bir asistansın (Siri gibi).")
            appendLine("Kullanıcı seninle konuşarak iletişim kuruyor ve cevapların sesli okunuyor.")
            appendLine()
            appendLine("Kurallar:")
            appendLine("- Her zaman Türkçe, sıcak ve doğal konuş. Kısa tut: genellikle 1-3 cümle.")
            appendLine("- Markdown, madde işareti, emoji, link veya tablo KULLANMA. Sadece sesli okunacak düz metin yaz.")
            appendLine("- Telefonla ilgili işler için araçları kullan. Bir aracı çalıştırmadan bir şeyi yaptığını söyleme.")
            appendLine("- Arama: make_call kullan. Birden fazla eşleşme olursa kime ait olduğunu sor.")
            appendLine("- Mesaj gönderme (SMS veya WhatsApp gibi uygulama cevabı): önce kime ve ne yazılacağını tekrar et ve 'Göndereyim mi?' diye sor. Kullanıcı açıkça evet derse user_confirmed=true ile gönder.")
            appendLine("- \"Mesajlarımı oku\" denirse hem read_app_messages hem read_sms kullanabilirsin; çok mesaj varsa kısaca özetle.")
            appendLine("- Kişi adlarındaki Türkçe ekleri araçlara verirken çıkar (\"Ahmet'i ara\" -> \"Ahmet\", \"annemi ara\" -> \"annem\").")
            appendLine("- Kullanıcıdan cevap bekliyorsan cümleni soru işaretiyle bitir; beklemiyorsan soru işaretiyle bitirme.")
            appendLine("- Güncel bilgiler (hava durumu, haberler, döviz, maç sonuçları) için web_search aracını kullan (varsa). Hava durumu sorulursa ve şehir bilinmiyorsa şehri sor.")
            appendLine("- Sayıları, saatleri ve tarihleri kolay okunur şekilde yaz.")
            appendLine()
            appendLine("Şu an: $now (saat dilimi: $tz).")
            if (name != null) appendLine("Kullanıcının adı: $name.")
            if (city != null) appendLine("Kullanıcının yaşadığı şehir: $city.")
        }
    }

    // ------------------------------------------------------------------
    // Gelen mesajı sesli duyurma
    // ------------------------------------------------------------------

    fun announce(m: AppMessage) {
        if (isBusy) return
        val where = m.conversation?.let { " $it grubunda" } ?: ""
        val canReply = m.replyAction != null
        val text = "${m.sender}$where ${m.appName} üzerinden yazdı: ${m.text.take(300)}" +
                if (canReply) ". Cevap vermek ister misin?" else "."

        trimHistory()
        if (history.isNotEmpty() && history.last().optString("role") == "user") history.clear()
        history.add(
            JSONObject().put("role", "user").put(
                "content",
                "(Sistem: yeni mesaj bildirimi geldi. id=${m.id}, uygulama=${m.appName}, gönderen=${m.sender}, metin=\"${m.text}\". Bunu kullanıcıya duyur.)"
            )
        )
        history.add(JSONObject().put("role", "assistant").put("content", text))
        lastInteraction = System.currentTimeMillis()
        AssistantState.add(ChatLine(fromUser = false, text = text))
        speak(text, listenAfter = canReply)
    }

    // ------------------------------------------------------------------
    // Konuşma (TTS)
    // ------------------------------------------------------------------

    private fun speak(text: String, listenAfter: Boolean) {
        listenAfterSpeech = listenAfter
        val t = tts
        if (t == null || !ttsReady) {
            onSpeechDone()
            return
        }
        AssistantState.status.value = Status.SPEAKING
        currentUtterance = "utt-${++utteranceCounter}"
        val params = Bundle()
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f)
        t.speak(cleanForSpeech(text), TextToSpeech.QUEUE_FLUSH, params, currentUtterance)
    }

    private fun onSpeechDone() {
        val actions = ArrayList(pendingActions)
        pendingActions.clear()
        var startedSomething = false
        for (a in actions) {
            try {
                a()
                startedSomething = true
            } catch (e: SecurityException) {
                AssistantState.info.value = "İzin eksik: ${e.message}"
            } catch (e: Exception) {
                AssistantState.info.value = "İşlem yapılamadı: ${e.message}"
            }
        }
        // Arama başlattıysak veya uygulama açtıysak tekrar dinlemeye geçme.
        if (listenAfterSpeech && !startedSomething) {
            main.postDelayed({ startListening() }, 250)
        } else {
            finishIdle()
        }
    }

    private fun stopSpeakingSilently() {
        currentUtterance = ""
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
    }

    private fun cleanForSpeech(s: String): String = s
        .replace(Regex("https?://\\S+"), "")
        .replace(Regex("[*#_`>|]"), "")
        .replace(Regex("\\[(.*?)]\\(.*?\\)"), "$1")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun finishIdle() {
        AssistantState.level.value = 0f
        AssistantState.partial.value = ""
        AssistantState.status.value = Status.IDLE
        onIdle()
    }

    fun shutdown() {
        job?.cancel()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        tone?.release()
        tone = null
    }

    companion object {
        private const val TAG = "Engine"
    }
}
