package com.asistan.app.core

import android.Manifest
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.asistan.app.notify.NotificationStore
import com.asistan.app.phone.Contacts
import com.asistan.app.phone.PhoneActions
import com.asistan.app.phone.Sms
import com.asistan.app.phone.TextUtil
import org.json.JSONArray
import org.json.JSONObject

/** Bir aracın sonucu. [afterSpeech], asistan cevabını okuduktan SONRA çalışır (ör. aramayı başlatmak). */
data class ToolOutcome(
    val content: String,
    val isError: Boolean = false,
    val afterSpeech: (() -> Unit)? = null
)

/** Claude'un telefonda kullanabileceği araçlar (arama, SMS, bildirim mesajları, alarm, uygulama açma). */
class ToolExecutor(private val ctx: Context) {

    // ---------- Araç tanımları (Claude'a gönderilir) ----------

    fun definitions(webSearch: Boolean): JSONArray {
        val arr = JSONArray()
        arr.put(
            tool(
                "find_contact",
                "Rehberde kişi arar ve telefon numaralarını döndürür. Ada gelen Türkçe ekleri çıkar (\"Ahmet'in\" -> \"Ahmet\").",
                props("query" to str("Kişinin adı veya adın bir kısmı")),
                listOf("query")
            )
        )
        arr.put(
            tool(
                "make_call",
                "Telefon araması başlatır. Rehberdeki bir kişi adı veya doğrudan bir telefon numarası alır. " +
                        "Birden fazla eşleşme olursa seçenekleri döndürür; kullanıcıya hangisi olduğunu sor ve numarayla tekrar çağır.",
                props("contact_or_number" to str("Kişi adı (ekler çıkarılmış) veya telefon numarası")),
                listOf("contact_or_number")
            )
        )
        arr.put(
            tool(
                "read_sms",
                "Gelen kutusundaki SMS mesajlarını okur (en yeniden eskiye).",
                props(
                    "count" to int("Kaç mesaj (varsayılan 5, en fazla 20)"),
                    "unread_only" to bool("Sadece okunmamışlar"),
                    "from" to str("Sadece bu kişiden/numaradan gelenler (isteğe bağlı)")
                ),
                emptyList()
            )
        )
        arr.put(
            tool(
                "send_sms",
                "SMS gönderir. ÖNCE alıcıyı ve metni kullanıcıya okuyup onay al; yalnızca kullanıcı açıkça onaylarsa user_confirmed=true ile çağır.",
                props(
                    "recipient" to str("Kişi adı veya telefon numarası"),
                    "message" to str("Gönderilecek metin"),
                    "user_confirmed" to bool("Kullanıcı bu metni göndermeyi açıkça onayladı mı?")
                ),
                listOf("recipient", "message", "user_confirmed")
            )
        )
        arr.put(
            tool(
                "read_app_messages",
                "WhatsApp, Telegram, Instagram, Messenger, BiP vb. uygulamalardan bildirim olarak gelen son mesajları okur. " +
                        "Her mesajın bir id'si vardır; cevap vermek için reply_app_message ile bu id kullanılır.",
                props(
                    "app" to str("Uygulama adı filtresi, ör. WhatsApp (isteğe bağlı)"),
                    "count" to int("Kaç mesaj (varsayılan 8)")
                ),
                emptyList()
            )
        )
        arr.put(
            tool(
                "reply_app_message",
                "Bildirimden gelen bir mesaja (ör. WhatsApp) doğrudan cevap yazar. ÖNCE metni kullanıcıya okuyup onay al.",
                props(
                    "message_id" to int("read_app_messages ile gelen mesaj id'si"),
                    "message" to str("Cevap metni"),
                    "user_confirmed" to bool("Kullanıcı açıkça onayladı mı?")
                ),
                listOf("message_id", "message", "user_confirmed")
            )
        )
        arr.put(
            tool(
                "set_alarm",
                "Saat uygulamasında alarm kurar.",
                props(
                    "hour" to int("Saat (0-23)"),
                    "minute" to int("Dakika (0-59)"),
                    "label" to str("Alarm etiketi (isteğe bağlı)")
                ),
                listOf("hour", "minute")
            )
        )
        arr.put(
            tool(
                "set_timer",
                "Geri sayım zamanlayıcısı kurar.",
                props(
                    "seconds" to int("Süre (saniye)"),
                    "label" to str("Etiket (isteğe bağlı)")
                ),
                listOf("seconds")
            )
        )
        arr.put(
            tool(
                "open_app",
                "Telefonda yüklü bir uygulamayı açar (ör. YouTube, Spotify, Kamera).",
                props("app_name" to str("Uygulamanın adı")),
                listOf("app_name")
            )
        )
        if (webSearch) {
            arr.put(
                JSONObject()
                    .put("type", "web_search_20250305")
                    .put("name", "web_search")
                    .put("max_uses", 3)
            )
        }
        return arr
    }

    // ---------- Araçları çalıştırma ----------

    fun execute(name: String, input: JSONObject): ToolOutcome = try {
        when (name) {
            "find_contact" -> findContact(input)
            "make_call" -> makeCall(input)
            "read_sms" -> readSms(input)
            "send_sms" -> sendSms(input)
            "read_app_messages" -> readAppMessages(input)
            "reply_app_message" -> replyAppMessage(input)
            "set_alarm" -> setAlarm(input)
            "set_timer" -> setTimer(input)
            "open_app" -> openApp(input)
            else -> ToolOutcome("Bilinmeyen araç: $name", isError = true)
        }
    } catch (e: SecurityException) {
        ToolOutcome(
            "Gerekli izin verilmemiş (${e.message}). Kullanıcıya Asistan ayarlarındaki İzinler bölümünden izni vermesini söyle.",
            isError = true
        )
    } catch (e: Exception) {
        ToolOutcome("İşlem başarısız: ${e.message ?: e.javaClass.simpleName}", isError = true)
    }

    private fun missing(perm: String, what: String): ToolOutcome? =
        if (ContextCompat.checkSelfPermission(ctx, perm) != PackageManager.PERMISSION_GRANTED) {
            ToolOutcome(
                "$what izni verilmemiş. Kullanıcıya Asistan uygulamasında Ayarlar > İzinler bölümünden bu izni vermesini söyle.",
                isError = true
            )
        } else null

    private fun findContact(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.READ_CONTACTS, "Rehber")?.let { return it }
        val q = input.optString("query")
        val found = Contacts.search(ctx, q)
        if (found.isEmpty()) return ToolOutcome("Rehberde \"$q\" ile eşleşen kişi bulunamadı.")
        return ToolOutcome(found.joinToString("\n") { "${it.name} – ${it.label}: ${it.number}" })
    }

    /** Ad veya numarayı tek bir numaraya çevirir. Belirsizse kullanıcıya sorulacak metni döndürür. */
    private fun resolveNumber(target: String): Pair<Pair<String, String>?, ToolOutcome?> {
        if (TextUtil.looksLikeNumber(target)) {
            val name = Contacts.nameForNumber(ctx, target) ?: target
            return Pair(Pair(name, target), null)
        }
        missing(Manifest.permission.READ_CONTACTS, "Rehber")?.let { return Pair(null, it) }
        val found = Contacts.search(ctx, target)
        if (found.isEmpty()) {
            return Pair(null, ToolOutcome("Rehberde \"$target\" bulunamadı. Kullanıcıya adı tekrar sor.", isError = true))
        }
        val distinct = found.distinctBy { TextUtil.digits(it.number).takeLast(10) }
        if (distinct.size == 1) return Pair(Pair(distinct[0].name, distinct[0].number), null)
        val options = distinct.joinToString("\n") { "${it.name} – ${it.label}: ${it.number}" }
        return Pair(
            null,
            ToolOutcome(
                "Birden fazla eşleşme var, kullanıcıya hangisi olduğunu sor (numaraları okumak yerine ad ve etiketi söyle):\n$options"
            )
        )
    }

    private fun makeCall(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.CALL_PHONE, "Telefon araması")?.let { return it }
        val (resolved, problem) = resolveNumber(input.optString("contact_or_number"))
        if (resolved == null) return problem!!
        val (name, number) = resolved
        return ToolOutcome(
            "Arama hazır: $name ($number). Cevabını okuduktan sonra arama otomatik başlayacak. Kullanıcıya kısaca kimi aradığını söyle.",
            afterSpeech = { PhoneActions.placeCall(ctx, number) }
        )
    }

    private fun readSms(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.READ_SMS, "SMS okuma")?.let { return it }
        val count = input.optInt("count", 5).coerceIn(1, 20)
        val unread = input.optBoolean("unread_only", false)
        val from = input.optString("from", "").ifBlank { null }
        val list = Sms.inbox(ctx, count, unread, from)
        if (list.isEmpty()) {
            return ToolOutcome(if (unread) "Okunmamış SMS yok." else "Eşleşen SMS bulunamadı.")
        }
        return ToolOutcome(list.joinToString("\n") {
            val who = it.name ?: it.address
            val r = if (it.read) "" else " [okunmamış]"
            "${TextUtil.friendlyTime(it.date)} – $who$r: ${it.body.take(500)}"
        })
    }

    private fun sendSms(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.SEND_SMS, "SMS gönderme")?.let { return it }
        val text = input.optString("message").trim()
        if (text.isEmpty()) return ToolOutcome("Mesaj metni boş.", isError = true)
        if (!input.optBoolean("user_confirmed", false)) {
            return ToolOutcome(
                "Gönderilmedi: önce alıcıyı ve metni kullanıcıya oku, 'Göndereyim mi?' diye sor ve onay al.",
                isError = true
            )
        }
        val (resolved, problem) = resolveNumber(input.optString("recipient"))
        if (resolved == null) return problem!!
        Sms.send(ctx, resolved.second, text)
        return ToolOutcome("SMS gönderildi: ${resolved.first} kişisine.")
    }

    private fun readAppMessages(input: JSONObject): ToolOutcome {
        if (!NotificationStore.listenerConnected) {
            return ToolOutcome(
                "Bildirim erişimi kapalı. Kullanıcıya Asistan > Ayarlar > İzinler bölümünden 'Bildirim erişimi'ni açmasını söyle.",
                isError = true
            )
        }
        val app = input.optString("app", "").ifBlank { null }
        val count = input.optInt("count", 8).coerceIn(1, 20)
        val list = NotificationStore.recent(app, count)
        if (list.isEmpty()) {
            return ToolOutcome("Asistan açıldığından beri ${app ?: "uygulamalardan"} yeni mesaj bildirimi gelmedi.")
        }
        return ToolOutcome(list.joinToString("\n") {
            val group = it.conversation?.let { g -> " ($g grubunda)" } ?: ""
            val canReply = if (it.replyAction != null) "" else " [cevap verilemez]"
            "id=${it.id} | ${it.appName} | ${TextUtil.friendlyTime(it.time)} | ${it.sender}$group$canReply: ${it.text.take(500)}"
        })
    }

    private fun replyAppMessage(input: JSONObject): ToolOutcome {
        val msg = NotificationStore.get(input.optInt("message_id", -1))
            ?: return ToolOutcome("Bu id ile mesaj bulunamadı. Önce read_app_messages çağır.", isError = true)
        val text = input.optString("message").trim()
        if (text.isEmpty()) return ToolOutcome("Cevap metni boş.", isError = true)
        if (!input.optBoolean("user_confirmed", false)) {
            return ToolOutcome("Gönderilmedi: önce metni kullanıcıya oku ve onay al.", isError = true)
        }
        val action = msg.replyAction
            ?: return ToolOutcome("Bu bildirimde hızlı cevap özelliği yok. Kullanıcı uygulamayı açarak cevaplayabilir.", isError = true)
        val inputs = action.remoteInputs
            ?: return ToolOutcome("Bu bildirime cevap verilemiyor.", isError = true)
        val results = Bundle()
        for (ri in inputs) results.putCharSequence(ri.resultKey, text)
        val fillIn = Intent()
        RemoteInput.addResultsToIntent(inputs, fillIn, results)
        action.actionIntent.send(ctx, 0, fillIn)
        return ToolOutcome("${msg.appName} üzerinden ${msg.sender} kişisine cevap gönderildi.")
    }

    private fun setAlarm(input: JSONObject): ToolOutcome {
        val h = input.optInt("hour", -1)
        val m = input.optInt("minute", 0)
        if (h !in 0..23 || m !in 0..59) return ToolOutcome("Geçersiz saat.", isError = true)
        PhoneActions.setAlarm(ctx, h, m, input.optString("label", "").ifBlank { null })
        return ToolOutcome("Alarm %02d:%02d için kuruldu.".format(h, m))
    }

    private fun setTimer(input: JSONObject): ToolOutcome {
        val s = input.optInt("seconds", 0)
        if (s <= 0 || s > 24 * 3600) return ToolOutcome("Geçersiz süre.", isError = true)
        PhoneActions.setTimer(ctx, s, input.optString("label", "").ifBlank { null })
        return ToolOutcome("$s saniyelik zamanlayıcı kuruldu.")
    }

    private fun openApp(input: JSONObject): ToolOutcome {
        val q = input.optString("app_name")
        val apps = PhoneActions.findApps(ctx, q)
        if (apps.isEmpty()) return ToolOutcome("\"$q\" adında yüklü uygulama bulunamadı.", isError = true)
        if (apps.size > 1 && TextUtil.normalize(apps[0].label) != TextUtil.normalize(q)) {
            return ToolOutcome("Birden fazla uygulama eşleşti: ${apps.joinToString { it.label }}. Hangisi olduğunu sor.")
        }
        val app = apps[0]
        return ToolOutcome(
            "${app.label} açılacak.",
            afterSpeech = { PhoneActions.launchApp(ctx, app.packageName) }
        )
    }

    // ---------- JSON yardımcıları ----------

    private fun tool(name: String, desc: String, properties: JSONObject, required: List<String>) =
        JSONObject()
            .put("name", name)
            .put("description", desc)
            .put(
                "input_schema",
                JSONObject()
                    .put("type", "object")
                    .put("properties", properties)
                    .put("required", JSONArray(required))
            )

    private fun props(vararg p: Pair<String, JSONObject>): JSONObject {
        val o = JSONObject()
        p.forEach { o.put(it.first, it.second) }
        return o
    }

    private fun str(d: String) = JSONObject().put("type", "string").put("description", d)
    private fun int(d: String) = JSONObject().put("type", "integer").put("description", d)
    private fun bool(d: String) = JSONObject().put("type", "boolean").put("description", d)
}
