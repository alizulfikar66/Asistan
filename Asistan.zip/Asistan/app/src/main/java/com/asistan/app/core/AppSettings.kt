package com.asistan.app.core

import android.content.Context

/** Kullanıcı ayarları. Telefonun içinde, yalnızca bu uygulamanın erişebildiği yerde saklanır. */
class AppSettings(context: Context) {

    private val p = context.applicationContext
        .getSharedPreferences("asistan_settings", Context.MODE_PRIVATE)

    var apiKey: String
        get() = p.getString("api_key", "") ?: ""
        set(v) = p.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = p.getString("model", MODEL_FAST) ?: MODEL_FAST
        set(v) = p.edit().putString("model", v).apply()

    var userName: String
        get() = p.getString("user_name", "") ?: ""
        set(v) = p.edit().putString("user_name", v).apply()

    var city: String
        get() = p.getString("city", "") ?: ""
        set(v) = p.edit().putString("city", v).apply()

    var wakeWordEnabled: Boolean
        get() = p.getBoolean("wake_enabled", false)
        set(v) = p.edit().putBoolean("wake_enabled", v).apply()

    var wakeWord: String
        get() = p.getString("wake_word", "asistan") ?: "asistan"
        set(v) = p.edit().putString("wake_word", v).apply()

    var announceMessages: Boolean
        get() = p.getBoolean("announce", false)
        set(v) = p.edit().putBoolean("announce", v).apply()

    var webSearch: Boolean
        get() = p.getBoolean("web_search", true)
        set(v) = p.edit().putBoolean("web_search", v).apply()

    companion object {
        const val MODEL_FAST = "claude-haiku-5-5"
        const val MODEL_SMART = "claude-sonnet-5-5"
    }
}
