package com.asistan.app

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.asistan.app.core.AppSettings
import com.asistan.app.core.AssistantService
import com.asistan.app.core.AssistantState
import com.asistan.app.core.Status
import com.asistan.app.ui.AsistanTheme
import com.asistan.app.ui.MainScreen
import com.asistan.app.ui.Perms
import com.asistan.app.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    private lateinit var settings: AppSettings
    private var showSettings by mutableStateOf(false)
    private var hasKey by mutableStateOf(false)
    private var listenWhenReady = false

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            AssistantService.send(this, AssistantService.ACTION_START)
            if (listenWhenReady) AssistantService.send(this, AssistantService.ACTION_LISTEN)
        } else {
            AssistantState.info.value = "Seni duyabilmem için mikrofon izni gerekli."
        }
        listenWhenReady = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        settings = AppSettings(this)
        hasKey = settings.apiKey.isNotBlank()

        // İlk açılışta anahtar yoksa doğrudan ayarlara götür
        if (savedInstanceState == null && !hasKey) showSettings = true

        setContent {
            AsistanTheme {
                if (showSettings) {
                    SettingsScreen(settings) {
                        showSettings = false
                        hasKey = settings.apiKey.isNotBlank()
                    }
                } else {
                    MainScreen(
                        hasApiKey = hasKey,
                        onOrbTap = ::onOrbTap,
                        onSendText = { text -> withMic { AssistantService.send(this, AssistantService.ACTION_TEXT, text) } },
                        onOpenSettings = { showSettings = true }
                    )
                }
            }
        }
        handleAssistIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleAssistIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        AssistantState.uiVisible.value = true
        hasKey = settings.apiKey.isNotBlank()
        if (Perms.has(this, Manifest.permission.RECORD_AUDIO)) {
            AssistantService.send(this, AssistantService.ACTION_START)
        }
    }

    override fun onStop() {
        AssistantState.uiVisible.value = false
        super.onStop()
    }

    private fun handleAssistIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_ASSIST) {
            withMic { AssistantService.send(this, AssistantService.ACTION_LISTEN) }
        }
    }

    private fun onOrbTap() {
        when (AssistantState.status.value) {
            Status.LISTENING, Status.THINKING, Status.SPEAKING ->
                AssistantService.send(this, AssistantService.ACTION_INTERRUPT)
            else -> withMic { AssistantService.send(this, AssistantService.ACTION_LISTEN) }
        }
    }

    /** Mikrofon izni varsa işi yap, yoksa önce izni iste. */
    private fun withMic(action: () -> Unit) {
        if (Perms.has(this, Manifest.permission.RECORD_AUDIO)) {
            action()
        } else {
            listenWhenReady = true
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
}
