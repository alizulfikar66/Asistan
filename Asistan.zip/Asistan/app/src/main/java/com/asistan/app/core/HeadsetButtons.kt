package com.asistan.app.core

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent

/**
 * Kulaklık tuşu (kablolu kulaklıktaki tek tuş veya Bluetooth kulaklıktaki oynat/duraklat)
 * ile asistanı çağırma.
 *
 * Android medya tuşlarını en son ses çalan uygulamaya verir. Bu yüzden kulaklık takılınca ve
 * her konuşmadan sonra (müzik çalmıyorsa) çeyrek saniyelik sessiz bir ses çalarak tuşu
 * asistana alırız. Müzik uygulaması çalmaya başlarsa tuş yine onun olur (müziği durdurup
 * başlatırsın) – bu durumda "Asistan" diyerek veya küreye dokunarak konuşabilirsin.
 */
class HeadsetButtons(
    private val ctx: Context,
    private val onPress: () -> Unit
) {
    private val am = ctx.getSystemService(AudioManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private val settings = AppSettings(ctx)
    private var session: MediaSession? = null
    private var lastPress = 0L

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            if (addedDevices?.any { it.type in AudioRouter.HEADSET_TYPES } == true) {
                // Bluetooth bağlantısı otursun diye biraz bekle
                main.postDelayed({ claim() }, 1500)
            }
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {}
    }

    fun start() {
        if (session != null) return
        try {
            val s = MediaSession(ctx, "Asistan")
            s.setCallback(object : MediaSession.Callback() {
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    val ev: KeyEvent? = if (Build.VERSION.SDK_INT >= 33) {
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
                    }
                    if (ev == null || ev.keyCode !in KEYS) return super.onMediaButtonEvent(mediaButtonIntent)
                    if (!settings.headsetButton) return super.onMediaButtonEvent(mediaButtonIntent)
                    if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                        val now = System.currentTimeMillis()
                        if (now - lastPress > 700) {
                            lastPress = now
                            main.post { onPress() }
                        }
                    }
                    return true
                }
            })
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                                PlaybackState.ACTION_PLAY_PAUSE
                    )
                    .setState(PlaybackState.STATE_PAUSED, 0, 1f)
                    .build()
            )
            s.isActive = true
            session = s
            am.registerAudioDeviceCallback(deviceCallback, main)
        } catch (e: Exception) {
            Log.w(TAG, "Kulaklık tuşu dinlenemiyor", e)
        }
        claim()
    }

    /** Müzik çalmıyorsa ve kulaklık takılıysa medya tuşunu asistana al. */
    fun claim() {
        if (session == null || !settings.headsetButton) return
        if (am.isMusicActive) return
        val headset = try {
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in AudioRouter.HEADSET_TYPES }
        } catch (_: Exception) {
            false
        }
        if (!headset) return
        try {
            val rate = 16000
            val samples = rate / 4
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(samples * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(ShortArray(samples), 0, samples)
            track.play()
            main.postDelayed({
                try {
                    track.stop()
                } catch (_: Exception) {
                }
                track.release()
            }, 500)
        } catch (e: Exception) {
            Log.w(TAG, "Sessiz ses çalınamadı", e)
        }
    }

    fun release() {
        try {
            am.unregisterAudioDeviceCallback(deviceCallback)
        } catch (_: Exception) {
        }
        session?.let {
            it.isActive = false
            it.release()
        }
        session = null
    }

    companion object {
        private const val TAG = "HeadsetButtons"
        private val KEYS = setOf(
            KeyEvent.KEYCODE_HEADSETHOOK,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE
        )
    }
}
