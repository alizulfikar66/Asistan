package com.asistan.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

data class RuntimePerm(val permission: String, val title: String, val why: String)

object Perms {

    val runtime: List<RuntimePerm> = buildList {
        add(RuntimePerm(Manifest.permission.RECORD_AUDIO, "Mikrofon", "Seni duyabilmek için"))
        add(RuntimePerm(Manifest.permission.READ_CONTACTS, "Rehber", "\"Annemi ara\" diyebilmen için"))
        add(RuntimePerm(Manifest.permission.CALL_PHONE, "Telefon araması", "Arama başlatmak için"))
        add(RuntimePerm(Manifest.permission.READ_SMS, "SMS okuma", "Mesajlarını okuyabilmek için"))
        add(RuntimePerm(Manifest.permission.SEND_SMS, "SMS gönderme", "Senin adına SMS atmak için"))
        if (Build.VERSION.SDK_INT >= 33) {
            add(RuntimePerm(Manifest.permission.POST_NOTIFICATIONS, "Bildirimler", "Arka planda çalıştığını göstermek için"))
        }
    }

    fun has(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    fun missingRuntime(ctx: Context) = runtime.map { it.permission }.filterNot { has(ctx, it) }

    fun notificationAccess(ctx: Context) =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun overlay(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun batteryUnrestricted(ctx: Context) =
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

    fun openNotificationAccess(ctx: Context) =
        open(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    fun openOverlay(ctx: Context) =
        open(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))

    fun openBattery(ctx: Context) =
        open(ctx, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))

    fun openAppDetails(ctx: Context) =
        open(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))

    fun openTtsSettings(ctx: Context) = open(ctx, Intent("com.android.settings.TTS_SETTINGS"))

    fun openUrl(ctx: Context, url: String) = open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun open(ctx: Context, i: Intent) {
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }
}
