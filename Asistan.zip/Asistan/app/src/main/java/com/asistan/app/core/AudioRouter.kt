package com.asistan.app.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * Asistanın ses yolunu yönetir:
 *  - Dinlerken/konuşurken müziği duraklatır (ses odağı), bitince bırakır.
 *  - Bluetooth kulaklık takılıysa kulaklığın MİKROFONUNU açar (SCO) ve asistanın sesini
 *    kulaklıktan verir; böylece telefon cepteyken kulaklıkla konuşabilirsin.
 *  - Kablolu / USB kulaklıkta Android zaten kulaklık mikrofonunu kullanır, ek işlem gerekmez.
 * Tüm fonksiyonlar ana iş parçacığında çağrılmalıdır.
 */
class AudioRouter(private val ctx: Context) {

    private val am = ctx.getSystemService(AudioManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private val settings = AppSettings(ctx)

    private var focus: AudioFocusRequest? = null
    private var scoStarting = false
    private var scoOn = false
    private var weChangedMode = false
    private var scoReceiver: BroadcastReceiver? = null
    private val waiters = ArrayList<() -> Unit>()
    private val scoTimeout = Runnable { finishScoWait(connected = false) }

    /** Asistanın sesi şu an Bluetooth kulaklıktan mı gidiyor? */
    val usingBluetoothHeadset: Boolean get() = scoOn

    /** Herhangi bir kulaklık (kablolu, USB, Bluetooth) bağlı mı? */
    fun headsetConnected(): Boolean = try {
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in HEADSET_TYPES }
    } catch (_: Exception) {
        false
    }

    /** Mikrofonlu Bluetooth kulaklığın adı (yoksa null). */
    fun bluetoothHeadsetName(): String? = btMicDevice()?.productName?.toString()?.ifBlank { "Bluetooth kulaklık" }

    private fun btMicDevice(): AudioDeviceInfo? = try {
        if (Build.VERSION.SDK_INT >= 31) {
            am.availableCommunicationDevices.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
            }
        } else {
            (am.getDevices(AudioManager.GET_DEVICES_INPUTS) + am.getDevices(AudioManager.GET_DEVICES_OUTPUTS))
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
        }
    } catch (_: Exception) {
        null
    }

    /**
     * Dinlemeden önce çağrılır. Ses odağını alır; Bluetooth kulaklık varsa mikrofonunu açar.
     * Hazır olunca [onReady] çağrılır (kulaklık mikrofonu açılamazsa telefon mikrofonuyla devam eder).
     * [allowBluetooth] false ise (ör. telefon çalarken) Bluetooth mikrofonu açılmaz.
     */
    fun acquire(allowBluetooth: Boolean, onReady: () -> Unit) {
        requestFocus()
        if (scoOn || !allowBluetooth || !settings.headsetMic || isInPhoneCall()) {
            onReady()
            return
        }
        val dev = btMicDevice()
        if (dev == null) {
            onReady()
            return
        }
        waiters.add(onReady)
        if (scoStarting) return
        scoStarting = true
        main.postDelayed(scoTimeout, 2500)
        try {
            if (am.mode == AudioManager.MODE_NORMAL) {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                weChangedMode = true
            }
            if (Build.VERSION.SDK_INT >= 31) {
                val ok = am.setCommunicationDevice(dev)
                if (!ok) {
                    finishScoWait(connected = false)
                    return
                }
                // Bağlantının oturması için kısa bekleme
                main.postDelayed({ if (scoStarting) finishScoWait(connected = true) }, 700)
            } else {
                registerScoReceiver()
                @Suppress("DEPRECATION")
                am.startBluetoothSco()
                @Suppress("DEPRECATION")
                am.isBluetoothScoOn = true
            }
        } catch (e: Exception) {
            Log.w(TAG, "Kulaklık mikrofonu açılamadı", e)
            finishScoWait(connected = false)
        }
    }

    private fun registerScoReceiver() {
        if (scoReceiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val state = i.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1)
                if (state == AudioManager.SCO_AUDIO_STATE_CONNECTED && scoStarting) {
                    // Ses bağlantısı kuruldu; ilk heceler kaçmasın diye çok kısa bekle
                    main.postDelayed({ if (scoStarting) finishScoWait(connected = true) }, 250)
                }
            }
        }
        scoReceiver = r
        try {
            ContextCompat.registerReceiver(
                ctx, r, IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (_: Exception) {
            scoReceiver = null
        }
    }

    private fun finishScoWait(connected: Boolean) {
        main.removeCallbacks(scoTimeout)
        if (!scoStarting) return
        scoStarting = false
        if (connected) {
            scoOn = true
        } else {
            stopSco()
            AssistantState.info.value = "Kulaklık mikrofonu açılamadı, telefonun mikrofonunu kullanıyorum."
        }
        val list = ArrayList(waiters)
        waiters.clear()
        list.forEach { it() }
    }

    private fun stopSco() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                am.clearCommunicationDevice()
            } else {
                @Suppress("DEPRECATION")
                am.isBluetoothScoOn = false
                @Suppress("DEPRECATION")
                am.stopBluetoothSco()
            }
        } catch (_: Exception) {
        }
        scoReceiver?.let {
            try {
                ctx.unregisterReceiver(it)
            } catch (_: Exception) {
            }
        }
        scoReceiver = null
        // Gerçek bir telefon görüşmesi sırasında modu bozma
        if (weChangedMode && am.mode == AudioManager.MODE_IN_COMMUNICATION) {
            try {
                am.mode = AudioManager.MODE_NORMAL
            } catch (_: Exception) {
            }
        }
        weChangedMode = false
        scoOn = false
    }

    /** Konuşma bitti: kulaklık mikrofonunu kapat, müziğin devam etmesine izin ver. */
    fun release() {
        main.removeCallbacks(scoTimeout)
        scoStarting = false
        waiters.clear()
        if (scoOn || weChangedMode || scoReceiver != null) stopSco()
        abandonFocus()
    }

    fun requestFocus() {
        if (focus != null) return
        val f = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setOnAudioFocusChangeListener { }
            .build()
        try {
            am.requestAudioFocus(f)
            focus = f
        } catch (_: Exception) {
        }
    }

    private fun abandonFocus() {
        val f = focus ?: return
        focus = null
        try {
            am.abandonAudioFocusRequest(f)
        } catch (_: Exception) {
        }
    }

    /** Metin okuma (TTS) için ses özellikleri: kulaklık mikrofonu açıksa ses de kulaklıktan gelsin. */
    fun speechAttributes(): AudioAttributes =
        if (scoOn) AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        else AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()

    /** Bip sesi için uygun ses kanalı. */
    fun toneStream(): Int = if (scoOn) AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_MUSIC

    private fun isInPhoneCall(): Boolean = try {
        am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_RINGTONE
    } catch (_: Exception) {
        false
    }

    companion object {
        private const val TAG = "AudioRouter"
        val HEADSET_TYPES = buildSet {
            add(AudioDeviceInfo.TYPE_WIRED_HEADSET)
            add(AudioDeviceInfo.TYPE_WIRED_HEADPHONES)
            add(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)
            add(AudioDeviceInfo.TYPE_BLUETOOTH_SCO)
            add(AudioDeviceInfo.TYPE_USB_HEADSET)
            if (Build.VERSION.SDK_INT >= 31) {
                add(AudioDeviceInfo.TYPE_BLE_HEADSET)
                add(AudioDeviceInfo.TYPE_BLE_SPEAKER)
            }
        }
    }
}
