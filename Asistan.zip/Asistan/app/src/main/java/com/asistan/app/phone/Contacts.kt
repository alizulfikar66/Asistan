package com.asistan.app.phone

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract

data class Contact(
    val name: String,
    val number: String,
    val label: String,
    val type: Int = 0,
    val primary: Boolean = false
)

/** Rehberde kişi arama. Türkçe ekleri ("Ahmet'i", "annemi", "hayatımı") tolere eder. */
object Contacts {

    // Uzundan kısaya: önce uzun ek denenir
    private val suffixes = listOf(
        "nin", "nun", "yla", "yle", "la", "le", "yi", "yu", "ye", "ya", "ni", "nu", "na", "ne",
        "i", "u", "e", "a", "m"
    )

    fun all(ctx: Context): List<Contact> {
        val result = mutableListOf<Contact>()
        val seen = HashSet<String>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE,
            ContactsContract.CommonDataKinds.Phone.LABEL,
            ContactsContract.CommonDataKinds.Phone.IS_SUPER_PRIMARY
        )
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val type = c.getInt(2)
                val customLabel = c.getString(3)
                val primary = c.getInt(4) != 0
                val label = ContactsContract.CommonDataKinds.Phone
                    .getTypeLabel(ctx.resources, type, customLabel).toString()
                val key = name + "|" + TextUtil.digits(number).takeLast(10)
                if (seen.add(key)) result.add(Contact(name, number, label, type, primary))
            }
        }
        return result
    }

    /** Sorgunun olası eksiz halleri: "hayatimi" -> ["hayatimi", "hayatim", "hayati"...]. */
    private fun variants(base: String): List<Pair<String, Int>> {
        val out = LinkedHashMap<String, Int>() // varyant -> kaç ek atıldı
        out[base] = 0
        // Ayrı kelime olarak kalmış ekleri at: "ahmet i" -> "ahmet"
        val words = base.split(" ").toMutableList()
        while (words.size > 1 && words.last() in suffixes) words.removeAt(words.size - 1)
        val joined = words.joinToString(" ")
        if (joined != base) out.putIfAbsent(joined, 1)
        // Son kelimeye yapışık ekleri en fazla iki kez at
        var frontier = listOf(joined)
        for (depth in 1..2) {
            val next = mutableListOf<String>()
            for (v in frontier) for (s in suffixes) {
                if (v.endsWith(s) && v.length - s.length >= 3) {
                    val cut = v.dropLast(s.length).trim()
                    if (out.putIfAbsent(cut, depth) == null) next.add(cut)
                }
            }
            frontier = next
        }
        return out.entries.map { it.key to it.value }
    }

    private fun scored(ctx: Context, query: String): List<Pair<Contact, Int>> {
        val base = TextUtil.normalize(query.substringBefore('\''))
        if (base.isEmpty()) return emptyList()
        val vs = variants(base)
        return all(ctx).map { c ->
            val n = TextUtil.normalize(c.name)
            // Her kişi için en iyi varyantın puanı; atılan her ek için küçük ceza
            c to (vs.maxOfOrNull { (v, cut) -> score(n, v).let { if (it > 0) it - cut * 2 else 0 } } ?: 0)
        }.filter { it.second > 0 }.sortedByDescending { it.second }
    }

    fun search(ctx: Context, query: String): List<Contact> {
        val found = scored(ctx, query)
        if (found.isEmpty()) return emptyList()
        val best = found.first().second
        return found.filter { it.second >= best - 10 }.map { it.first }.take(8)
    }

    /**
     * Sesli "X'i ara" komutu için: tek ve güçlü bir eşleşme varsa o kişinin numarasını döndürür.
     * Belirsizse (iki farklı kişi) veya eşleşme zayıfsa null döner.
     */
    fun bestForCall(ctx: Context, query: String): Contact? {
        val found = scored(ctx, query)
        if (found.isEmpty()) return null
        val best = found.first().second
        if (best < 60) return null
        val top = found.filter { it.second >= best - 3 }.map { it.first }
        val names = top.map { TextUtil.normalize(it.name) }.distinct()
        if (names.size != 1) return null
        // Aynı kişinin birden fazla numarası varsa: varsayılan > cep > ilki
        return top.firstOrNull { it.primary }
            ?: top.firstOrNull { it.type == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE }
            ?: top.first()
    }

    private fun score(name: String, q: String): Int = when {
        name == q -> 100
        name.startsWith("$q ") -> 85
        name.startsWith(q) -> 80
        name.split(" ").any { it == q } -> 75
        name.split(" ").any { it.startsWith(q) } -> 65
        name.contains(q) -> 50
        q.length >= 3 && name.length >= 3 && q.contains(name) -> 40
        else -> 0
    }

    fun nameForNumber(ctx: Context, number: String): String? {
        if (number.isBlank()) return null
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            ctx.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }
}
