package com.asistan.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.asistan.app.core.AppSettings
import com.asistan.app.core.AssistantService
import com.asistan.app.core.AssistantState
import com.asistan.app.core.ClaudeClient
import com.asistan.app.wake.ModelDownloader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun SettingsScreen(settings: AppSettings, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // İzin ekranlarından dönünce durumları yenile
    var refresh by remember { mutableIntStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) refresh++ }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh++ }

    var apiKey by remember { mutableStateOf(settings.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(settings.model) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(settings.userName) }
    var city by remember { mutableStateOf(settings.city) }
    var wakeEnabled by remember { mutableStateOf(settings.wakeWordEnabled) }
    var wakeWord by remember { mutableStateOf(settings.wakeWord) }
    var announce by remember { mutableStateOf(settings.announceMessages) }
    var webSearch by remember { mutableStateOf(settings.webSearch) }
    val progress by AssistantState.modelProgress.collectAsState()
    var modelReady by remember { mutableStateOf(ModelDownloader.isReady(ctx)) }
    var downloadError by remember { mutableStateOf<String?>(null) }

    fun refreshService() = AssistantService.send(ctx, AssistantService.ACTION_REFRESH)

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Palette.bgTop, Palette.bgBottom)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Palette.text)
            }
            Text("Ayarlar", color = Palette.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---------------- Claude ----------------
            Section("1 · Claude API anahtarı") {
                Hint("Asistanın beyni Claude. platform.claude.com adresinden ücretsiz hesap aç, kredi yükle ve bir API anahtarı oluştur (sk-ant- ile başlar).")
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it; settings.apiKey = it },
                    label = { Text("API anahtarı") },
                    singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    colors = fieldColors()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Gizle" else "Göster") }
                    TextButton(onClick = { Perms.openUrl(ctx, "https://console.anthropic.com/settings/keys") }) {
                        Text("Anahtar al")
                    }
                    Spacer(Modifier.weight(1f))
                    Button(
                        enabled = !testing && apiKey.isNotBlank(),
                        onClick = {
                            testing = true
                            testResult = null
                            scope.launch {
                                testResult = try {
                                    withContext(Dispatchers.IO) {
                                        ClaudeClient(settings).createMessage(
                                            "Kısa cevap ver.",
                                            JSONArray().put(JSONObject().put("role", "user").put("content", "Tek kelimeyle merhaba de.")),
                                            null, 30
                                        )
                                    }
                                    "✓ Bağlantı çalışıyor"
                                } catch (e: Exception) {
                                    "✗ ${e.message}"
                                }
                                testing = false
                            }
                        }
                    ) { Text(if (testing) "Deneniyor…" else "Test et") }
                }
                testResult?.let {
                    Text(it, color = if (it.startsWith("✓")) Palette.good else Palette.bad, fontSize = 14.sp)
                }
                Text("Model", color = Palette.text, fontWeight = FontWeight.SemiBold)
                ModelOption("Hızlı (Claude Haiku 5.5) – önerilen, en ucuz", model == AppSettings.MODEL_FAST) {
                    model = AppSettings.MODEL_FAST; settings.model = model
                }
                ModelOption("Akıllı (Claude Sonnet 5.5) – daha yavaş, daha pahalı", model == AppSettings.MODEL_SMART) {
                    model = AppSettings.MODEL_SMART; settings.model = model
                }
            }

            // ---------------- İzinler ----------------
            Section("2 · İzinler") {
                key(refresh) {
                    val missing = Perms.missingRuntime(ctx)
                    Perms.runtime.forEach { p ->
                        PermRow(p.title, p.why, Perms.has(ctx, p.permission)) {
                            permLauncher.launch(arrayOf(p.permission))
                        }
                    }
                    if (missing.isNotEmpty()) {
                        Button(
                            onClick = { permLauncher.launch(missing.toTypedArray()) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Tüm izinleri ver") }
                    }
                    PermRow(
                        "Bildirim erişimi",
                        "WhatsApp, Telegram vb. mesajları okuyup cevaplamak için",
                        Perms.notificationAccess(ctx)
                    ) { Perms.openNotificationAccess(ctx) }
                    PermRow(
                        "Diğer uygulamaların üzerinde göster",
                        "\"Asistan\" deyince uygulamanın öne gelmesi için",
                        Perms.overlay(ctx)
                    ) { Perms.openOverlay(ctx) }
                    PermRow(
                        "Pil kısıtlaması yok",
                        "Uyandırma kelimesinin arka planda kesilmemesi için",
                        Perms.batteryUnrestricted(ctx)
                    ) { Perms.openBattery(ctx) }
                }
                Hint("Bildirim erişimi açılmıyor veya \"kısıtlanmış ayar\" uyarısı çıkıyorsa: Uygulama bilgisi ekranında sağ üstteki ⋮ menüsünden \"Kısıtlanmış ayarlara izin ver\"i seç, sonra tekrar dene.")
                OutlinedButton(onClick = { Perms.openAppDetails(ctx) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Uygulama bilgisini aç")
                }
            }

            // ---------------- Uyandırma ----------------
            Section("3 · Uyandırma kelimesi") {
                SwitchRow(
                    "\"${wakeWord.replaceFirstChar { it.uppercase() }}\" deyince dinlemeye başla",
                    "Telefon içinde, internetsiz çalışır. Pil tüketimini biraz artırır.",
                    wakeEnabled
                ) {
                    wakeEnabled = it; settings.wakeWordEnabled = it; refreshService()
                }
                OutlinedTextField(
                    value = wakeWord,
                    onValueChange = { v ->
                        wakeWord = v.take(30)
                        if (v.isNotBlank()) settings.wakeWord = v.trim()
                    },
                    label = { Text("Uyandırma kelimesi") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = fieldColors()
                )
                Hint("Uzun ve günlük konuşmada az geçen bir kelime seç (ör. \"asistan\", \"hey asistan\", \"bilge\").")
                if (modelReady) {
                    Text("✓ Türkçe ses modeli hazır", color = Palette.good, fontSize = 14.sp)
                } else {
                    val p = progress
                    if (p != null) {
                        Text("Ses modeli indiriliyor… %$p", color = Palette.text, fontSize = 14.sp)
                        LinearProgressIndicator(progress = { p / 100f }, modifier = Modifier.fillMaxWidth())
                    } else {
                        Hint("Uyandırma için bir kerelik ~35 MB Türkçe ses modeli indirilmeli (Wi-Fi önerilir).")
                        Button(
                            onClick = {
                                downloadError = null
                                AssistantState.modelProgress.value = 0
                                scope.launch {
                                    try {
                                        ModelDownloader.download(ctx) { AssistantState.modelProgress.value = it }
                                        modelReady = true
                                        refreshService()
                                    } catch (e: Exception) {
                                        downloadError = e.message ?: "İndirme başarısız"
                                    } finally {
                                        AssistantState.modelProgress.value = null
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Ses modelini indir") }
                    }
                    downloadError?.let { Text("✗ $it", color = Palette.bad, fontSize = 14.sp) }
                }
            }

            // ---------------- Mesajlar ve özellikler ----------------
            Section("4 · Özellikler") {
                SwitchRow(
                    "Gelen mesajları sesli oku",
                    "WhatsApp, SMS vb. yeni mesaj gelince okur ve cevap vermek isteyip istemediğini sorar.",
                    announce
                ) { announce = it; settings.announceMessages = it; refreshService() }
                SwitchRow(
                    "İnternette arama",
                    "Hava durumu, haberler, döviz gibi güncel bilgiler için (arama başına küçük ek ücret).",
                    webSearch
                ) { webSearch = it; settings.webSearch = it }
            }

            Section("5 · Seni tanıyayım") {
                OutlinedTextField(
                    value = name, onValueChange = { name = it; settings.userName = it },
                    label = { Text("Adın (isteğe bağlı)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                )
                OutlinedTextField(
                    value = city, onValueChange = { city = it; settings.city = it },
                    label = { Text("Şehrin (hava durumu için)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                )
            }

            Section("6 · Ses") {
                Hint("Asistanın sesi telefonun metin okuma motorundan gelir. Türkçe ses yoksa veya sesi beğenmediysen buradan değiştirebilirsin.")
                OutlinedButton(onClick = { Perms.openTtsSettings(ctx) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Metin okuma ayarlarını aç")
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Palette.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, color = Palette.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        content(this)
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Palette.textDim, fontSize = 13.sp, lineHeight = 18.sp)
}

@Composable
private fun ModelOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, color = Palette.text, fontSize = 14.sp)
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Palette.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = Palette.textDim, fontSize = 13.sp, lineHeight = 17.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PermRow(title: String, why: String, granted: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            Icons.Filled.Check, contentDescription = null,
            tint = if (granted) Palette.good else Palette.textDim.copy(alpha = 0.3f),
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(Palette.surfaceHigh)
                .padding(4.dp)
        )
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, color = Palette.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(why, color = Palette.textDim, fontSize = 12.sp)
        }
        if (!granted) {
            TextButton(onClick = onGrant) { Text("Ver") }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Palette.violet,
    unfocusedBorderColor = Palette.surfaceHigh,
    focusedTextColor = Palette.text,
    unfocusedTextColor = Palette.text,
    focusedLabelColor = Palette.violet,
    unfocusedLabelColor = Palette.textDim
)
