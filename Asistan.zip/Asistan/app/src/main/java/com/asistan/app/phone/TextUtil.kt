package com.asistan.app.phone

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val TURKISH: Locale = Locale("tr", "TR")

object TextUtil {

    /** "Ömer Çağlar" -> "omer caglar". Türkçe karakter ve büyük/küçük harf farkını yok sayar. */
    fun normalize(s: String): String = s.lowercase(TURKISH)
        .replace('ı', 'i').replace('ğ', 'g').replace('ü', 'u')
        .replace('ş', 's').replace('ö', 'o').replace('ç', 'c')
        .replace('â', 'a').replace('î', 'i').replace('û', 'u')
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    fun digits(s: String): String = s.filter { it.isDigit() }

    /** Girdi bir telefon numarasına mı benziyor? */
    fun looksLikeNumber(s: String): Boolean {
        val cleaned = s.replace(Regex("[\\s()\\-+.]"), "")
        return cleaned.length >= 3 && cleaned.all { it.isDigit() }
    }

    /** Sesli okumaya uygun, kısa tarih: "bugün 14:05", "dün 09:12", "3 Ekim 18:40" */
    fun friendlyTime(millis: Long): String {
        val now = Calendar.getInstance()
        val then = Calendar.getInstance().apply { timeInMillis = millis }
        val hm = SimpleDateFormat("HH:mm", TURKISH).format(Date(millis))
        val sameYear = now.get(Calendar.YEAR) == then.get(Calendar.YEAR)
        val dayDiff = now.get(Calendar.DAY_OF_YEAR) - then.get(Calendar.DAY_OF_YEAR)
        return when {
            sameYear && dayDiff == 0 -> "bugün $hm"
            sameYear && dayDiff == 1 -> "dün $hm"
            else -> SimpleDateFormat("d MMMM HH:mm", TURKISH).format(Date(millis))
        }
    }
}
