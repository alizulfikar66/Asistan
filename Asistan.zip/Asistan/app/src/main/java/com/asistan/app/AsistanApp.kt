package com.asistan.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class AsistanApp : Application() {

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Asistan dinleme",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Asistan arka planda çalışırken gösterilir"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    companion object {
        const val CHANNEL_ID = "asistan_service"
    }
}
