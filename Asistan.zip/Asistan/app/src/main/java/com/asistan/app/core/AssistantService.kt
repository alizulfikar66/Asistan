package com.asistan.app.core

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.asistan.app.AsistanApp
import com.asistan.app.MainActivity
import com.asistan.app.R
import com.asistan.app.notify.NotificationStore
import com.asistan.app.wake.ModelDownloader
import com.asistan.app.wake.WakeWordDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Asistanın arka planda çalışan kısmı. Uyandırma kelimesini dinler, konuşmayı yönetir.
 * Android'in mikrofonu arka planda kullanmaya izin vermesi için "ön plan servisi" olarak çalışır
 * (bildirim çubuğunda küçük bir bildirim görünür).
 */
class AssistantService : Service() {

    private val scope = MainScope()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var settings: AppSettings
    private lateinit var engine: ConversationEngine
    private lateinit var wake: WakeWordDetector
    private var wakeLoading = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        settings = AppSettings(this)
        engine = ConversationEngine(this, scope) { main.postDelayed({ afterIdle() }, 600) }
        engine.init()
        wake = WakeWordDetector(this) { onWakeWord() }

        // Yeni mesaj gelince (ayar açıksa) sesli duyur
        scope.launch {
            NotificationStore.incoming.collect { m ->
                if (settings.announceMessages && !engine.isBusy) {
                    wake.stop()
                    engine.announce(m)
                }
            }
        }
        // Uygulama kapatıldığında gereksizse servisi durdur
        scope.launch {
            AssistantState.uiVisible.collect { visible ->
                if (!visible) main.postDelayed({ stopIfUnneeded() }, 1500)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!goForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent?.action) {
            ACTION_LISTEN -> {
                wake.stop()
                main.postDelayed({ engine.startListening() }, 150)
            }
            ACTION_TEXT -> {
                wake.stop()
                engine.submitText(intent.getStringExtra(EXTRA_TEXT).orEmpty())
            }
            ACTION_INTERRUPT -> engine.interrupt()
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> afterIdle() // START / REFRESH
        }
        return START_STICKY
    }

    private fun goForeground(): Boolean = try {
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
        true
    } catch (e: Exception) {
        Log.e(TAG, "Ön plan servisi başlatılamadı", e)
        AssistantState.info.value = "Arka plan dinleme başlatılamadı. Uygulamayı açıp tekrar dene."
        false
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val listen = PendingIntent.getForegroundService(
            this, 1,
            Intent(this, AssistantService::class.java).setAction(ACTION_LISTEN),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (settings.wakeWordEnabled && ModelDownloader.isReady(this))
            "\"${settings.wakeWord.replaceFirstChar { it.uppercase() }}\" demeni bekliyorum"
        else "Konuşmak için dokun"
        return NotificationCompat.Builder(this, AsistanApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Asistan hazır")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(0, "Konuş", listen)
            .addAction(0, "Kapat", stop)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    /** Konuşma bittiğinde: uyandırma kelimesini tekrar dinle veya servisi kapat. */
    private fun afterIdle() {
        if (engine.isBusy) return
        if (stopIfUnneeded()) return
        // Bildirim metnini güncelle
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
        wake.wakeWord = settings.wakeWord
        if (!settings.wakeWordEnabled || !ModelDownloader.isReady(this)) {
            wake.stop()
            if (AssistantState.status.value == Status.WAKE_LISTENING) {
                AssistantState.status.value = Status.IDLE
            }
            return
        }
        if (wake.isRunning || wakeLoading) return
        wakeLoading = true
        scope.launch {
            val ok = withContext(Dispatchers.IO) { wake.loadModel() }
            wakeLoading = false
            if (ok && !engine.isBusy && settings.wakeWordEnabled && wake.start()) {
                AssistantState.status.value = Status.WAKE_LISTENING
            }
        }
    }

    /** Uygulama kapalıysa ve uyandırma/duyuru kapalıysa servise gerek yok. */
    private fun stopIfUnneeded(): Boolean {
        val needed = AssistantState.uiVisible.value ||
                settings.wakeWordEnabled || settings.announceMessages || engine.isBusy
        if (!needed) {
            stopSelf()
            return true
        }
        return false
    }

    private fun onWakeWord() {
        if (engine.isBusy) return
        // "Diğer uygulamaların üzerinde göster" izni varsa uygulamayı öne getir
        if (!AssistantState.uiVisible.value && Settings.canDrawOverlays(this)) {
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            } catch (_: Exception) {
            }
        }
        // Vosk mikrofonu bıraksın diye kısa bir bekleme
        main.postDelayed({ engine.startListening() }, 300)
    }

    override fun onDestroy() {
        running = false
        wake.release()
        engine.shutdown()
        scope.cancel()
        AssistantState.status.value = Status.IDLE
        super.onDestroy()
    }

    companion object {
        private const val TAG = "AssistantService"
        private const val NOTIF_ID = 42

        const val ACTION_START = "com.asistan.START"
        const val ACTION_REFRESH = "com.asistan.REFRESH"
        const val ACTION_LISTEN = "com.asistan.LISTEN"
        const val ACTION_TEXT = "com.asistan.TEXT"
        const val ACTION_INTERRUPT = "com.asistan.INTERRUPT"
        const val ACTION_STOP = "com.asistan.STOP"
        const val EXTRA_TEXT = "text"

        @Volatile
        var running = false
            private set

        /** Uygulama ekrandayken çağrılmalı (Android arka plandan servis başlatmayı kısıtlar). */
        fun send(ctx: Context, action: String, text: String? = null) {
            val i = Intent(ctx, AssistantService::class.java).setAction(action)
            if (text != null) i.putExtra(EXTRA_TEXT, text)
            try {
                ContextCompat.startForegroundService(ctx, i)
            } catch (e: Exception) {
                Log.e(TAG, "Servis başlatılamadı", e)
                AssistantState.info.value = "Asistan servisi başlatılamadı: ${e.message}"
            }
        }
    }
}
