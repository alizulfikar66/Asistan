package com.asistan.app.core

import kotlinx.coroutines.flow.MutableStateFlow

/** Asistanın o anki durumu. Arayüzdeki küre bu duruma göre renk değiştirir. */
enum class Status {
    IDLE,            // Boşta
    WAKE_LISTENING,  // "Asistan" kelimesini bekliyor
    LISTENING,       // Kullanıcıyı dinliyor
    THINKING,        // Claude düşünüyor / araç çalıştırıyor
    SPEAKING         // Cevabı sesli okuyor
}

data class ChatLine(
    val fromUser: Boolean,
    val text: String,
    val time: Long = System.currentTimeMillis()
)

/**
 * Servis ile arayüz arasında paylaşılan ortak durum.
 * İkisi de aynı uygulama sürecinde çalıştığı için basit bir tekil nesne yeterli.
 */
object AssistantState {
    val status = MutableStateFlow(Status.IDLE)
    val partial = MutableStateFlow("")           // Konuşurken anlık yazıya dökülen metin
    val level = MutableStateFlow(0f)             // Ses seviyesi 0..1 (küre animasyonu için)
    val lines = MutableStateFlow<List<ChatLine>>(emptyList())
    val info = MutableStateFlow<String?>(null)   // Hata / bilgi mesajı
    val uiVisible = MutableStateFlow(false)      // Uygulama ekranda mı?
    val modelProgress = MutableStateFlow<Int?>(null) // Uyandırma modeli indirme yüzdesi

    fun add(line: ChatLine) {
        lines.value = (lines.value + line).takeLast(100)
    }
}
