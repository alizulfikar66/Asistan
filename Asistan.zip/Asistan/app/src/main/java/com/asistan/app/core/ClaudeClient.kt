package com.asistan.app.core

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ClaudeException(message: String, val code: Int = 0) : Exception(message)

/** Claude Messages API'ye istek atan küçük istemci. Bloklayan çağrıdır; arka plan iş parçacığında kullanın. */
class ClaudeClient(private val settings: AppSettings) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun createMessage(
        system: String,
        messages: JSONArray,
        tools: JSONArray?,
        maxTokens: Int = 1024
    ): JSONObject {
        val key = settings.apiKey
        if (key.isBlank()) {
            throw ClaudeException("API anahtarı girilmemiş. Ayarlar ekranından Claude API anahtarını ekle.", -1)
        }
        val body = JSONObject()
            .put("model", settings.model)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put("messages", messages)
        if (tools != null && tools.length() > 0) body.put("tools", tools)

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", key)
            .header("anthropic-version", "2023-06-01")
            .header("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching {
                    JSONObject(text).getJSONObject("error").getString("message")
                }.getOrDefault(text.take(300))
                throw ClaudeException(msg, resp.code)
            }
            return JSONObject(text)
        }
    }
}
