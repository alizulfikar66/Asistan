# 🎙️ Asistan — Android için Türkçe sesli yapay zekâ asistanı

Siri benzeri, telefonunla **konuşarak** kullandığın bir asistan. Beyni Claude yapay zekâsı.

**Neler yapabilir?**

| Sen dersin ki… | Asistan… |
|---|---|
| "Annemi ara" | Rehberde bulur, "Annen aranıyor" der ve arar |
| "Okunmamış SMS'lerimi oku" | Gönderen adıyla birlikte sesli okur |
| "Ahmet'e 'akşam geç geleceğim' diye SMS at" | Metni tekrar eder, "Göndereyim mi?" diye sorar, onaylarsan gönderir |
| "WhatsApp'ta son mesajları oku" | WhatsApp, Telegram, Instagram, BiP… bildirimlerini okur |
| "Ona 'tamam geliyorum' diye cevap ver" | WhatsApp mesajına doğrudan cevap yazar |
| "Yarın 7'ye alarm kur" / "10 dakikalık zamanlayıcı" | Saat uygulamasında kurar |
| "Spotify'ı aç" | Uygulamayı açar |
| "İstanbul'da hava nasıl?" / "Dolar kaç TL?" | İnternette arayıp cevaplar |
| Herhangi bir soru, sohbet | Doğal Türkçe sohbet eder |

Ayrıca:
- **"Asistan" deyince uyanır** (telefonun içinde, internetsiz dinler — ses kaydı dışarı gitmez)
- **Gelen mesajları sesli duyurur** ve "Cevap vermek ister misin?" diye sorar (isteğe bağlı)
- Soru sorduğunda mikrofonu **otomatik tekrar açar**, böylece karşılıklı sohbet edebilirsin
- İstersen klavyeyle de yazabilirsin

> **Neden sadece Android?** Apple, iPhone'da başka uygulamaların SMS okumasına ve kendi kendine arama yapmasına izin vermiyor. Android'de bunların hepsi mümkün.

---

## 📋 İhtiyacın olanlar

1. **Android telefon** (Android 8 veya üzeri)
2. **Claude API anahtarı** (aşağıda nasıl alınacağı anlatılıyor)
3. Bir bilgisayar (Windows, Mac veya Linux) — sadece uygulamayı bir kere derlemek için

---

## 1. Adım — Claude API anahtarını al

1. Bilgisayarında **https://console.anthropic.com** adresine git, hesap aç.
2. **Billing (Faturalandırma)** bölümünden kredi yükle. 5 dolar bile aylarca yeter (bkz. *Maliyet*).
3. **API Keys** bölümünde **Create Key**'e bas. `sk-ant-` ile başlayan anahtarı kopyala ve bir yere not et.
   ⚠️ Bu anahtar bir şifre gibidir, kimseyle paylaşma.

---

## 2. Adım — Uygulamayı derle (APK dosyası oluştur)

İki yol var. **Hiç program kurmak istemiyorsan A yolunu** seç.

### 🅰️ Yol A: GitHub ile (bilgisayara hiçbir şey kurmadan)

1. **https://github.com** adresinde ücretsiz hesap aç.
2. Sağ üstteki **+** → **New repository**. İsim olarak `Asistan` yaz, **Private** seç, **Create repository**'e bas.
3. Açılan sayfada **"uploading an existing file"** bağlantısına tıkla.
4. Bu zip'ten çıkan **Asistan klasörünün içindeki her şeyi** (klasörün kendisini değil, içindekileri) sürükleyip bırak.
   - ⚠️ `.github` adlı gizli klasörün de yüklendiğinden emin ol. Mac'te Finder'da gizli dosyaları göstermek için `Cmd + Shift + .` tuşlarına bas. Windows'ta Dosya Gezgini → Görünüm → "Gizli öğeler"i işaretle.
   - Sürükle-bırak `.github` klasörünü almazsa: GitHub'da **Add file → Create new file**'a bas, dosya adına `.github/workflows/build.yml` yaz ve bu projedeki `build.yml`'in içeriğini yapıştır.
5. Aşağıdaki **Commit changes** düğmesine bas.
6. Üstteki **Actions** sekmesine geç. "APK derle" işinin çalıştığını göreceksin (sarı daire). 5-10 dakika bekle.
7. Yeşil tik ✅ çıkınca işe tıkla, en alttaki **Artifacts** bölümünden **Asistan-APK**'yı indir. İçinden `app-debug.apk` çıkacak.
   - Kırmızı ❌ çıkarsa: işe tıkla, hatanın yazdığı kısmı kopyala ve bana gönder, düzeltelim.

### 🅱️ Yol B: Android Studio ile

1. **https://developer.android.com/studio** adresinden Android Studio'yu indirip kur (varsayılan seçeneklerle).
2. Android Studio'yu aç → **Open** → bu `Asistan` klasörünü seç.
3. Sağ altta "Gradle sync" bitene kadar bekle (ilk seferde 5-15 dakika sürebilir, gerekli dosyaları indirir).
4. Telefonunda **Geliştirici seçenekleri**ni aç: Ayarlar → Telefon hakkında → **Yapı numarası**'na 7 kez dokun. Sonra Geliştirici seçenekleri → **USB hata ayıklama**'yı aç.
5. Telefonu USB kabloyla bilgisayara bağla, telefondaki izni onayla.
6. Android Studio'da üstteki yeşil ▶️ **Run** düğmesine bas. Uygulama telefona kurulup açılır.

---

## 3. Adım — APK'yı telefona kur (Yol A'yı seçtiysen)

1. `app-debug.apk` dosyasını telefona gönder (kendine e-posta, Google Drive, WhatsApp "kendime mesaj", USB…).
2. Telefonda dosyaya dokun. "Bilinmeyen uygulamalar" uyarısı çıkarsa **Ayarlar**'a gidip bu kaynağa izin ver.
3. **Yükle**'ye bas. Google Play Protect uyarı verirse **Yine de yükle**'yi seç (uygulamayı sen derledin, Play Store'da olmadığı için uyarıyor).

---

## 4. Adım — İlk kurulum (telefonda)

Uygulama ilk açılışta **Ayarlar** ekranını açar:

1. **API anahtarını** yapıştır → **Test et**'e bas → "✓ Bağlantı çalışıyor" görmelisin.
2. **İzinler** bölümünde **Tüm izinleri ver**'e bas ve hepsine izin ver.
3. **Bildirim erişimi** → **Ver** → listede Asistan'ı bul ve aç.
   - 🔒 **"Kısıtlanmış ayar" uyarısı çıkarsa** (Android 13+ Play Store dışı uygulamalarda olur): Ayarlar ekranındaki **Uygulama bilgisini aç** düğmesine bas → sağ üstteki **⋮** → **Kısıtlanmış ayarlara izin ver** → sonra bildirim erişimini tekrar açmayı dene.
4. (Önerilir) **Diğer uygulamaların üzerinde göster** ve **Pil kısıtlaması yok** izinlerini ver.
5. "Asistan" deyince uyanmasını istiyorsan **Uyandırma kelimesi** bölümünden **Ses modelini indir**'e bas (~35 MB, bir kere), sonra anahtarı aç.
6. **Şehrini** yaz (hava durumu için).
7. Geri dön ve **küreye dokunup konuş!**

**Ses gelmiyor veya İngilizce aksanla konuşuyorsa:** Ayarlar → 6 · Ses → **Metin okuma ayarlarını aç** → "Google Konuşma Hizmetleri"nde Türkçe ses verisini indir.

---

## 💬 Kullanım ipuçları

- **Küreye dokun** → bip sesinden sonra konuş. Konuşurken tekrar dokunursan durur.
- Kürenin rengi ne yaptığını gösterir: 💜 hazır · 🩵 dinliyor · 🩷 düşünüyor · 🧡 konuşuyor · 💚 "Asistan" kelimesini bekliyor.
- Asistan soru sorarsa (ör. "Göndereyim mi?") mikrofon kendiliğinden açılır, sadece "evet" demen yeter.
- 5 dakika konuşmazsan sohbet sıfırlanır.
- **WhatsApp mesajları:** Asistan, telefona gelen *bildirimleri* okur. Yani uygulama açıldıktan sonra gelen mesajları görebilir, eski sohbet geçmişini göremez. Bildirimi sessize alınmış sohbetleri de göremez.

---

## 💰 Maliyet

- Varsayılan model **Claude Haiku 5.5**: hızlı ve çok ucuz. Bir komut genellikle bir kuruşun çok küçük bir kısmına mal olur; 5 dolarlık kredi normal kullanımda uzun süre yeter.
- **Akıllı mod (Sonnet 5.5)** daha zeki ama birkaç kat pahalı ve biraz daha yavaş.
- **İnternette arama** her aramada küçük bir ek ücret alır; istemezsen Ayarlar'dan kapatabilirsin.
- Güncel fiyatlar: https://www.anthropic.com/pricing — kullanımını console.anthropic.com'dan takip edebilir, harcama limiti koyabilirsin.

Uyandırma kelimesi dinleme ve konuşmayı yazıya çevirme ücretsizdir (telefonda / Google'ın servisinde çalışır).

---

## 🛠️ Sorun giderme

| Sorun | Çözüm |
|---|---|
| "API anahtarı geçersiz" | Anahtarı tekrar kopyala, başında/sonunda boşluk olmasın. Hesabında kredi olduğundan emin ol. |
| "Konuşma tanıma servisi yok" | Play Store'dan **Google** uygulamasını yükle/güncelle. |
| Beni anlamıyor | İnternet bağlantını kontrol et; Google uygulamasında Türkçe dil paketinin yüklü olduğundan emin ol. |
| WhatsApp mesajlarını göremiyor | Bildirim erişimini aç (yukarıdaki "kısıtlanmış ayar" notuna bak). WhatsApp bildirimlerinin açık olduğundan emin ol. |
| "Asistan" deyince uyanmıyor | Ses modelini indirdin mi? Pil kısıtlamasını kaldır. Daha net ve yakından söyle. Xiaomi/Huawei/Oppo telefonlarda ayrıca uygulama ayarlarından **Otomatik başlat**'ı aç. |
| Uyanıyor ama uygulama ekrana gelmiyor | "Diğer uygulamaların üzerinde göster" iznini ver. |
| Kendi kendine uyanıyor | Uyandırma kelimesini daha uzun ve nadir bir şeyle değiştir (ör. "hey asistan"). |
| Alarm kurulmuyor / uygulama açılmıyor | "Diğer uygulamaların üzerinde göster" iznini ver (Android, arka plandan uygulama açmayı kısıtlıyor). |
| Derleme hatası | Hata metnini kopyalayıp bana gönder. |

---

## 🔐 Gizlilik ve güvenlik

- API anahtarın yalnızca telefonunda, bu uygulamanın özel alanında saklanır.
- Söylediklerin yazıya çevrildikten sonra (ve okunan mesajların içeriği) cevap üretmek için Claude API'ye gönderilir.
- Uyandırma kelimesi tamamen telefonda dinlenir, hiçbir yere ses gönderilmez.
- Asistan **senin onayın olmadan mesaj göndermez**; önce metni okur ve sorar.
- APK'yı başkalarıyla paylaşacaksan kendi API anahtarını girmelerini söyle.

---

## 🧠 Nasıl çalışıyor? (Merak edenler için)

```
"Asistan!" ──► Vosk (telefonda, internetsiz) uyandırma kelimesini yakalar
                    │
                    ▼
   Konuşma ──► Android SpeechRecognizer (tr-TR) ──► metin
                    │
                    ▼
            Claude API (araç kullanımı / tool use)
              │  "make_call", "read_sms", "send_sms",
              │  "read_app_messages", "reply_app_message",
              │  "set_alarm", "set_timer", "open_app", "web_search"
              ▼
        Telefonda aracı çalıştır ──► sonucu Claude'a geri ver
                    │
                    ▼
        Cevap ──► TextToSpeech (Türkçe) ──► soru sorduysa tekrar dinle
```

**Proje yapısı**

```
app/src/main/java/com/asistan/app/
├── MainActivity.kt              Uygulamanın giriş noktası
├── core/
│   ├── AssistantService.kt      Arka planda çalışan servis (uyandırma + konuşma)
│   ├── ConversationEngine.kt    Dinle → Claude'a sor → araçları çalıştır → konuş
│   ├── ClaudeClient.kt          Claude API bağlantısı
│   ├── Tools.kt                 Claude'un kullanabildiği telefon araçları
│   ├── AppSettings.kt           Ayarlar
│   └── AssistantState.kt        Ekran ile servis arasındaki ortak durum
├── phone/                       Rehber, SMS, arama, alarm, uygulama açma
├── notify/                      WhatsApp vb. bildirimlerini okuma ve cevaplama
├── wake/                        "Asistan" uyandırma kelimesi (Vosk)
└── ui/                          Ekranlar, animasyonlu küre, ayarlar
```

**Yeni özellik eklemek** çok kolay: `Tools.kt` içinde `definitions()` listesine yeni bir araç tanımı ekle ve `execute()` içinde ne yapacağını yaz. Claude, açıklamayı okuyup ne zaman kullanacağını kendisi anlar.

---

## 🚀 Sonraki fikirler

- Takvim: "Yarın ne işim var?" (Google Takvim okuma)
- Konum: "En yakın eczane nerede?"
- Müzik kontrolü: "Şarkıyı geç", "sesi kıs"
- Ev otomasyonu: "Salonun ışığını kapat"
- Gelen aramada arayanı sesli söyleme
- Telefonun varsayılan dijital asistanı olarak ayarlanabilme (ana ekran tuşuna uzun basınca açılma)
