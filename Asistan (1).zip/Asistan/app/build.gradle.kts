plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.asistan.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.asistan.app"
        minSdk = 26          // Android 8.0 ve üzeri
        targetSdk = 35
        versionCode = 5
        versionName = "5.0"
    }

    // Sabit imza anahtarı: her yeni sürüm eskisinin üstüne güncelleme olarak kurulabilsin.
    signingConfigs {
        create("asistan") {
            storeFile = file("asistan.keystore")
            storePassword = "asistan123"
            keyAlias = "asistan"
            keyPassword = "asistan123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("asistan")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("asistan")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Claude API'ye bağlanmak için
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Çevrimdışı uyandırma kelimesi ("Asistan") için Vosk
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
}
