package com.asistan.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val bgTop = Color(0xFF0E0A1F)
    val bgBottom = Color(0xFF1A1036)
    val surface = Color(0xFF1E1638)
    val surfaceHigh = Color(0xFF2A2050)
    val text = Color(0xFFF2EEFF)
    val textDim = Color(0xFFA79EC9)
    val violet = Color(0xFF7C4DFF)
    val pink = Color(0xFFFF4FA3)
    val cyan = Color(0xFF32D3F5)
    val teal = Color(0xFF2EE6B6)
    val orange = Color(0xFFFF9F43)
    val good = Color(0xFF39D98A)
    val bad = Color(0xFFFF6B6B)
}

@Composable
fun AsistanTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.violet,
            secondary = Palette.pink,
            background = Palette.bgTop,
            surface = Palette.surface,
            surfaceVariant = Palette.surfaceHigh,
            onPrimary = Color.White,
            onBackground = Palette.text,
            onSurface = Palette.text,
            onSurfaceVariant = Palette.textDim
        ),
        content = content
    )
}
