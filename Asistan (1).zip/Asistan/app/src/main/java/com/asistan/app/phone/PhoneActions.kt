package com.asistan.app.phone

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.telecom.TelecomManager

data class AppInfo(val label: String, val packageName: String)

object PhoneActions {

    /** Arama başlatır. CALL_PHONE izni gerekir. */
    @SuppressLint("MissingPermission")
    fun placeCall(ctx: Context, number: String) {
        val tm = ctx.getSystemService(TelecomManager::class.java)
        val uri = Uri.fromParts("tel", number, null)
        try {
            tm.placeCall(uri, Bundle())
        } catch (e: SecurityException) {
            throw e
        } catch (e: Exception) {
            // Bazı cihazlarda placeCall yoksa klasik yöntem
            ctx.startActivity(Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun setAlarm(ctx: Context, hour: Int, minute: Int, label: String?) {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!label.isNullOrBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        ctx.startActivity(i)
    }

    fun setTimer(ctx: Context, seconds: Int, label: String?) {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!label.isNullOrBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        ctx.startActivity(i)
    }

    fun findApps(ctx: Context, query: String): List<AppInfo> {
        val pm = ctx.packageManager
        val q = TextUtil.normalize(query)
        if (q.isEmpty()) return emptyList()
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0).map {
            AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName)
        }.distinctBy { it.packageName }
        val exact = apps.filter { TextUtil.normalize(it.label) == q }
        if (exact.isNotEmpty()) return exact
        return apps.filter {
            val l = TextUtil.normalize(it.label)
            l.contains(q) || (l.length >= 3 && q.contains(l))
        }.take(5)
    }

    /** Google Haritalar'da yol tarifi başlatır veya bir yer arar. */
    fun maps(ctx: Context, query: String, navigate: Boolean) {
        val q = Uri.encode(query)
        val primary = if (navigate) Uri.parse("google.navigation:q=$q") else Uri.parse("geo:0,0?q=$q")
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, primary).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            val web = Uri.parse("https://www.google.com/maps/search/?api=1&query=$q")
            ctx.startActivity(Intent(Intent.ACTION_VIEW, web).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** Türkiye numaralarını WhatsApp'ın beklediği biçime çevirir: 0532... -> 90532... */
    fun whatsappNumber(raw: String): String {
        var d = TextUtil.digits(raw)
        if (raw.trim().startsWith("00")) d = d.removePrefix("00")
        return when {
            d.length == 11 && d.startsWith("0") -> "90" + d.drop(1)
            d.length == 10 && d.startsWith("5") -> "90$d"
            else -> d
        }
    }

    /** WhatsApp'ta sohbeti mesaj yazılmış halde açar; kullanıcı Gönder'e basar. */
    fun whatsappCompose(ctx: Context, number: String, text: String) {
        val uri = Uri.parse("https://wa.me/${whatsappNumber(number)}?text=${Uri.encode(text)}")
        val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
            ctx.packageManager.getLaunchIntentForPackage(it) != null
        }
        if (pkg != null) i.setPackage(pkg)
        ctx.startActivity(i)
    }

    fun launchApp(ctx: Context, packageName: String): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return true
    }
}
