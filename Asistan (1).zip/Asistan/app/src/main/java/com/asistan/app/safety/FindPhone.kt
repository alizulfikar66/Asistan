package com.asistan.app.safety

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.asistan.app.AsistanApp
import com.asistan.app.MainActivity
import com.asistan.app.R
import com.asistan.app.core.AppSettings
import com.asistan.app.core.AssistantState
import com.asistan.app.phone.LocationHelper
import com.asistan.app.phone.Sms
import com.asistan.app.phone.TextUtil

/**
 * Kayıp telefon: başka bir telefondan gizli kodu içeren SMS gelince
 * telefon (sessizde bile) yüksek sesle çalar ve konumunu gönderene SMS ile yollar.
 */
object FindPhone {

    private var player: MediaPlayer? = null
    private var savedAlarmVolume: Int? = null
    private val main = Handler(Looper.getMainLooper())
    private const val NOTIF_ID = 7777

    fun startRinging(ctx: Context) {
        val app = ctx.applicationContext
        main.post {
            if (player != null) return@post
            try {
                val am = app.getSystemService(AudioManager::class.java)
                savedAlarmVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
                am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    setDataSource(app, uri)
                    isLooping = true
                    prepare()
                    start()
                }
                AssistantState.findRinging.value = true
                showNotification(app)
                main.postDelayed({ stopRinging(app) }, 90_000) // en fazla 1,5 dakika
            } catch (_: Exception) {
                stopRinging(app)
            }
        }
    }

    fun stopRinging(ctx: Context) {
        val app = ctx.applicationContext
        main.post {
            main.removeCallbacksAndMessages(null)
            try {
                player?.stop()
                player?.release()
            } catch (_: Exception) {
            }
            player = null
            savedAlarmVolume?.let {
                try {
                    app.getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_ALARM, it, 0)
                } catch (_: Exception) {
                }
            }
            savedAlarmVolume = null
            AssistantState.findRinging.value = false
            app.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
        }
    }

    private fun showNotification(ctx: Context) {
        val stop = PendingIntent.getBroadcast(
            ctx, 77, Intent(ctx, FindPhoneStopReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            ctx, 78, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, AsistanApp.REMINDER_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("📢 Telefon aranıyor")
            .setContentText("Biri \"Telefonumu bul\" kodunu gönderdi. Durdurmak için dokun.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setContentIntent(open)
            .addAction(0, "Durdur", stop)
            .setOngoing(true)
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
        } catch (_: SecurityException) {
        }
    }
}

class FindPhoneStopReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) = FindPhone.stopRinging(ctx)
}

/** Gelen SMS'lerde "Telefonumu bul" kodunu arar. */
class SmsCommandReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val code = AppSettings(ctx).findCode
        if (code.length < 4) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (messages.isEmpty()) return
        val sender = messages[0].originatingAddress ?: return
        val body = messages.joinToString("") { it.messageBody ?: "" }
        if (!TextUtil.normalize(body).contains(TextUtil.normalize(code))) return

        FindPhone.startRinging(ctx)

        // Konumu bul ve gönderene SMS at (arka planda, en fazla ~8 sn)
        val pending = goAsync()
        Thread {
            try {
                val hasLoc = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED
                val canSms = ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS) ==
                        PackageManager.PERMISSION_GRANTED
                if (canSms) {
                    val loc = if (hasLoc) LocationHelper.current(ctx, timeoutSec = 7) else null
                    val text = if (loc != null) {
                        "Asistan: Telefon burada: ${LocationHelper.mapsLink(loc)} (doğruluk ~${loc.accuracy.toInt()} m). Telefon şu an çalıyor."
                    } else {
                        "Asistan: Telefon çalıyor ama konum alınamadı (konum kapalı olabilir)."
                    }
                    Sms.send(ctx, sender, text)
                }
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }.start()
    }
}
