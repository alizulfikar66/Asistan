package com.asistan.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.asistan.app.R
import com.asistan.app.core.AssistantState
import com.asistan.app.core.ChatLine
import com.asistan.app.core.Status

@Composable
fun MainScreen(
    hasApiKey: Boolean,
    onOrbTap: () -> Unit,
    onSendText: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onCamera: () -> Unit,
    onStopFind: () -> Unit,
    onEndMeeting: () -> Unit
) {
    val findRinging by AssistantState.findRinging.collectAsState()
    val meetingOn by AssistantState.meetingOn.collectAsState()
    val wakeReady by AssistantState.wakeReady.collectAsState()
    val status by AssistantState.status.collectAsState()
    val partial by AssistantState.partial.collectAsState()
    val level by AssistantState.level.collectAsState()
    val lines by AssistantState.lines.collectAsState()
    val info by AssistantState.info.collectAsState()
    var typed by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.animateScrollToItem(lines.size + 1) // +1: üst boşluk öğesi
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Palette.bgTop, Palette.bgBottom)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // Üst çubuk
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Asistan", color = Palette.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(statusText(status), color = Palette.textDim, fontSize = 13.sp)
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Ayarlar", tint = Palette.text)
            }
        }

        if (!hasApiKey) {
            Banner(
                "Başlamak için Ayarlar'dan Claude API anahtarını gir ve izinleri ver.",
                onClick = onOpenSettings
            )
        }
        if (meetingOn) {
            Banner("🤝 Toplantı modu açık — telefon sessizde. Bitirmek için dokun.", onClick = onEndMeeting)
        }
        if (hasApiKey && !wakeReady) {
            Banner("💡 Tuşa basmadan \"Asistan\" diyerek konuşmak için Ayarlar > Uyandırma kelimesi'nden ses modelini indir ve aç.", onClick = onOpenSettings)
        }
        if (findRinging) {
            Banner("📢 \"Telefonumu bul\" çalıyor. Durdurmak için dokun.", onClick = onStopFind)
        }
        info?.let { msg ->
            Banner(msg, onClick = { AssistantState.info.value = null }, dismissible = true)
        }

        // Sohbet
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (lines.isEmpty()) {
                Column(
                    Modifier.align(Alignment.Center).padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Merhaba! Neler yapabilirim?", color = Palette.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    listOf(
                        "\"Annemi ara\"",
                        "\"Okunmamış mesajlarımı oku\"",
                        "\"WhatsApp'ta son mesaja cevap ver\"",
                        "\"Yarın 3'te doktoru hatırlat\"",
                        "\"Bugün ne işim var?\"",
                        "\"Şarkıyı geç\" · \"Sesi kıs\" · \"Feneri aç\"",
                        "\"Arabayı B2'ye park ettim, hatırla\"",
                        "\"Kim aradı?\" · \"En yakın eczane\"",
                        "\"Wi-Fi'yi kapat\" · \"Aşağı kaydır\" · \"Geri git\"",
                        "\"Bu numara kimin?\" · \"Engelle\"",
                        "\"Sessize al\" · \"Toplantıya giriyorum\"",
                        "\"Bana kara delikleri anlat\" 🎓"
                    ).forEach {
                        Text(it, color = Palette.textDim, fontSize = 15.sp, modifier = Modifier.padding(vertical = 3.dp))
                    }
                }
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Spacer(Modifier.height(8.dp)) }
                items(lines) { Bubble(it) }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }

        // Anlık yazıya dökülen konuşma
        Text(
            text = if (status == Status.LISTENING) partial.ifBlank { "Dinliyorum…" } else "",
            color = Palette.text,
            fontStyle = FontStyle.Italic,
            fontSize = 17.sp,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp).height(26.dp),
            maxLines = 1
        )

        // Küre
        Box(
            Modifier
                .fillMaxWidth()
                .height(190.dp),
            contentAlignment = Alignment.Center
        ) {
            Orb(status, level, Modifier.size(190.dp))
            Box(
                Modifier
                    .size(110.dp)
                    .clip(CircleShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onOrbTap
                    ),
                contentAlignment = Alignment.Center
            ) {
                when (status) {
                    Status.IDLE, Status.WAKE_LISTENING -> Icon(
                        painterResource(R.drawable.ic_mic), contentDescription = "Konuş",
                        tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(38.dp)
                    )
                    else -> Icon(
                        Icons.Filled.Close, contentDescription = "Durdur",
                        tint = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }

        // Yazarak konuşma
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 8.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onCamera) {
                Icon(painterResource(R.drawable.ic_camera), contentDescription = "Kamerayla göster", tint = Palette.cyan)
            }
            OutlinedTextField(
                value = typed,
                onValueChange = { typed = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Veya buraya yaz…", color = Palette.textDim) },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Palette.violet,
                    unfocusedBorderColor = Palette.surfaceHigh,
                    focusedTextColor = Palette.text,
                    unfocusedTextColor = Palette.text
                )
            )
            IconButton(
                onClick = {
                    if (typed.isNotBlank()) {
                        onSendText(typed)
                        typed = ""
                    }
                }
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Gönder", tint = Palette.violet)
            }
        }
    }
}

private fun statusText(s: Status) = when (s) {
    Status.IDLE -> "Hazır · konuşmak için küreye dokun"
    Status.WAKE_LISTENING -> "Uyandırma kelimesini bekliyor"
    Status.LISTENING -> "Dinliyor…"
    Status.THINKING -> "Düşünüyor…"
    Status.SPEAKING -> "Konuşuyor…"
}

@Composable
private fun Bubble(line: ChatLine) {
    Box(Modifier.fillMaxWidth(), contentAlignment = if (line.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
        Text(
            text = line.text,
            color = Palette.text,
            fontSize = 16.sp,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 18.dp, topEnd = 18.dp,
                        bottomStart = if (line.fromUser) 18.dp else 4.dp,
                        bottomEnd = if (line.fromUser) 4.dp else 18.dp
                    )
                )
                .background(if (line.fromUser) Palette.violet.copy(alpha = 0.85f) else Palette.surfaceHigh)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun Banner(text: String, onClick: () -> Unit, dismissible: Boolean = false) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Palette.surfaceHigh)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Palette.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
        if (dismissible) {
            Icon(Icons.Filled.Close, contentDescription = "Kapat", tint = Palette.textDim, modifier = Modifier.size(18.dp))
        }
    }
}
