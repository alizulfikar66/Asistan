package com.asistan.app.core

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.telephony.TelephonyManager
import com.asistan.app.phone.Contacts
import com.asistan.app.phone.MeetingMode
import android.os.BatteryManager
import com.asistan.app.protect.LastScreenedCall
import com.asistan.app.protect.NumberRisk
import java.lang.ref.WeakReference
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.asistan.app.AsistanApp
import com.asistan.app.MainActivity
import com.asistan.app.R
import com.asistan.app.notify.NotificationStore
import com.asistan.app.wake.ModelDownloader
import com.asistan.app.wake.WakeWordDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Asistanın arka planda çalışan kısmı. Uyandırma kelimesini dinler, konuşmayı yönetir.
 * Android'in mikrofonu arka planda kullanmaya izin vermesi için "ön plan servisi" olarak çalışır
 * (bildirim çubuğunda küçük bir bildirim görünür).
 */
class AssistantService : Service() {

    private val scope = MainScope()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var settings: AppSettings
    private lateinit var engine: ConversationEngine
    private lateinit var wake: WakeWordDetector
    private var wakeLoading = false

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------- Gelen arama takibi ----------------

    private var inCall = false
    private var ringing = false
    private var answered = false
    private var ringNumber: String? = null
    private var ringAnnounced = false
    private val announceUnknown = Runnable { announceIncoming(null) }

    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    inCall = true
                    ringing = true
                    wake.stop()
                    @Suppress("DEPRECATION")
                    val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                    if (!number.isNullOrBlank()) ringNumber = number
                    // Toplantıda veya duyuru kapalıyken sesli söyleme
                    if (!settings.announceCalls || settings.meetingMode) return
                    if (!number.isNullOrBlank()) {
                        main.removeCallbacks(announceUnknown)
                        announceIncoming(number)
                    } else {
                        // Numara genelde ikinci yayında gelir; kısa süre bekle.
                        main.removeCallbacks(announceUnknown)
                        main.postDelayed(announceUnknown, 900)
                    }
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                    inCall = true
                    answered = true
                    main.removeCallbacks(announceUnknown)
                    ringAnnounced = false
                    wake.stop()
                    engine.onCallStateIdleOrAnswered()
                }
                TelephonyManager.EXTRA_STATE_IDLE -> {
                    // Çaldı ama açılmadıysa: cevapsız arama (toplantı modunda otomatik SMS)
                    if (ringing && !answered && settings.meetingMode) {
                        val n = ringNumber ?: if (LastScreenedCall.recent()) LastScreenedCall.number else null
                        Thread { MeetingMode.onMissedCall(this@AssistantService, n) }.start()
                    }
                    ringing = false
                    answered = false
                    ringNumber = null
                    inCall = false
                    main.removeCallbacks(announceUnknown)
                    ringAnnounced = false
                    engine.onCallStateIdleOrAnswered()
                    main.postDelayed({ afterIdle() }, 1200)
                }
            }
        }
    }

    // ---------------- Şarj uyarıları ----------------

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            if (level < 0) return
            val pct = level * 100 / scale
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            val initial = isInitialStickyBroadcast

            if (plugged) {
                lastBatteryAlert = 101
                if (pct >= 100 && !fullAnnounced) {
                    fullAnnounced = true
                    if (!initial && settings.batteryAlerts) batteryNotice("Şarj tamamlandı, pil yüzde yüz doldu.")
                }
                return
            }
            if (pct < 100) fullAnnounced = false
            val threshold = listOf(5, 10, 20).firstOrNull { pct <= it } ?: run {
                lastBatteryAlert = 101
                return
            }
            if (threshold >= lastBatteryAlert) return
            lastBatteryAlert = threshold
            if (initial || !settings.batteryAlerts) return
            batteryNotice(
                when (threshold) {
                    5 -> "Dikkat, şarj kritik seviyede: yüzde $pct. Telefon birazdan kapanabilir, hemen şarja tak."
                    10 -> "Şarj yüzde $pct seviyesine düştü. En kısa sürede şarja takmanı öneririm."
                    else -> "Şarj yüzde $pct seviyesine düştü. Fırsatın olunca şarja takmanı öneririm."
                }
            )
        }
    }

    private fun batteryNotice(text: String) {
        val n = NotificationCompat.Builder(this, AsistanApp.REMINDER_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("🔋 Şarj")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        try {
            getSystemService(NotificationManager::class.java).notify(6000, n)
        } catch (_: SecurityException) {
        }
        if (!engine.isBusy && !inCall && !settings.meetingMode) {
            wake.stop()
            engine.speakNotice(text)
        }
    }

    private fun announceIncoming(number: String?) {
        if (ringAnnounced || !inCall) return
        ringAnnounced = true
        // Numara yoksa arama filtreleme servisinin gördüğü numarayı kullan
        val num = number ?: if (LastScreenedCall.recent()) LastScreenedCall.number else null
        val canKnowNumber = num != null ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED ||
                LastScreenedCall.recent()
        val risk = if (canKnowNumber) {
            try {
                NumberRisk.assess(this, num)
            } catch (e: Exception) {
                null
            }
        } else null
        val sentence = when {
            risk != null -> NumberRisk.announcement(risk)
            num != null -> "${Contacts.nameForNumber(this, num) ?: num} arıyor."
            else -> "Bir arama geliyor."
        }
        if (!AssistantState.uiVisible.value && Settings.canDrawOverlays(this)) {
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            } catch (_: Exception) {
            }
        }
        engine.announceCall(sentence, num, risk?.level ?: 0)
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        instance = WeakReference(this)
        try {
            ContextCompat.registerReceiver(
                this, phoneReceiver,
                IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED),
                ContextCompat.RECEIVER_EXPORTED
            )
        } catch (e: Exception) {
            Log.w(TAG, "Arama dinleyicisi kaydedilemedi", e)
        }
        try {
            ContextCompat.registerReceiver(
                this, batteryReceiver,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED),
                ContextCompat.RECEIVER_EXPORTED
            )
        } catch (e: Exception) {
            Log.w(TAG, "Şarj dinleyicisi kaydedilemedi", e)
        }
        settings = AppSettings(this)
        engine = ConversationEngine(this, scope) { main.postDelayed({ afterIdle() }, 600) }
        engine.init()
        wake = WakeWordDetector(this) { onWakeWord() }

        // Yeni mesaj gelince (ayar açıksa) sesli duyur
        scope.launch {
            NotificationStore.incoming.collect { m ->
                if (settings.announceMessages && !settings.meetingMode && !inCall && !engine.isBusy) {
                    wake.stop()
                    engine.announce(m)
                }
            }
        }
        // Uygulama kapatıldığında gereksizse servisi durdur
        scope.launch {
            AssistantState.uiVisible.collect { visible ->
                if (!visible) main.postDelayed({ stopIfUnneeded() }, 1500)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!goForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent?.action) {
            ACTION_LISTEN -> {
                wake.stop()
                main.postDelayed({ engine.startSession() }, 150)
            }
            ACTION_TEXT -> {
                wake.stop()
                engine.submitText(intent.getStringExtra(EXTRA_TEXT).orEmpty())
            }
            ACTION_IMAGE -> {
                wake.stop()
                val path = intent.getStringExtra(EXTRA_PATH)
                if (path != null) engine.handleImage(path, intent.getStringExtra(EXTRA_TEXT).orEmpty())
            }
            ACTION_INTERRUPT -> engine.interrupt()
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> afterIdle() // START / REFRESH
        }
        return START_STICKY
    }

    private fun goForeground(): Boolean = try {
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
        true
    } catch (e: Exception) {
        Log.e(TAG, "Ön plan servisi başlatılamadı", e)
        AssistantState.info.value = "Arka plan dinleme başlatılamadı. Uygulamayı açıp tekrar dene."
        false
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val listen = PendingIntent.getForegroundService(
            this, 1,
            Intent(this, AssistantService::class.java).setAction(ACTION_LISTEN),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (settings.wakeWordEnabled && ModelDownloader.isReady(this))
            "\"${settings.wakeWord.replaceFirstChar { it.uppercase() }}\" demeni bekliyorum"
        else "Konuşmak için dokun"
        return NotificationCompat.Builder(this, AsistanApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Asistan hazır")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(0, "Konuş", listen)
            .addAction(0, "Kapat", stop)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    /** Konuşma bittiğinde: uyandırma kelimesini tekrar dinle veya servisi kapat. */
    private fun afterIdle() {
        if (engine.isBusy || inCall) return
        if (stopIfUnneeded()) return
        // Bildirim metnini güncelle
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
        wake.wakeWord = settings.wakeWord
        if (!settings.wakeWordEnabled || !ModelDownloader.isReady(this)) {
            wake.stop()
            if (AssistantState.status.value == Status.WAKE_LISTENING) {
                AssistantState.status.value = Status.IDLE
            }
            return
        }
        if (wake.isRunning || wakeLoading) return
        wakeLoading = true
        scope.launch {
            val ok = withContext(Dispatchers.IO) { wake.loadModel() }
            wakeLoading = false
            if (ok && !engine.isBusy && settings.wakeWordEnabled && wake.start()) {
                AssistantState.status.value = Status.WAKE_LISTENING
            }
        }
    }

    /** Uygulama kapalıysa ve uyandırma/duyuru kapalıysa servise gerek yok. */
    private fun stopIfUnneeded(): Boolean {
        val callsNeeded = settings.announceCalls &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) ==
                PackageManager.PERMISSION_GRANTED
        val needed = AssistantState.uiVisible.value || callsNeeded || inCall ||
                settings.wakeWordEnabled || settings.announceMessages || engine.isBusy
        if (!needed) {
            stopSelf()
            return true
        }
        return false
    }

    private fun onWakeWord() {
        if (engine.isBusy) return
        // "Diğer uygulamaların üzerinde göster" izni varsa uygulamayı öne getir
        if (!AssistantState.uiVisible.value && Settings.canDrawOverlays(this)) {
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            } catch (_: Exception) {
            }
        }
        // Vosk mikrofonu bıraksın diye kısa bir bekleme
        main.postDelayed({ engine.startSession() }, 300)
    }

    override fun onDestroy() {
        running = false
        instance = null
        main.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(phoneReceiver)
        } catch (_: Exception) {
        }
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {
        }
        wake.release()
        engine.shutdown()
        scope.cancel()
        AssistantState.status.value = Status.IDLE
        super.onDestroy()
    }

    companion object {
        private const val TAG = "AssistantService"
        private const val NOTIF_ID = 42

        const val ACTION_START = "com.asistan.START"
        const val ACTION_REFRESH = "com.asistan.REFRESH"
        const val ACTION_LISTEN = "com.asistan.LISTEN"
        const val ACTION_TEXT = "com.asistan.TEXT"
        const val ACTION_INTERRUPT = "com.asistan.INTERRUPT"
        const val ACTION_STOP = "com.asistan.STOP"
        const val ACTION_IMAGE = "com.asistan.IMAGE"
        const val EXTRA_TEXT = "text"
        const val EXTRA_PATH = "path"

        @Volatile
        var running = false
            private set

        private var instance: WeakReference<AssistantService>? = null

        // Servis yeniden başlasa da aynı uyarıyı tekrar etmemek için süreç boyunca saklanır
        private var lastBatteryAlert = 101
        private var fullAnnounced = false

        /** Hatırlatıcı gibi duyuruları (asistan çalışıyorsa) sesli okur. */
        fun speakNotice(text: String) {
            val s = instance?.get() ?: return
            s.main.post {
                if (s.engine.isBusy || s.inCall || s.settings.meetingMode) return@post
                s.wake.stop()
                s.engine.speakNotice(text)
            }
        }

        /** Uygulama ekrandayken çağrılmalı (Android arka plandan servis başlatmayı kısıtlar). */
        fun send(ctx: Context, action: String, text: String? = null, path: String? = null) {
            val i = Intent(ctx, AssistantService::class.java).setAction(action)
            if (text != null) i.putExtra(EXTRA_TEXT, text)
            if (path != null) i.putExtra(EXTRA_PATH, path)
            try {
                ContextCompat.startForegroundService(ctx, i)
            } catch (e: Exception) {
                Log.e(TAG, "Servis başlatılamadı", e)
                AssistantState.info.value = "Asistan servisi başlatılamadı: ${e.message}"
            }
        }
    }
}
