package com.asistan.app.phone

import android.app.AlarmManager
import android.content.ComponentName
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.SystemClock
import android.view.KeyEvent
import com.asistan.app.notify.MessageNotificationListener
import kotlin.math.roundToInt

/** Müzik, ses seviyesi, zil modu, fener ve telefon durumu. */
object DeviceControl {

    // ---------------- Müzik ----------------

    private fun activeController(ctx: Context): MediaController? = try {
        val msm = ctx.getSystemService(MediaSessionManager::class.java)
        val sessions = msm.getActiveSessions(ComponentName(ctx, MessageNotificationListener::class.java))
        sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: sessions.firstOrNull()
    } catch (e: SecurityException) {
        null // Bildirim erişimi kapalı
    }

    /** @return kullanıcıya söylenecek sonuç */
    fun media(ctx: Context, action: String): String {
        val c = activeController(ctx)
        if (action == "now_playing") {
            if (c == null) return "Şu an çalan bir şey bulunamadı (veya bildirim erişimi kapalı)."
            val md = c.metadata
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
            val app = appLabel(ctx, c.packageName)
            if (title.isNullOrBlank()) return "$app açık ama şarkı bilgisi yok."
            return "$app: ${artist?.let { "$it – " } ?: ""}$title (${if (playing) "çalıyor" else "duraklatılmış"})"
        }
        if (c != null) {
            val t = c.transportControls
            when (action) {
                "play" -> t.play()
                "pause" -> t.pause()
                "toggle" -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
                "next" -> t.skipToNext()
                "previous" -> t.skipToPrevious()
                else -> return "Bilinmeyen müzik komutu."
            }
            return "${appLabel(ctx, c.packageName)}: komut gönderildi ($action)."
        }
        // Yedek yöntem: kulaklık tuşu gibi medya tuşu gönder
        val key = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "toggle" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "Bilinmeyen müzik komutu."
        }
        val am = ctx.getSystemService(AudioManager::class.java)
        val now = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, key, 0))
        am.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, key, 0))
        return "Medya tuşu gönderildi ($action)."
    }

    // ---------------- Ses ----------------

    private fun streamOf(name: String) = when (name) {
        "ring" -> AudioManager.STREAM_RING
        "alarm" -> AudioManager.STREAM_ALARM
        "call" -> AudioManager.STREAM_VOICE_CALL
        "notification" -> AudioManager.STREAM_NOTIFICATION
        else -> AudioManager.STREAM_MUSIC
    }

    fun setVolume(ctx: Context, streamName: String, percent: Int?, change: String?): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        val s = streamOf(streamName)
        val max = am.getStreamMaxVolume(s)
        when {
            percent != null -> {
                val idx = (percent.coerceIn(0, 100) * max / 100.0).roundToInt()
                am.setStreamVolume(s, idx, AudioManager.FLAG_SHOW_UI)
            }
            change == "up" -> am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            change == "down" -> am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            change == "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            change == "unmute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
            else -> return "Ses seviyesi veya yönü belirtilmedi."
        }
        val now = am.getStreamVolume(s)
        return "Ses (${streamName}) şimdi yüzde ${(now * 100.0 / max).roundToInt()}."
    }

    fun setRingerMode(ctx: Context, mode: String): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.ringerMode = when (mode) {
            "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
            "silent" -> AudioManager.RINGER_MODE_SILENT
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        return "Zil modu: " + when (am.ringerMode) {
            AudioManager.RINGER_MODE_VIBRATE -> "titreşim"
            AudioManager.RINGER_MODE_SILENT -> "sessiz"
            else -> "normal"
        }
    }

    // ---------------- Fener ----------------

    fun torch(ctx: Context, on: Boolean): String {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Bu telefonda fener bulunamadı."
        cm.setTorchMode(id, on)
        return if (on) "Fener açıldı." else "Fener kapatıldı."
    }

    // ---------------- Durum ----------------

    fun status(ctx: Context): String {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        val net = try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            when {
                caps == null -> "internet yok"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobil veri"
                else -> "bağlı"
            }
        } catch (e: Exception) {
            "bilinmiyor"
        }
        val am = ctx.getSystemService(AudioManager::class.java)
        val ringer = when (am.ringerMode) {
            AudioManager.RINGER_MODE_VIBRATE -> "titreşim"
            AudioManager.RINGER_MODE_SILENT -> "sessiz"
            else -> "normal"
        }
        val music = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val nextAlarm = ctx.getSystemService(AlarmManager::class.java).nextAlarmClock?.triggerTime
        return buildString {
            append("Pil: %$battery${if (charging) " (şarj oluyor)" else ""}. ")
            append("Bağlantı: $net. Zil modu: $ringer. Medya sesi: %$music.")
            if (nextAlarm != null) append(" Sıradaki alarm: ${TextUtil.friendlyTime(nextAlarm)}.")
        }
    }

    private fun appLabel(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        "Müzik"
    }
}
