package com.asistan.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class AsistanApp : Application() {

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Asistan dinleme",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Asistan arka planda çalışırken gösterilir"
            setShowBadge(false)
        }
        val reminders = NotificationChannel(
            REMINDER_CHANNEL_ID,
            "Hatırlatıcılar",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Sesle kurduğun hatırlatmalar"
            enableVibration(true)
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
        nm.createNotificationChannel(reminders)
    }

    companion object {
        const val CHANNEL_ID = "asistan_service"
        const val REMINDER_CHANNEL_ID = "asistan_reminders"
    }
}
