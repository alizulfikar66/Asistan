package com.asistan.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.asistan.app.core.AppSettings
import com.asistan.app.core.AssistantService
import com.asistan.app.core.AssistantState
import com.asistan.app.core.ClaudeClient
import com.asistan.app.core.MemoryStore
import com.asistan.app.core.NoteStore
import com.asistan.app.protect.BlockStore
import androidx.compose.material3.Slider
import androidx.compose.runtime.LaunchedEffect
import com.asistan.app.wake.ModelDownloader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun SettingsScreen(settings: AppSettings, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // İzin ekranlarından dönünce durumları yenile
    var refresh by remember { mutableIntStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) refresh++ }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh++ }

    var apiKey by remember { mutableStateOf(settings.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(settings.model) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(settings.userName) }
    var city by remember { mutableStateOf(settings.city) }
    var wakeEnabled by remember { mutableStateOf(settings.wakeWordEnabled) }
    var wakeWord by remember { mutableStateOf(settings.wakeWord) }
    var announce by remember { mutableStateOf(settings.announceMessages) }
    var webSearch by remember { mutableStateOf(settings.webSearch) }
    var announceCalls by remember { mutableStateOf(settings.announceCalls) }
    val memories by MemoryStore.items.collectAsState()
    val notes by NoteStore.items.collectAsState()
    LaunchedEffect(Unit) {
        MemoryStore.load(ctx)
        NoteStore.load(ctx)
    }
    val roleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { refresh++ }
    val blocked by BlockStore.items.collectAsState()
    LaunchedEffect(Unit) { BlockStore.load(ctx) }
    var autoReject by remember { mutableStateOf(settings.autoRejectHighRisk) }
    var silenceRisky by remember { mutableStateOf(settings.silenceRisky) }
    var continuous by remember { mutableStateOf(settings.continuousConversation) }
    var batteryAlerts by remember { mutableStateOf(settings.batteryAlerts) }
    var meetingReply by remember { mutableStateOf(settings.meetingReply) }
    var emergency by remember { mutableStateOf(settings.emergencyContacts) }
    var findCode by remember { mutableStateOf(settings.findCode) }
    var assistantName by remember { mutableStateOf(settings.assistantName) }
    var personality by remember { mutableStateOf(settings.personality) }
    var rate by remember { mutableStateOf(settings.speechRate) }
    var pitch by remember { mutableStateOf(settings.pitch) }
    val progress by AssistantState.modelProgress.collectAsState()
    var modelReady by remember { mutableStateOf(ModelDownloader.isReady(ctx)) }
    var downloadError by remember { mutableStateOf<String?>(null) }

    fun refreshService() = AssistantService.send(ctx, AssistantService.ACTION_REFRESH)

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Palette.bgTop, Palette.bgBottom)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Palette.text)
            }
            Text("Ayarlar", color = Palette.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---------------- Claude ----------------
            Section("1 · Claude API anahtarı") {
                Hint("Asistanın beyni Claude. platform.claude.com adresinden ücretsiz hesap aç, kredi yükle ve bir API anahtarı oluştur (sk-ant- ile başlar).")
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it; settings.apiKey = it },
                    label = { Text("API anahtarı") },
                    singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    colors = fieldColors()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Gizle" else "Göster") }
                    TextButton(onClick = { Perms.openUrl(ctx, "https://console.anthropic.com/settings/keys") }) {
                        Text("Anahtar al")
                    }
                    Spacer(Modifier.weight(1f))
                    Button(
                        enabled = !testing && apiKey.isNotBlank(),
                        onClick = {
                            testing = true
                            testResult = null
                            scope.launch {
                                testResult = try {
                                    withContext(Dispatchers.IO) {
                                        ClaudeClient(settings).createMessage(
                                            "Kısa cevap ver.",
                                            JSONArray().put(JSONObject().put("role", "user").put("content", "Tek kelimeyle merhaba de.")),
                                            null, 30
                                        )
                                    }
                                    "✓ Bağlantı çalışıyor"
                                } catch (e: Exception) {
                                    "✗ ${e.message}"
                                }
                                testing = false
                            }
                        }
                    ) { Text(if (testing) "Deneniyor…" else "Test et") }
                }
                testResult?.let {
                    Text(it, color = if (it.startsWith("✓")) Palette.good else Palette.bad, fontSize = 14.sp)
                }
                Text("Model", color = Palette.text, fontWeight = FontWeight.SemiBold)
                ModelOption("Hızlı (Claude Haiku 5.5) – önerilen, en ucuz", model == AppSettings.MODEL_FAST) {
                    model = AppSettings.MODEL_FAST; settings.model = model
                }
                ModelOption("Akıllı (Claude Sonnet 5.5) – daha yavaş, daha pahalı", model == AppSettings.MODEL_SMART) {
                    model = AppSettings.MODEL_SMART; settings.model = model
                }
            }

            // ---------------- İzinler ----------------
            Section("2 · İzinler") {
                key(refresh) {
                    val missing = Perms.missingRuntime(ctx)
                    Perms.runtime.forEach { p ->
                        PermRow(p.title, p.why, Perms.has(ctx, p.permission)) {
                            permLauncher.launch(Perms.requestSet(p.permission))
                        }
                    }
                    if (missing.isNotEmpty()) {
                        Button(
                            onClick = { permLauncher.launch(missing.toTypedArray()) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Tüm izinleri ver") }
                    }
                    PermRow(
                        "Bildirim erişimi",
                        "WhatsApp, Telegram vb. mesajları okuyup cevaplamak için",
                        Perms.notificationAccess(ctx)
                    ) { Perms.openNotificationAccess(ctx) }
                    PermRow(
                        "Diğer uygulamaların üzerinde göster",
                        "\"Asistan\" deyince uygulamanın öne gelmesi için",
                        Perms.overlay(ctx)
                    ) { Perms.openOverlay(ctx) }
                    PermRow(
                        "Pil kısıtlaması yok",
                        "Uyandırma kelimesinin arka planda kesilmemesi için",
                        Perms.batteryUnrestricted(ctx)
                    ) { Perms.openBattery(ctx) }
                }
                Hint("Bildirim erişimi açılmıyor veya \"kısıtlanmış ayar\" uyarısı çıkıyorsa: Uygulama bilgisi ekranında sağ üstteki ⋮ menüsünden \"Kısıtlanmış ayarlara izin ver\"i seç, sonra tekrar dene.")
                OutlinedButton(onClick = { Perms.openAppDetails(ctx) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Uygulama bilgisini aç")
                }
            }

            // ---------------- Uyandırma ----------------
            Section("3 · Uyandırma kelimesi") {
                SwitchRow(
                    "\"${wakeWord.replaceFirstChar { it.uppercase() }}\" deyince dinlemeye başla",
                    "Telefon içinde, internetsiz çalışır. Pil tüketimini biraz artırır.",
                    wakeEnabled
                ) {
                    wakeEnabled = it; settings.wakeWordEnabled = it; refreshService()
                }
                OutlinedTextField(
                    value = wakeWord,
                    onValueChange = { v ->
                        wakeWord = v.take(30)
                        if (v.isNotBlank()) settings.wakeWord = v.trim()
                    },
                    label = { Text("Uyandırma kelimesi") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = fieldColors()
                )
                Hint("Uzun ve günlük konuşmada az geçen bir kelime seç (ör. \"asistan\", \"hey asistan\", \"bilge\").")
                if (modelReady) {
                    Text("✓ Türkçe ses modeli hazır", color = Palette.good, fontSize = 14.sp)
                } else {
                    val p = progress
                    if (p != null) {
                        Text("Ses modeli indiriliyor… %$p", color = Palette.text, fontSize = 14.sp)
                        LinearProgressIndicator(progress = { p / 100f }, modifier = Modifier.fillMaxWidth())
                    } else {
                        Hint("Uyandırma için bir kerelik ~35 MB Türkçe ses modeli indirilmeli (Wi-Fi önerilir).")
                        Button(
                            onClick = {
                                downloadError = null
                                AssistantState.modelProgress.value = 0
                                scope.launch {
                                    try {
                                        ModelDownloader.download(ctx) { AssistantState.modelProgress.value = it }
                                        modelReady = true
                                        refreshService()
                                    } catch (e: Exception) {
                                        downloadError = e.message ?: "İndirme başarısız"
                                    } finally {
                                        AssistantState.modelProgress.value = null
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Ses modelini indir") }
                    }
                    downloadError?.let { Text("✗ $it", color = Palette.bad, fontSize = 14.sp) }
                }
            }

            // ---------------- Mesajlar ve özellikler ----------------
            Section("🗣️ Sohbet ve günlük kullanım") {
                SwitchRow(
                    "Kesintisiz sohbet",
                    "Uyandırma kelimesini veya küreyi kullandıktan sonra her cevaptan sonra dinlemeye devam eder. \"Asistan kapan\", \"görüşürüz\" veya \"bu kadar\" deyince kapanır; bir süre konuşmazsan da kendiliğinden kapanır.",
                    continuous
                ) { continuous = it; settings.continuousConversation = it }
                SwitchRow(
                    "Şarj uyarıları",
                    "Şarj %20, %10 ve %5'e düşünce sesli uyarır; şarj dolunca haber verir.",
                    batteryAlerts
                ) { batteryAlerts = it; settings.batteryAlerts = it; refreshService() }
                Text("🤝 Toplantı modu", color = Palette.text, fontWeight = FontWeight.SemiBold)
                Hint("\"Toplantıya giriyorum\" dediğinde telefon sessize alınır, aramalar sesli duyurulmaz ve rehberindeki arayanlara aşağıdaki mesaj gönderilir. \"Toplantı bitti\" deyince normale döner ve kaçırdığın aramaları söyler.")
                OutlinedTextField(
                    value = meetingReply, onValueChange = { meetingReply = it; settings.meetingReply = it },
                    label = { Text("Otomatik cevap mesajı") },
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                )
                key(refresh) {
                    PermRow(
                        "Rahatsız Etmeyin erişimi",
                        "\"Sessize al\" komutunun telefonu tam sessize alabilmesi için",
                        Perms.dndAccess(ctx)
                    ) { Perms.openDndAccess(ctx) }
                }
            }

            Section("4 · Özellikler") {
                SwitchRow(
                    "Gelen aramaları sesli söyle",
                    "\"Annen arıyor, açayım mı?\" der. \"Aç\", \"reddet\" veya \"reddet ve toplantıdayım yaz\" diyebilirsin.",
                    announceCalls
                ) { announceCalls = it; settings.announceCalls = it; refreshService() }
                SwitchRow(
                    "Gelen mesajları sesli oku",
                    "WhatsApp, SMS vb. yeni mesaj gelince okur ve cevap vermek isteyip istemediğini sorar.",
                    announce
                ) { announce = it; settings.announceMessages = it; refreshService() }
                SwitchRow(
                    "İnternette arama",
                    "Hava durumu, haberler, döviz gibi güncel bilgiler için (arama başına küçük ek ücret).",
                    webSearch
                ) { webSearch = it; settings.webSearch = it }
            }

            Section("5 · Seni tanıyayım") {
                OutlinedTextField(
                    value = name, onValueChange = { name = it; settings.userName = it },
                    label = { Text("Adın (isteğe bağlı)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                )
                OutlinedTextField(
                    value = city, onValueChange = { city = it; settings.city = it },
                    label = { Text("Şehrin (hava durumu için)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                )
            }

            Section("6 · Hafıza") {
                if (memories.isEmpty()) {
                    Hint("Henüz bir şey hatırlamıyorum. \"Bunu hatırla: arabayı B2 katına park ettim\" diyerek bilgi ekleyebilirsin.")
                } else {
                    Hint("Asistanın senin hakkında hatırladıkları. İstemediğini silebilirsin.")
                    memories.forEach { m ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(m.text, color = Palette.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { MemoryStore.remove(ctx, m.id) }) { Text("Sil") }
                        }
                    }
                }
            }

            Section("🖐️ Ekran kontrolü") {
                Hint("Asistanın ekrandaki düğmelere basması, yazı yazması, kaydırması ve menülerde gezinmesi için gerekir. Örnek: \"Wi-Fi'yi kapat\", \"İzin ver'e bas\", \"Aşağı kaydır\", \"Geri git\", \"Ekranı kilitle\", \"WhatsApp'ta Ahmet'e 'geliyorum' yaz\".")
                key(refresh) {
                    val on = Perms.accessibilityEnabled(ctx)
                    PermRow(
                        "Ekran kontrolü",
                        if (on) "Açık — asistan ekranı yönetebilir" else "Kapalı",
                        on
                    ) { Perms.openAccessibility(ctx) }
                    if (!on) {
                        Button(onClick = { Perms.openAccessibility(ctx) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Erişilebilirlik ayarlarını aç")
                        }
                        Hint("Açılan ekranda \"Yüklü uygulamalar\" (veya \"İndirilen uygulamalar\") altında \"Asistan ekran kontrolü\"nü bul ve aç. Gri ve açılmıyorsa: 2. bölümdeki \"Uygulama bilgisini aç\" → ⋮ → \"Kısıtlanmış ayarlara izin ver\", sonra tekrar dene.")
                    }
                }
                Hint("🔒 Asistan geri alınamaz düğmelerden (Gönder, Sil, Öde) önce sana sorar; banka uygulamalarında para işlemi yapmaz ve şifre yazmaz.")
            }

            Section("🛡️ Arama koruması") {
                Hint("Rehberinde olmayan numaralar (0850, 0212, 0216, 0888, 0900, 444, gizli numara, yurt dışı) aradığında risk analizi yapar ve telefon çalarken seni uyarır. \"Engelle\" dersen o numara bir daha çaldırmaz.")
                key(refresh) {
                    val held = Perms.screeningRoleHeld(ctx)
                    PermRow(
                        "Arama filtreleme",
                        if (held) "Açık — numaralar çalmadan önce inceleniyor" else "Kapalı — engelleme için gerekli",
                        held
                    ) {
                        Perms.screeningRoleIntent(ctx)?.let { roleLauncher.launch(it) }
                    }
                    if (!held) {
                        Button(
                            onClick = {
                                val i = Perms.screeningRoleIntent(ctx)
                                if (i != null) roleLauncher.launch(i)
                                else AssistantState.info.value = "Arama filtreleme Android 10 ve üzerinde çalışır."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Asistan'ı arama filtreleme uygulaması yap") }
                    }
                }
                SwitchRow(
                    "Yüksek riskli aramaları otomatik reddet",
                    "Engellediğin numaralar, 0900 ve dolandırıcılıkta sık kullanılan yurt dışı kodları hiç çaldırmaz; sadece bildirim gelir.",
                    autoReject
                ) { autoReject = it; settings.autoRejectHighRisk = it }
                SwitchRow(
                    "Şüpheli aramaları sessiz çaldır",
                    "Gizli numara ve yurt dışı aramaları sessiz gelir; asistan yine de söyler.",
                    silenceRisky
                ) { silenceRisky = it; settings.silenceRisky = it }
                if (blocked.isNotEmpty()) {
                    Text("Engellenen numaralar", color = Palette.text, fontWeight = FontWeight.SemiBold)
                    blocked.forEach { b ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(b.number, color = Palette.text, fontSize = 14.sp)
                                if (b.label.isNotBlank()) Text(b.label, color = Palette.textDim, fontSize = 12.sp)
                            }
                            TextButton(onClick = { BlockStore.remove(ctx, b.number) }) { Text("Kaldır") }
                        }
                    }
                }
            }

            Section("📝 Notlar") {
                if (notes.isEmpty()) {
                    Hint("\"Not al: yarın faturayı öde\" diyerek not ekleyebilirsin.")
                } else {
                    notes.sortedByDescending { it.created }.forEach { n ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(n.text, color = Palette.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { NoteStore.remove(ctx, n.id) }) { Text("Sil") }
                        }
                    }
                }
            }

            Section("🆘 Güvenlik") {
                Text("🆘 Acil durum kişileri", color = Palette.text, fontWeight = FontWeight.SemiBold)
                Hint("\"Yardım!\" dediğinde konumunla birlikte SMS gidecek kişiler. Rehberdeki adları veya numaraları virgülle ayır.")
                OutlinedTextField(
                    value = emergency, onValueChange = { emergency = it; settings.emergencyContacts = it },
                    label = { Text("Ör: Annem, Ahmet Yılmaz, 05321234567") },
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                )
                Text("🔎 Telefonumu bul", color = Palette.text, fontWeight = FontWeight.SemiBold)
                Hint("Telefonun kaybolursa başka bir telefondan bu kodu SMS ile gönder: telefon sessizde bile yüksek sesle çalar ve konumunu sana SMS ile yollar. En az 4 karakter, tahmin edilmesi zor bir kod seç. Boş bırakırsan kapalı olur.")
                OutlinedTextField(
                    value = findCode, onValueChange = { findCode = it; settings.findCode = it },
                    label = { Text("Gizli kod (ör. KAYIP-4821)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                )
                if (findCode.isNotBlank() && findCode.trim().length < 4) {
                    Text("Kod en az 4 karakter olmalı.", color = Palette.bad, fontSize = 13.sp)
                }
            }

            Section("🎭 Kişilik ve ses") {
                OutlinedTextField(
                    value = assistantName, onValueChange = { assistantName = it; settings.assistantName = it },
                    label = { Text("Asistanın adı") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                )
                Hint("Uyandırma kelimesini de aynı ad yapmak istersen yukarıdaki 3. bölümden değiştir.")
                Text("Konuşma tarzı", color = Palette.text, fontWeight = FontWeight.SemiBold)
                listOf("samimi" to "Samimi 😊", "ciddi" to "Ciddi 🎩", "esprili" to "Esprili 😄").forEach { (key, label) ->
                    ModelOption(label, personality == key) { personality = key; settings.personality = key }
                }
                Text("Konuşma hızı: ${"%.1f".format(rate)}x", color = Palette.text, fontSize = 14.sp)
                Slider(
                    value = rate, onValueChange = { rate = it; settings.speechRate = it },
                    valueRange = 0.6f..1.6f
                )
                Text("Ses tonu: ${"%.1f".format(pitch)}", color = Palette.text, fontSize = 14.sp)
                Slider(
                    value = pitch, onValueChange = { pitch = it; settings.pitch = it },
                    valueRange = 0.6f..1.5f
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        AssistantService.speakNotice("Merhaba, ben ${settings.assistantName}. Sesim böyle.")
                    }) { Text("Sesi dene") }
                    OutlinedButton(onClick = { Perms.openTtsSettings(ctx) }) { Text("Ses motoru") }
                }
                Hint("Farklı bir ses (kadın/erkek) için \"Ses motoru\"ndan Google Konuşma Hizmetleri'nde Türkçe sesleri inceleyebilirsin.")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Palette.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, color = Palette.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        content(this)
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Palette.textDim, fontSize = 13.sp, lineHeight = 18.sp)
}

@Composable
private fun ModelOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, color = Palette.text, fontSize = 14.sp)
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Palette.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = Palette.textDim, fontSize = 13.sp, lineHeight = 17.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PermRow(title: String, why: String, granted: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            Icons.Filled.Check, contentDescription = null,
            tint = if (granted) Palette.good else Palette.textDim.copy(alpha = 0.3f),
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(Palette.surfaceHigh)
                .padding(4.dp)
        )
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, color = Palette.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(why, color = Palette.textDim, fontSize = 12.sp)
        }
        if (!granted) {
            TextButton(onClick = onGrant) { Text("Ver") }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Palette.violet,
    unfocusedBorderColor = Palette.surfaceHigh,
    focusedTextColor = Palette.text,
    unfocusedTextColor = Palette.text,
    focusedLabelColor = Palette.violet,
    unfocusedLabelColor = Palette.textDim
)
