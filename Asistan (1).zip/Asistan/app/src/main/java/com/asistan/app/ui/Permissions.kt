package com.asistan.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

data class RuntimePerm(val permission: String, val title: String, val why: String)

object Perms {

    val runtime: List<RuntimePerm> = buildList {
        add(RuntimePerm(Manifest.permission.RECORD_AUDIO, "Mikrofon", "Seni duyabilmek için"))
        add(RuntimePerm(Manifest.permission.READ_CONTACTS, "Rehber", "\"Annemi ara\" diyebilmen için"))
        add(RuntimePerm(Manifest.permission.CALL_PHONE, "Telefon araması", "Arama başlatmak için"))
        add(RuntimePerm(Manifest.permission.READ_SMS, "SMS okuma", "Mesajlarını okuyabilmek için"))
        add(RuntimePerm(Manifest.permission.SEND_SMS, "SMS gönderme", "Senin adına SMS atmak için"))
        add(RuntimePerm(Manifest.permission.READ_PHONE_STATE, "Telefon durumu", "Gelen aramayı fark etmek için"))
        add(RuntimePerm(Manifest.permission.READ_CALL_LOG, "Arama geçmişi", "Arayanın kim olduğunu ve cevapsız aramaları söylemek için"))
        add(RuntimePerm(Manifest.permission.ANSWER_PHONE_CALLS, "Aramaları yanıtlama", "\"Aç\" veya \"reddet\" diyebilmen için"))
        add(RuntimePerm(Manifest.permission.ACCESS_FINE_LOCATION, "Konum", "\"Neredeyim?\", acil durum ve kayıp telefon için"))
        add(RuntimePerm(Manifest.permission.RECEIVE_SMS, "SMS alma", "\"Telefonumu bul\" kodunu yakalamak için"))
        add(RuntimePerm(Manifest.permission.READ_CALENDAR, "Takvim okuma", "\"Bugün ne işim var?\" için"))
        add(RuntimePerm(Manifest.permission.WRITE_CALENDAR, "Takvime yazma", "Etkinlik ekleyebilmek için"))
        if (Build.VERSION.SDK_INT >= 33) {
            add(RuntimePerm(Manifest.permission.POST_NOTIFICATIONS, "Bildirimler", "Arka planda çalıştığını göstermek için"))
        }
    }

    fun has(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    /** Android 12+ hassas konumu yaklaşık konumla birlikte istemeyi zorunlu tutar. */
    fun requestSet(permission: String): Array<String> =
        if (permission == Manifest.permission.ACCESS_FINE_LOCATION)
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        else arrayOf(permission)

    fun missingRuntime(ctx: Context): List<String> =
        runtime.map { it.permission }.filterNot { has(ctx, it) }.flatMap { requestSet(it).toList() }

    fun notificationAccess(ctx: Context) =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun overlay(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun accessibilityEnabled(ctx: Context): Boolean {
        if (com.asistan.app.control.ScreenControlService.isEnabled) return true
        val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.startsWith(ctx.packageName + "/") }
    }

    fun dndAccess(ctx: Context) =
        ctx.getSystemService(android.app.NotificationManager::class.java).isNotificationPolicyAccessGranted

    fun openDndAccess(ctx: Context) = open(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))

    fun openAccessibility(ctx: Context) = open(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    fun screeningRoleHeld(ctx: Context): Boolean = try {
        Build.VERSION.SDK_INT >= 29 &&
                ctx.getSystemService(android.app.role.RoleManager::class.java)
                    .isRoleHeld(android.app.role.RoleManager.ROLE_CALL_SCREENING)
    } catch (_: Exception) {
        false
    }

    fun screeningRoleIntent(ctx: Context): Intent? = try {
        if (Build.VERSION.SDK_INT >= 29)
            ctx.getSystemService(android.app.role.RoleManager::class.java)
                .createRequestRoleIntent(android.app.role.RoleManager.ROLE_CALL_SCREENING)
        else null
    } catch (_: Exception) {
        null
    }

    fun batteryUnrestricted(ctx: Context) =
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

    fun openNotificationAccess(ctx: Context) =
        open(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    fun openOverlay(ctx: Context) =
        open(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))

    fun openBattery(ctx: Context) =
        open(ctx, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))

    fun openAppDetails(ctx: Context) =
        open(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))

    fun openTtsSettings(ctx: Context) = open(ctx, Intent("com.android.settings.TTS_SETTINGS"))

    fun openUrl(ctx: Context, url: String) = open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun open(ctx: Context, i: Intent) {
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }
}
