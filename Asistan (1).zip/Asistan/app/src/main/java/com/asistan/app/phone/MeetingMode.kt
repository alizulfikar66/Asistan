package com.asistan.app.phone

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import androidx.core.content.ContextCompat
import com.asistan.app.core.AppSettings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Toplantı modu: telefon sessize alınır, gelen aramalar duyurulmaz;
 * rehberdeki biri ararsa ona otomatik "toplantıdayım" SMS'i gider.
 * Bitince kaçırılan aramaların özeti verilir.
 */
object MeetingMode {

    data class Missed(val number: String?, val name: String?, val replied: Boolean, val time: Long)

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("asistan_meeting", Context.MODE_PRIVATE)

    fun isOn(ctx: Context) = AppSettings(ctx).meetingMode

    /** Zil modunu ayarlar. Tam sessize izin yoksa titreşime alır. @return söylenecek cümle */
    fun setRinger(ctx: Context, mode: Int): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        return try {
            am.ringerMode = mode
            when (mode) {
                AudioManager.RINGER_MODE_SILENT -> "Telefonu sessize aldım."
                AudioManager.RINGER_MODE_VIBRATE -> "Telefonu titreşime aldım."
                else -> "Telefonu normal moda aldım, zil sesi açık."
            }
        } catch (e: SecurityException) {
            if (mode == AudioManager.RINGER_MODE_SILENT) {
                try {
                    am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                } catch (_: Exception) {
                }
                "Tam sessize almak için Rahatsız Etmeyin erişimi gerekiyor, şimdilik titreşime aldım. Ayarlar'dan bu izni verebilirsin."
            } else {
                "Zil modunu değiştiremedim. Ayarlar'dan Rahatsız Etmeyin erişimini vermen gerekebilir."
            }
        }
    }

    fun start(ctx: Context): String {
        val s = AppSettings(ctx)
        if (s.meetingMode) return "Zaten toplantı modundasın."
        val am = ctx.getSystemService(AudioManager::class.java)
        s.ringerBeforeMeeting = am.ringerMode
        prefs(ctx).edit().putString("missed", "[]").apply()
        s.meetingMode = true
        com.asistan.app.core.AssistantState.meetingOn.value = true
        val r = setRinger(ctx, AudioManager.RINGER_MODE_SILENT)
        val sms = if (canSms(ctx)) " Rehberindeki biri ararsa ona toplantıda olduğunu yazacağım." else ""
        return "Toplantı modu açık. $r$sms İyi toplantılar!"
    }

    fun end(ctx: Context): String {
        val s = AppSettings(ctx)
        if (!s.meetingMode) return "Toplantı modu zaten kapalı."
        s.meetingMode = false
        com.asistan.app.core.AssistantState.meetingOn.value = false
        val before = s.ringerBeforeMeeting.takeIf { it >= 0 } ?: AudioManager.RINGER_MODE_NORMAL
        setRinger(ctx, if (before == AudioManager.RINGER_MODE_SILENT) AudioManager.RINGER_MODE_NORMAL else before)
        val missed = missed(ctx)
        if (missed.isEmpty()) return "Toplantı modu kapandı, telefonun normale döndü. Bu sürede arayan olmadı."
        val names = missed.map { it.name ?: it.number ?: "gizli numara" }.distinct()
        val replied = missed.filter { it.replied }.mapNotNull { it.name }.distinct()
        return buildString {
            append("Toplantı modu kapandı. Bu sürede ${missed.size} arama kaçırdın: ${names.joinToString(", ")}.")
            if (replied.isNotEmpty()) append(" ${replied.joinToString(", ")} kişisine toplantıda olduğunu yazdım.")
            append(" Geri aramamı ister misin?")
        }
    }

    /** Toplantı sırasında cevapsız kalan arama. */
    fun onMissedCall(ctx: Context, number: String?) {
        if (!isOn(ctx)) return
        val name = number?.let {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
                Contacts.nameForNumber(ctx, it) else null
        }
        var replied = false
        // Sadece rehberdeki kişilere cevap ver (dolandırıcılara numaranın aktif olduğunu belli etme)
        if (number != null && name != null && canSms(ctx)) {
            try {
                Sms.send(ctx, number, AppSettings(ctx).meetingReply)
                replied = true
            } catch (_: Exception) {
            }
        }
        val arr = JSONArray(prefs(ctx).getString("missed", "[]") ?: "[]")
        arr.put(
            JSONObject().put("number", number ?: JSONObject.NULL).put("name", name ?: JSONObject.NULL)
                .put("replied", replied).put("time", System.currentTimeMillis())
        )
        prefs(ctx).edit().putString("missed", arr.toString()).apply()
    }

    fun missed(ctx: Context): List<Missed> {
        val arr = JSONArray(prefs(ctx).getString("missed", "[]") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Missed(
                o.optString("number").takeIf { s -> s.isNotBlank() && s != "null" },
                o.optString("name").takeIf { s -> s.isNotBlank() && s != "null" },
                o.optBoolean("replied"),
                o.optLong("time")
            )
        }
    }

    private fun canSms(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
}
