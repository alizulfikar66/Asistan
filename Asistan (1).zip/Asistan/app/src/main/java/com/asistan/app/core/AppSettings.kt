package com.asistan.app.core

import android.content.Context

/** Kullanıcı ayarları. Telefonun içinde, yalnızca bu uygulamanın erişebildiği yerde saklanır. */
class AppSettings(context: Context) {

    private val p = context.applicationContext
        .getSharedPreferences("asistan_settings", Context.MODE_PRIVATE)

    var apiKey: String
        get() = p.getString("api_key", "") ?: ""
        set(v) = p.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = p.getString("model", MODEL_FAST) ?: MODEL_FAST
        set(v) = p.edit().putString("model", v).apply()

    var userName: String
        get() = p.getString("user_name", "") ?: ""
        set(v) = p.edit().putString("user_name", v).apply()

    var city: String
        get() = p.getString("city", "") ?: ""
        set(v) = p.edit().putString("city", v).apply()

    var wakeWordEnabled: Boolean
        get() = p.getBoolean("wake_enabled", false)
        set(v) = p.edit().putBoolean("wake_enabled", v).apply()

    var wakeWord: String
        get() = p.getString("wake_word", "asistan") ?: "asistan"
        set(v) = p.edit().putString("wake_word", v).apply()

    var announceMessages: Boolean
        get() = p.getBoolean("announce", false)
        set(v) = p.edit().putBoolean("announce", v).apply()

    var announceCalls: Boolean
        get() = p.getBoolean("announce_calls", true)
        set(v) = p.edit().putBoolean("announce_calls", v).apply()

    // ---- Kişilik ----
    var assistantName: String
        get() = p.getString("assistant_name", "Asistan")?.ifBlank { "Asistan" } ?: "Asistan"
        set(v) = p.edit().putString("assistant_name", v.trim()).apply()

    /** samimi | ciddi | esprili */
    var personality: String
        get() = p.getString("personality", "samimi") ?: "samimi"
        set(v) = p.edit().putString("personality", v).apply()

    var speechRate: Float
        get() = p.getFloat("speech_rate", 1.05f)
        set(v) = p.edit().putFloat("speech_rate", v).apply()

    var pitch: Float
        get() = p.getFloat("pitch", 1.0f)
        set(v) = p.edit().putFloat("pitch", v).apply()

    // ---- Güvenlik ----
    /** Acil durumda konum gönderilecek kişiler: "Annem, Ahmet, 05321234567" */
    var emergencyContacts: String
        get() = p.getString("emergency_contacts", "") ?: ""
        set(v) = p.edit().putString("emergency_contacts", v).apply()

    /** "Telefonumu bul" SMS kodu. Boşsa özellik kapalı. */
    var findCode: String
        get() = p.getString("find_code", "") ?: ""
        set(v) = p.edit().putString("find_code", v.trim()).apply()

    // ---- Arama koruması ----
    /** Engellenen ve yüksek riskli (0900, riskli yurt dışı) aramaları otomatik reddet */
    var autoRejectHighRisk: Boolean
        get() = p.getBoolean("auto_reject_high", true)
        set(v) = p.edit().putBoolean("auto_reject_high", v).apply()

    /** Şüpheli aramaları (gizli numara, yurt dışı) sessiz çaldır */
    var silenceRisky: Boolean
        get() = p.getBoolean("silence_risky", false)
        set(v) = p.edit().putBoolean("silence_risky", v).apply()

    // ---- Sohbet ve günlük kullanım ----
    /** "Asistan" dedikten sonra her cevaptan sonra otomatik dinlemeye devam et */
    var continuousConversation: Boolean
        get() = p.getBoolean("continuous", true)
        set(v) = p.edit().putBoolean("continuous", v).apply()

    var batteryAlerts: Boolean
        get() = p.getBoolean("battery_alerts", true)
        set(v) = p.edit().putBoolean("battery_alerts", v).apply()

    var meetingMode: Boolean
        get() = p.getBoolean("meeting_mode", false)
        set(v) = p.edit().putBoolean("meeting_mode", v).apply()

    var meetingReply: String
        get() = p.getString("meeting_reply", DEFAULT_MEETING_REPLY)?.ifBlank { DEFAULT_MEETING_REPLY } ?: DEFAULT_MEETING_REPLY
        set(v) = p.edit().putString("meeting_reply", v).apply()

    /** Toplantı modunu açmadan önceki zil modu (bitince geri yüklenir) */
    var ringerBeforeMeeting: Int
        get() = p.getInt("ringer_before_meeting", -1)
        set(v) = p.edit().putInt("ringer_before_meeting", v).apply()

    var webSearch: Boolean
        get() = p.getBoolean("web_search", true)
        set(v) = p.edit().putBoolean("web_search", v).apply()

    companion object {
        const val MODEL_FAST = "claude-haiku-5-5"
        const val MODEL_SMART = "claude-sonnet-5-5"
        const val DEFAULT_MEETING_REPLY = "Şu an toplantıdayım, en kısa sürede size dönüş yapacağım."
    }
}
