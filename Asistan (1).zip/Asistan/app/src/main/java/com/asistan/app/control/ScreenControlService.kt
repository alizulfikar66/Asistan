package com.asistan.app.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.asistan.app.phone.TextUtil
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Asistanın "elleri": erişilebilirlik servisi sayesinde ekrandaki düğmeleri okur,
 * dokunur, yazı yazar, kaydırır; geri/ana ekran/kilit gibi sistem tuşlarına basar.
 * Kullanıcının Ayarlar > Erişilebilirlik'ten açması gerekir.
 */
class ScreenControlService : AccessibilityService() {

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ------------------------------------------------------------------
    // Ekranı okuma
    // ------------------------------------------------------------------

    private data class Element(val node: AccessibilityNodeInfo, val desc: String)

    @Volatile
    private var lastElements: List<Element> = emptyList()

    /** Ekrandaki etkileşimli ve okunabilir öğeleri numaralı liste olarak döndürür. */
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "Ekran okunamadı (kilit ekranı veya güvenli bir uygulama olabilir)."
        val list = mutableListOf<Element>()
        collect(root, list, 0)
        lastElements = list
        val app = root.packageName?.toString() ?: "?"
        if (list.isEmpty()) return "Uygulama: $app. Ekranda okunabilir öğe bulunamadı."
        val sb = StringBuilder("Uygulama: ${appLabel(app)} ($app)\n")
        list.forEachIndexed { i, e -> sb.append("[$i] ${e.desc}\n") }
        if (list.size >= MAX_ELEMENTS) sb.append("(Liste kısaltıldı; daha fazlası için kaydır.)")
        return sb.toString().trim()
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<Element>, depth: Int) {
        if (node == null || out.size >= MAX_ELEMENTS || depth > 40) return
        if (node.isVisibleToUser) {
            val text = node.text?.toString()?.trim().orEmpty()
            val cd = node.contentDescription?.toString()?.trim().orEmpty()
            val hint = if (Build.VERSION.SDK_INT >= 26) node.hintText?.toString()?.trim().orEmpty() else ""
            val label = listOf(text, cd).filter { it.isNotEmpty() }.distinct().joinToString(" / ").take(90)
            val cls = node.className?.toString().orEmpty()
            val kind = when {
                node.isEditable -> "Metin kutusu"
                node.isCheckable || cls.endsWith("Switch") || cls.endsWith("CheckBox") ->
                    "Anahtar (${if (node.isChecked) "AÇIK" else "KAPALI"})"
                node.isClickable || node.isLongClickable -> if (cls.endsWith("Button") || cls.endsWith("ImageButton")) "Düğme" else "Tıklanabilir"
                node.isScrollable -> "Kaydırılabilir alan"
                label.isNotEmpty() -> "Yazı"
                else -> null
            }
            if (kind != null && (label.isNotEmpty() || node.isEditable || node.isScrollable)) {
                val extra = if (node.isEditable && label.isEmpty() && hint.isNotEmpty()) " (ipucu: ${hint.take(60)})" else ""
                out.add(Element(node, "$kind: ${if (label.isNotEmpty()) "'$label'" else "(etiketsiz)"}$extra"))
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out, depth + 1)
    }

    // ------------------------------------------------------------------
    // Eylemler
    // ------------------------------------------------------------------

    /** Numara ([index]) veya görünen yazıya ([text]) göre bir öğeye dokunur. */
    fun tap(index: Int?, text: String?, longPress: Boolean = false): String {
        val el = find(index, text) ?: return notFound(text)
        var n: AccessibilityNodeInfo? = el.node
        val action = if (longPress) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
        // Kendisi tıklanamıyorsa tıklanabilir bir üst öğe bul
        var hops = 0
        while (n != null && hops < 6) {
            if ((if (longPress) n.isLongClickable else n.isClickable) && n.performAction(action)) {
                return "Dokunuldu: ${el.desc}"
            }
            n = n.parent
            hops++
        }
        // Son çare: ekranda o noktaya parmakla dokun
        val r = Rect()
        el.node.getBoundsInScreen(r)
        return if (gestureTap(r.exactCenterX(), r.exactCenterY(), if (longPress) 700L else 60L))
            "Dokunuldu (hareketle): ${el.desc}" else "Dokunulamadı: ${el.desc}"
    }

    /** Metin kutusuna yazar. index/text verilmezse odaktaki veya ilk metin kutusunu kullanır. */
    fun typeText(index: Int?, target: String?, value: String): String {
        val node: AccessibilityNodeInfo? = when {
            index != null || !target.isNullOrBlank() -> find(index, target)?.node
            else -> rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: lastElements.firstOrNull { it.node.isEditable }?.node
                ?: run { readScreen(); lastElements.firstOrNull { it.node.isEditable }?.node }
        }
        if (node == null) return "Yazı yazılacak bir metin kutusu bulunamadı."
        if (!node.isEditable) return "Seçilen öğe bir metin kutusu değil."
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Yazıldı." else "Yazılamadı."
    }

    fun scroll(direction: String): String {
        val root = rootInActiveWindow ?: return "Ekran okunamadı."
        val scrollable = findLargestScrollable(root)
        val forward = direction == "down" || direction == "right"
        if (scrollable != null) {
            val ok = scrollable.performAction(
                if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            )
            if (ok) return "Kaydırıldı ($direction)."
        }
        // Hareketle kaydır
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val ok = when (direction) {
            "up" -> gestureSwipe(w / 2, h * 0.3f, w / 2, h * 0.75f)
            "left" -> gestureSwipe(w * 0.2f, h / 2, w * 0.8f, h / 2)
            "right" -> gestureSwipe(w * 0.8f, h / 2, w * 0.2f, h / 2)
            else -> gestureSwipe(w / 2, h * 0.75f, w / 2, h * 0.3f)
        }
        return if (ok) "Kaydırıldı ($direction)." else "Kaydırılamadı."
    }

    fun global(action: String): String {
        val a = when (action) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "power_menu" -> GLOBAL_ACTION_POWER_DIALOG
            "lock_screen" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return "Ekran kilitleme Android 9+ gerektirir."
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return "Ekran görüntüsü Android 9+ gerektirir."
            else -> return "Bilinmeyen sistem eylemi: $action"
        }
        return if (performGlobalAction(a)) "Yapıldı: $action" else "Yapılamadı: $action"
    }

    // ------------------------------------------------------------------
    // Yardımcılar
    // ------------------------------------------------------------------

    private fun find(index: Int?, text: String?): Element? {
        if (index != null) {
            lastElements.getOrNull(index)?.let { if (it.node.refresh()) return it }
        }
        if (!text.isNullOrBlank()) {
            val q = TextUtil.normalize(text)
            readScreen()
            val els = lastElements
            return els.firstOrNull { TextUtil.normalize(label(it)) == q }
                ?: els.firstOrNull { TextUtil.normalize(label(it)).contains(q) }
        }
        return null
    }

    private fun label(e: Element): String {
        val t = e.node.text?.toString().orEmpty()
        val c = e.node.contentDescription?.toString().orEmpty()
        return "$t $c"
    }

    private fun notFound(text: String?) =
        "Öğe bulunamadı${if (!text.isNullOrBlank()) ": '$text'" else ""}. Önce read_screen ile ekrana bak."

    private fun findLargestScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            if (n.isScrollable && n.isVisibleToUser) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val area = r.width() * r.height()
                if (area > bestArea) {
                    bestArea = area
                    best = n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return best
    }

    private fun gestureTap(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply { moveTo(x, y) }
        return dispatch(GestureDescription.StrokeDescription(path, 0, durationMs))
    }

    private fun gestureSwipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        return dispatch(GestureDescription.StrokeDescription(path, 0, 350))
    }

    /** Hareketi gönderir ve bitmesini bekler (arka plan iş parçacığında çağrılmalı). */
    private fun dispatch(stroke: GestureDescription.StrokeDescription): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val sent = dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok = true
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null
        )
        if (!sent) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    companion object {
        private const val MAX_ELEMENTS = 70

        @Volatile
        var instance: ScreenControlService? = null
            private set

        val isEnabled: Boolean get() = instance != null
    }
}
