package com.asistan.app.phone

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.provider.CallLog
import android.telecom.TelecomManager

data class CallLogItem(
    val number: String,
    val name: String?,
    val type: Int,
    val date: Long,
    val durationSec: Long
)

/** Gelen aramayı açma/reddetme, arama geçmişi ve çalarken zil sesini kısma. */
object CallHelper {

    @SuppressLint("MissingPermission")
    fun answer(ctx: Context) {
        val tm = ctx.getSystemService(TelecomManager::class.java)
        @Suppress("DEPRECATION")
        tm.acceptRingingCall()
    }

    /** Çalan aramayı reddeder veya devam eden aramayı kapatır. Android 9+ gerekir. */
    @SuppressLint("MissingPermission")
    fun endCall(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 28) return false
        val tm = ctx.getSystemService(TelecomManager::class.java)
        @Suppress("DEPRECATION")
        return tm.endCall()
    }

    fun log(ctx: Context, count: Int, missedOnly: Boolean): List<CallLogItem> {
        val result = mutableListOf<CallLogItem>()
        val selection = if (missedOnly) "${CallLog.Calls.TYPE} = ${CallLog.Calls.MISSED_TYPE}" else null
        ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE,
                CallLog.Calls.DATE, CallLog.Calls.DURATION
            ),
            selection, null, "${CallLog.Calls.DATE} DESC"
        )?.use { c ->
            while (c.moveToNext() && result.size < count) {
                val number = c.getString(0) ?: ""
                val name = c.getString(1)?.takeIf { it.isNotBlank() }
                result.add(CallLogItem(number, name, c.getInt(2), c.getLong(3), c.getLong(4)))
            }
        }
        return result
    }

    fun typeName(type: Int): String = when (type) {
        CallLog.Calls.INCOMING_TYPE -> "gelen"
        CallLog.Calls.OUTGOING_TYPE -> "giden"
        CallLog.Calls.MISSED_TYPE -> "cevapsız"
        CallLog.Calls.REJECTED_TYPE -> "reddedilen"
        CallLog.Calls.BLOCKED_TYPE -> "engellenen"
        CallLog.Calls.VOICEMAIL_TYPE -> "sesli mesaj"
        else -> "arama"
    }

    // ---- Asistan konuşurken zil sesini kısma ----

    private var savedRingVolume: Int? = null

    fun lowerRinger(ctx: Context) {
        try {
            val am = ctx.getSystemService(AudioManager::class.java)
            if (savedRingVolume == null) savedRingVolume = am.getStreamVolume(AudioManager.STREAM_RING)
            // 0 yapmak bazı telefonlarda "Rahatsız Etmeyin" izni ister; 1 güvenli.
            am.setStreamVolume(AudioManager.STREAM_RING, 1, 0)
        } catch (_: Exception) {
        }
    }

    fun restoreRinger(ctx: Context) {
        val v = savedRingVolume ?: return
        savedRingVolume = null
        try {
            ctx.getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_RING, v, 0)
        } catch (_: Exception) {
        }
    }
}
