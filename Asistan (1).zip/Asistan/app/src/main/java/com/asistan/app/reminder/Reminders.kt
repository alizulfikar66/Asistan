package com.asistan.app.reminder

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.asistan.app.AsistanApp
import com.asistan.app.MainActivity
import com.asistan.app.R
import com.asistan.app.core.AssistantService
import org.json.JSONArray
import org.json.JSONObject

data class Reminder(val id: Int, val text: String, val at: Long)

/** Hatırlatıcıları saklar ve zamanı gelince alarm kurar. */
object Reminders {

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("asistan_reminders", Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): List<Reminder> {
        val arr = JSONArray(prefs(ctx).getString("items", "[]") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Reminder(o.getInt("id"), o.getString("text"), o.getLong("at"))
        }.sortedBy { it.at }
    }

    @Synchronized
    private fun save(ctx: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("at", it.at)) }
        prefs(ctx).edit().putString("items", arr.toString()).apply()
    }

    /** @return true ise tam zamanında, false ise birkaç dakika gecikebilir */
    @Synchronized
    fun add(ctx: Context, text: String, at: Long): Pair<Reminder, Boolean> {
        val list = all(ctx)
        val r = Reminder((list.maxOfOrNull { it.id } ?: 0) + 1, text, at)
        save(ctx, list + r)
        return Pair(r, schedule(ctx, r))
    }

    @Synchronized
    fun cancel(ctx: Context, id: Int): Reminder? {
        val list = all(ctx)
        val r = list.firstOrNull { it.id == id } ?: return null
        save(ctx, list.filterNot { it.id == id })
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, r))
        return r
    }

    @Synchronized
    fun remove(ctx: Context, id: Int) {
        save(ctx, all(ctx).filterNot { it.id == id })
    }

    /** Telefon yeniden başlayınca alarmlar silinir; hepsini tekrar kur. */
    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        all(ctx).forEach { r ->
            if (r.at < now - 60 * 60_000) remove(ctx, r.id) // 1 saatten eski, kaçmış
            else schedule(ctx, r.copy(at = maxOf(r.at, now + 5_000)))
        }
    }

    private fun pending(ctx: Context, r: Reminder): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
            .setAction("com.asistan.REMINDER")
            .putExtra("id", r.id)
            .putExtra("text", r.text)
        return PendingIntent.getBroadcast(
            ctx, 1000 + r.id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun schedule(ctx: Context, r: Reminder): Boolean {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val exactAllowed = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        return try {
            if (exactAllowed) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pending(ctx, r))
                true
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pending(ctx, r))
                false
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pending(ctx, r))
            false
        }
    }
}

/** Zamanı gelen hatırlatıcıyı bildirim olarak gösterir ve asistan çalışıyorsa sesli okur. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val text = intent.getStringExtra("text") ?: return
        Reminders.remove(ctx, id)

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, AsistanApp.REMINDER_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("⏰ Hatırlatma")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(5000 + id, n)
        } catch (_: SecurityException) {
        }
        AssistantService.speakNotice("Hatırlatma: $text")
    }
}

/** Telefon açılınca hatırlatıcıları yeniden kurar. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON" ||
            intent.action == AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED
        ) {
            Reminders.rescheduleAll(ctx)
            if (intent.action != AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED) {
                remindToStart(ctx)
            }
        }
    }

    /**
     * Android, mikrofon kullanan servislerin telefon açılışında kendiliğinden başlamasına izin vermez.
     * Bu yüzden kullanıcıya "başlatmak için dokun" bildirimi gösterilir.
     */
    private fun remindToStart(ctx: Context) {
        val s = com.asistan.app.core.AppSettings(ctx)
        if (!(s.wakeWordEnabled || s.announceCalls || s.announceMessages || s.batteryAlerts)) return
        val open = PendingIntent.getActivity(
            ctx, 90, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, AsistanApp.REMINDER_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("${s.assistantName} hazır")
            .setContentText("Telefon yeniden başladı. Asistanı başlatmak için dokun.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(9000, n)
        } catch (_: SecurityException) {
        }
    }
}
