package com.asistan.app.wake

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.asistan.app.phone.TextUtil
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

/**
 * Uyandırma kelimesini telefonun içinde (internetsiz) dinler.
 * Kelime duyulunca [onWake] çağrılır ve dinleme durur; tekrar başlatmak için [start] çağrılmalıdır.
 */
class WakeWordDetector(private val ctx: Context, private val onWake: () -> Unit) {

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var service: SpeechService? = null
    private var lastWake = 0L

    @Volatile
    var wakeWord: String = "asistan"

    val isRunning get() = service != null

    /** Modeli yükler (ağır işlem, ana iş parçacığında çağırmayın). */
    fun loadModel(): Boolean {
        if (model != null) return true
        if (!ModelDownloader.isReady(ctx)) return false
        return try {
            model = Model(ModelDownloader.modelDir(ctx).absolutePath)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Model yüklenemedi", e)
            false
        }
    }

    /** Dinlemeye başlar. Ana iş parçacığında çağrılmalı; model önceden yüklenmiş olmalı. */
    fun start(): Boolean {
        if (service != null) return true
        val m = model ?: return false
        return try {
            val rec = Recognizer(m, 16000f)
            recognizer = rec
            service = SpeechService(rec, 16000f).also { it.startListening(listener) }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Uyandırma dinleyicisi başlatılamadı", e)
            stop()
            false
        }
    }

    fun stop() {
        try {
            service?.stop()
            service?.shutdown()
        } catch (_: Exception) {
        }
        service = null
        try {
            recognizer?.close()
        } catch (_: Exception) {
        }
        recognizer = null
    }

    fun release() {
        stop()
        try {
            model?.close()
        } catch (_: Exception) {
        }
        model = null
    }

    private fun check(text: String) {
        if (text.isBlank()) return
        val heard = TextUtil.normalize(text)
        val target = TextUtil.normalize(wakeWord)
        if (target.isEmpty() || !heard.contains(target)) return
        val now = System.currentTimeMillis()
        if (now - lastWake < 2000) return
        lastWake = now
        // Geri çağırmanın içinden servisi durdurmamak için bir sonraki döngüye bırak.
        main.post {
            stop()
            onWake()
        }
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            hypothesis?.let { check(JSONObject(it).optString("partial")) }
        }

        override fun onResult(hypothesis: String?) {
            hypothesis?.let { check(JSONObject(it).optString("text")) }
        }

        override fun onFinalResult(hypothesis: String?) {
            hypothesis?.let { check(JSONObject(it).optString("text")) }
        }

        override fun onError(exception: Exception?) {
            Log.e(TAG, "Vosk hatası", exception)
        }

        override fun onTimeout() {}
    }

    companion object {
        private const val TAG = "WakeWord"
    }
}
