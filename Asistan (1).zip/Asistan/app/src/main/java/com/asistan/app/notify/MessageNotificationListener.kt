package com.asistan.app.notify

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat

/**
 * Bildirimleri dinleyerek WhatsApp, Telegram, Messenger, SMS vb. mesajlarını yakalar.
 * Kullanıcının Ayarlar > Bildirim erişimi ekranından izin vermesi gerekir.
 */
class MessageNotificationListener : NotificationListenerService() {

    private val knownApps = mapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "org.telegram.messenger" to "Telegram",
        "org.thunderdog.challegram" to "Telegram",
        "com.facebook.orca" to "Messenger",
        "com.instagram.android" to "Instagram",
        "com.google.android.apps.messaging" to "Mesajlar",
        "com.samsung.android.messaging" to "Mesajlar",
        "com.android.mms" to "Mesajlar",
        "com.viber.voip" to "Viber",
        "org.thoughtcrime.securesms" to "Signal",
        "com.bip.app" to "BiP",
        "com.turkcell.bip" to "BiP",
        "com.discord" to "Discord",
        "com.slack" to "Slack",
        "com.microsoft.teams" to "Teams"
    )

    override fun onListenerConnected() {
        NotificationStore.listenerConnected = true
    }

    override fun onListenerDisconnected() {
        NotificationStore.listenerConnected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (_: Exception) {
            // Bir uygulamanın tuhaf bildirimi asistanı çökertmesin.
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (sbn.isOngoing) return

        val isMessage = knownApps.containsKey(sbn.packageName) ||
                n.category == Notification.CATEGORY_MESSAGE
        if (!isMessage) return

        val appName = knownApps[sbn.packageName] ?: appLabel(sbn.packageName)
        val reply = findReplyAction(n)
        val fresh = System.currentTimeMillis() - 60_000

        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        if (style != null && style.messages.isNotEmpty()) {
            val group = if (style.isGroupConversation) style.conversationTitle?.toString() else null
            for (m in style.messages.takeLast(5)) {
                val sender = m.person?.name?.toString() ?: continue // gönderen yoksa kullanıcının kendi mesajı
                val text = m.text?.toString() ?: continue
                val added = NotificationStore.add(
                    sbn.packageName, appName, sender, group, text, m.timestamp, reply
                )
                if (added != null && m.timestamp >= fresh) NotificationStore.incoming.tryEmit(added)
            }
            return
        }

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        if (text.isBlank()) return
        val added = NotificationStore.add(sbn.packageName, appName, title, null, text, sbn.postTime, reply)
        if (added != null) NotificationStore.incoming.tryEmit(added)
    }

    private fun findReplyAction(n: Notification): Notification.Action? =
        n.actions?.firstOrNull { a ->
            a.remoteInputs?.any { it.allowFreeFormInput } == true
        }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}
