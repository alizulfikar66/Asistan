package com.asistan.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.asistan.app.core.AppSettings
import com.asistan.app.core.AssistantService
import com.asistan.app.core.AssistantState
import com.asistan.app.core.Status
import com.asistan.app.safety.FindPhone
import com.asistan.app.ui.AsistanTheme
import com.asistan.app.ui.MainScreen
import com.asistan.app.ui.Perms
import com.asistan.app.ui.SettingsScreen
import com.asistan.app.vision.ImageUtil
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {

    private lateinit var settings: AppSettings
    private var showSettings by mutableStateOf(false)
    private var hasKey by mutableStateOf(false)
    private var listenWhenReady = false

    // Kamera
    private var photoFile: File? = null
    private var photoQuestion: String = ""

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            AssistantService.send(this, AssistantService.ACTION_START)
            if (listenWhenReady) AssistantService.send(this, AssistantService.ACTION_LISTEN)
        } else {
            AssistantState.info.value = "Seni duyabilmem için mikrofon izni gerekli."
        }
        listenWhenReady = false
    }

    private val takePicture = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { ok ->
        val file = photoFile
        photoFile = null
        if (ok && file != null && file.length() > 0) {
            AssistantService.send(this, AssistantService.ACTION_IMAGE, photoQuestion, file.absolutePath)
        } else {
            AssistantState.info.value = "Fotoğraf çekilmedi."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        settings = AppSettings(this)
        hasKey = settings.apiKey.isNotBlank()

        // İlk açılışta anahtar yoksa doğrudan ayarlara götür
        if (savedInstanceState == null && !hasKey) showSettings = true

        setContent {
            AsistanTheme {
                if (showSettings) {
                    SettingsScreen(settings) {
                        showSettings = false
                        hasKey = settings.apiKey.isNotBlank()
                        AssistantState.wakeReady.value =
                            settings.wakeWordEnabled && com.asistan.app.wake.ModelDownloader.isReady(this)
                    }
                } else {
                    MainScreen(
                        hasApiKey = hasKey,
                        onOrbTap = ::onOrbTap,
                        onSendText = { text -> withMic { AssistantService.send(this, AssistantService.ACTION_TEXT, text) } },
                        onOpenSettings = { showSettings = true },
                        onCamera = { AssistantState.cameraRequest.value = "Bu ne? Kısaca anlat." },
                        onStopFind = { FindPhone.stopRinging(this) },
                        onEndMeeting = {
                            AssistantState.info.value = com.asistan.app.phone.MeetingMode.end(this)
                        }
                    )
                }
            }
        }

        // Asistan "kamerayı aç" dediğinde (veya kamera düğmesine basılınca) fotoğraf çek
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.RESUMED) {
                AssistantState.cameraRequest.collect { q ->
                    if (q != null) {
                        AssistantState.cameraRequest.value = null
                        launchCamera(q)
                    }
                }
            }
        }
        handleAssistIntent(intent)
    }

    private fun launchCamera(question: String) {
        if (photoFile != null) return
        try {
            val file = ImageUtil.newPhotoFile(this)
            val uri: Uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            photoFile = file
            photoQuestion = question
            takePicture.launch(uri)
        } catch (e: Exception) {
            photoFile = null
            AssistantState.info.value = "Kamera açılamadı: ${e.message}"
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleAssistIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        AssistantState.uiVisible.value = true
        hasKey = settings.apiKey.isNotBlank()
        AssistantState.meetingOn.value = settings.meetingMode
        AssistantState.wakeReady.value = settings.wakeWordEnabled && com.asistan.app.wake.ModelDownloader.isReady(this)
        if (Perms.has(this, Manifest.permission.RECORD_AUDIO)) {
            AssistantService.send(this, AssistantService.ACTION_START)
        }
    }

    override fun onStop() {
        AssistantState.uiVisible.value = false
        super.onStop()
    }

    private fun handleAssistIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_ASSIST) {
            withMic { AssistantService.send(this, AssistantService.ACTION_LISTEN) }
        }
    }

    private fun onOrbTap() {
        when (AssistantState.status.value) {
            Status.LISTENING, Status.THINKING, Status.SPEAKING ->
                AssistantService.send(this, AssistantService.ACTION_INTERRUPT)
            else -> withMic { AssistantService.send(this, AssistantService.ACTION_LISTEN) }
        }
    }

    /** Mikrofon izni varsa işi yap, yoksa önce izni iste. */
    private fun withMic(action: () -> Unit) {
        if (Perms.has(this, Manifest.permission.RECORD_AUDIO)) {
            action()
        } else {
            listenWhenReady = true
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
}
