package com.asistan.app.wake

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * Çevrimdışı Türkçe konuşma tanıma modelini (Vosk, ~35 MB) bir kez indirir.
 * Bu model yalnızca uyandırma kelimesini ("Asistan") telefonda, internete göndermeden yakalamak için kullanılır.
 */
object ModelDownloader {

    private const val URL = "https://alphacephei.com/vosk/models/vosk-model-small-tr-0.3.zip"

    fun modelDir(ctx: Context) = File(ctx.filesDir, "vosk-tr")
    private fun marker(ctx: Context) = File(modelDir(ctx), ".hazir")

    fun isReady(ctx: Context) = marker(ctx).exists()

    suspend fun download(ctx: Context, onProgress: (Int) -> Unit) = withContext(Dispatchers.IO) {
        val http = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .build()
        val zipFile = File(ctx.cacheDir, "vosk-tr.zip")
        val tmpDir = File(ctx.filesDir, "vosk-tmp")

        http.newCall(Request.Builder().url(URL).build()).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("İndirme başarısız (HTTP ${resp.code})")
            val body = resp.body ?: throw IOException("Boş cevap")
            val total = body.contentLength().takeIf { it > 0 } ?: 40_000_000L
            body.byteStream().use { input ->
                FileOutputStream(zipFile).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var lastPct = -1
                    while (true) {
                        val r = input.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                        done += r
                        val pct = ((done * 90) / total).toInt().coerceIn(0, 90)
                        if (pct != lastPct) {
                            lastPct = pct
                            onProgress(pct)
                        }
                    }
                }
            }
        }

        // Zip'i aç
        tmpDir.deleteRecursively()
        tmpDir.mkdirs()
        val tmpCanonical = tmpDir.canonicalPath + File.separator
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                val outFile = File(tmpDir, entry.name)
                if (!outFile.canonicalPath.startsWith(tmpCanonical)) continue // güvenlik
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { zis.copyTo(it) }
                }
            }
        }
        onProgress(97)

        // Zip içinde tek klasör varsa onu model klasörü yap
        val children = tmpDir.listFiles()?.toList().orEmpty()
        val root = if (children.size == 1 && children[0].isDirectory) children[0] else tmpDir
        val dest = modelDir(ctx)
        dest.deleteRecursively()
        if (!root.renameTo(dest)) {
            root.copyRecursively(dest, overwrite = true)
        }
        tmpDir.deleteRecursively()
        zipFile.delete()
        marker(ctx).writeText("ok")
        onProgress(100)
    }
}
