package com.asistan.app.phone

import android.content.Context
import android.os.Build
import android.provider.Telephony
import android.telephony.SmsManager

data class SmsItem(
    val address: String,
    val name: String?,
    val body: String,
    val date: Long,
    val read: Boolean
)

object Sms {

    fun inbox(ctx: Context, count: Int, unreadOnly: Boolean, from: String?): List<SmsItem> {
        val result = mutableListOf<SmsItem>()
        val nameCache = HashMap<String, String?>()
        val fromNorm = from?.let { TextUtil.normalize(it) }?.takeIf { it.isNotEmpty() }
        val selection = if (unreadOnly) "${Telephony.Sms.READ} = 0" else null
        ctx.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.READ),
            selection, null, "${Telephony.Sms.DATE} DESC"
        )?.use { c ->
            var scanned = 0
            while (c.moveToNext() && result.size < count && scanned < 300) {
                scanned++
                val address = c.getString(0) ?: ""
                val name = nameCache.getOrPut(address) { Contacts.nameForNumber(ctx, address) }
                if (fromNorm != null) {
                    val hay = TextUtil.normalize((name ?: "") + " " + address)
                    if (!hay.contains(fromNorm)) continue
                }
                result.add(
                    SmsItem(address, name, c.getString(1) ?: "", c.getLong(2), c.getInt(3) == 1)
                )
            }
        }
        return result
    }

    fun send(ctx: Context, number: String, text: String) {
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }
        val parts = sm.divideMessage(text)
        sm.sendMultipartTextMessage(number, null, parts, null, null)
    }
}
