package com.asistan.app.core

import android.Manifest
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.asistan.app.notify.NotificationStore
import com.asistan.app.phone.CalendarHelper
import com.asistan.app.phone.CallHelper
import com.asistan.app.phone.Contacts
import com.asistan.app.phone.DeviceControl
import com.asistan.app.phone.PhoneActions
import com.asistan.app.reminder.Reminders
import com.asistan.app.phone.Sms
import com.asistan.app.phone.TextUtil
import org.json.JSONArray
import org.json.JSONObject

/** Bir aracın sonucu. [afterSpeech], asistan cevabını okuduktan SONRA çalışır (ör. aramayı başlatmak). */
data class ToolOutcome(
    val content: String,
    val isError: Boolean = false,
    val afterSpeech: (() -> Unit)? = null
)

/** Claude'un telefonda kullanabileceği araçlar (arama, SMS, bildirim mesajları, alarm, uygulama açma). */
class ToolExecutor(private val ctx: Context) {

    // ---------- Araç tanımları (Claude'a gönderilir) ----------

    fun definitions(webSearch: Boolean): JSONArray {
        val arr = JSONArray()
        arr.put(
            tool(
                "find_contact",
                "Rehberde kişi arar ve telefon numaralarını döndürür. Ada gelen Türkçe ekleri çıkar (\"Ahmet'in\" -> \"Ahmet\").",
                props("query" to str("Kişinin adı veya adın bir kısmı")),
                listOf("query")
            )
        )
        arr.put(
            tool(
                "make_call",
                "Telefon araması başlatır. Rehberdeki bir kişi adı veya doğrudan bir telefon numarası alır. " +
                        "Birden fazla eşleşme olursa seçenekleri döndürür; kullanıcıya hangisi olduğunu sor ve numarayla tekrar çağır.",
                props("contact_or_number" to str("Kişi adı (ekler çıkarılmış) veya telefon numarası")),
                listOf("contact_or_number")
            )
        )
        arr.put(
            tool(
                "read_sms",
                "Gelen kutusundaki SMS mesajlarını okur (en yeniden eskiye).",
                props(
                    "count" to int("Kaç mesaj (varsayılan 5, en fazla 20)"),
                    "unread_only" to bool("Sadece okunmamışlar"),
                    "from" to str("Sadece bu kişiden/numaradan gelenler (isteğe bağlı)")
                ),
                emptyList()
            )
        )
        arr.put(
            tool(
                "send_sms",
                "SMS gönderir. ÖNCE alıcıyı ve metni kullanıcıya okuyup onay al; yalnızca kullanıcı açıkça onaylarsa user_confirmed=true ile çağır.",
                props(
                    "recipient" to str("Kişi adı veya telefon numarası"),
                    "message" to str("Gönderilecek metin"),
                    "user_confirmed" to bool("Kullanıcı bu metni göndermeyi açıkça onayladı mı?")
                ),
                listOf("recipient", "message", "user_confirmed")
            )
        )
        arr.put(
            tool(
                "read_app_messages",
                "WhatsApp, Telegram, Instagram, Messenger, BiP vb. uygulamalardan bildirim olarak gelen son mesajları okur. " +
                        "Her mesajın bir id'si vardır; cevap vermek için reply_app_message ile bu id kullanılır.",
                props(
                    "app" to str("Uygulama adı filtresi, ör. WhatsApp (isteğe bağlı)"),
                    "count" to int("Kaç mesaj (varsayılan 8)")
                ),
                emptyList()
            )
        )
        arr.put(
            tool(
                "reply_app_message",
                "Bildirimden gelen bir mesaja (ör. WhatsApp) doğrudan cevap yazar. ÖNCE metni kullanıcıya okuyup onay al.",
                props(
                    "message_id" to int("read_app_messages ile gelen mesaj id'si"),
                    "message" to str("Cevap metni"),
                    "user_confirmed" to bool("Kullanıcı açıkça onayladı mı?")
                ),
                listOf("message_id", "message", "user_confirmed")
            )
        )
        arr.put(
            tool(
                "set_alarm",
                "Saat uygulamasında alarm kurar.",
                props(
                    "hour" to int("Saat (0-23)"),
                    "minute" to int("Dakika (0-59)"),
                    "label" to str("Alarm etiketi (isteğe bağlı)")
                ),
                listOf("hour", "minute")
            )
        )
        arr.put(
            tool(
                "set_timer",
                "Geri sayım zamanlayıcısı kurar.",
                props(
                    "seconds" to int("Süre (saniye)"),
                    "label" to str("Etiket (isteğe bağlı)")
                ),
                listOf("seconds")
            )
        )
        arr.put(
            tool(
                "open_app",
                "Telefonda yüklü bir uygulamayı açar (ör. YouTube, Spotify, Kamera).",
                props("app_name" to str("Uygulamanın adı")),
                listOf("app_name")
            )
        )
        // ---- Gelen arama ----
        arr.put(tool("answer_call", "Şu an çalan gelen aramayı açar.", props(), emptyList()))
        arr.put(
            tool(
                "reject_call",
                "Çalan aramayı reddeder veya devam eden aramayı kapatır. İstenirse ardından send_sms ile arayana mesaj atılabilir.",
                props(), emptyList()
            )
        )
        arr.put(
            tool(
                "read_call_log",
                "Arama geçmişini okur (kim aradı, cevapsız aramalar).",
                props(
                    "count" to int("Kaç kayıt (varsayılan 5)"),
                    "missed_only" to bool("Sadece cevapsız aramalar")
                ),
                emptyList()
            )
        )
        // ---- Müzik ve cihaz ----
        arr.put(
            tool(
                "media_control",
                "Çalan müziği/videoyu kontrol eder (Spotify, YouTube Music vb.) veya şu an ne çaldığını söyler.",
                props("action" to enumStr("Komut", "play", "pause", "toggle", "next", "previous", "now_playing")),
                listOf("action")
            )
        )
        arr.put(
            tool(
                "set_volume",
                "Ses seviyesini ayarlar. Ya percent (0-100) ya da change ver.",
                props(
                    "stream" to enumStr("Hangi ses (varsayılan media)", "media", "ring", "alarm", "notification", "call"),
                    "percent" to int("Hedef seviye yüzde 0-100"),
                    "change" to enumStr("Göreli değişiklik", "up", "down", "mute", "unmute")
                ),
                emptyList()
            )
        )
        arr.put(
            tool(
                "set_ringer_mode",
                "Telefonu normal, titreşim veya sessiz moda alır.",
                props("mode" to enumStr("Mod", "normal", "vibrate", "silent")),
                listOf("mode")
            )
        )
        arr.put(
            tool(
                "meeting_mode",
                "Toplantı modu: açınca telefon sessize alınır, aramalar sesli duyurulmaz, rehberdeki arayanlara otomatik 'toplantıdayım' SMS'i gider. Kapatınca zil modu geri gelir ve kaçırılan aramaların özeti döner.",
                props("on" to bool("true=aç, false=kapat")),
                listOf("on")
            )
        )
        arr.put(tool("flashlight", "Feneri açar veya kapatır.", props("on" to bool("true=aç, false=kapat")), listOf("on")))
        arr.put(tool("device_status", "Pil, şarj, internet bağlantısı, zil modu, ses seviyesi ve sıradaki alarmı söyler.", props(), emptyList()))
        // ---- Takvim ve hatırlatıcı ----
        arr.put(
            tool(
                "read_calendar",
                "Takvimdeki etkinlikleri okur. Tarihler yerel saatle ISO biçiminde: 2026-10-13T00:00",
                props(
                    "from" to str("Başlangıç (ISO). Boşsa şimdi."),
                    "to" to str("Bitiş (ISO). Boşsa başlangıçtan 1 gün sonra.")
                ),
                emptyList()
            )
        )
        arr.put(
            tool(
                "add_calendar_event",
                "Takvime etkinlik ekler (15 dk önce bildirim kurar). Tarihler yerel saatle ISO: 2026-10-16T14:00",
                props(
                    "title" to str("Etkinlik adı"),
                    "start" to str("Başlangıç (ISO)"),
                    "end" to str("Bitiş (ISO). Boşsa 1 saat."),
                    "location" to str("Yer (isteğe bağlı)")
                ),
                listOf("title", "start")
            )
        )
        arr.put(
            tool(
                "add_reminder",
                "Belirtilen zamanda asistanın sesli hatırlatma yapmasını ve bildirim göstermesini sağlar. Zaman yerel saatle ISO: 2026-10-13T15:00. " +
                        "\"10 dakika sonra\" gibi göreli ifadeleri şu anki saate göre hesapla.",
                props(
                    "text" to str("Ne hatırlatılacak, ör. 'Doktora git'"),
                    "when" to str("Zaman (ISO)")
                ),
                listOf("text", "when")
            )
        )
        arr.put(tool("list_reminders", "Kurulu hatırlatıcıları listeler.", props(), emptyList()))
        arr.put(
            tool(
                "cancel_reminder", "Bir hatırlatıcıyı iptal eder.",
                props("id" to int("list_reminders ile gelen id")), listOf("id")
            )
        )
        // ---- Hafıza ----
        arr.put(
            tool(
                "remember",
                "Kullanıcı hakkında kalıcı bir bilgiyi hafızaya kaydeder (ör. 'Arabayı B2 katına park ettim', 'Eşimin adı Ayşe'). Sonraki sohbetlerde de hatırlanır. Şifre, kart numarası gibi gizli bilgileri kaydetme.",
                props("fact" to str("Kısa, tek cümlelik bilgi")),
                listOf("fact")
            )
        )
        arr.put(tool("forget", "Hafızadaki bir bilgiyi siler.", props("id" to int("Hafıza id'si")), listOf("id")))
        // ---- Harita ve WhatsApp ----
        arr.put(
            tool(
                "maps",
                "Google Haritalar'ı açar: yol tarifi başlatır (navigate=true) veya yer arar (ör. 'en yakın eczane').",
                props(
                    "query" to str("Adres, yer adı veya arama ('yakındaki benzinlik')"),
                    "navigate" to bool("true ise yol tarifini başlat")
                ),
                listOf("query")
            )
        )
        arr.put(
            tool(
                "whatsapp_compose",
                "Rehberdeki bir kişiye WhatsApp'ta yazılmış bir mesajla sohbeti açar; Gönder'e kullanıcı basar. Daha önce mesajlaşılmamış kişiler için kullan (gelen mesaja cevap için reply_app_message daha iyi).",
                props(
                    "recipient" to str("Kişi adı veya numara"),
                    "message" to str("Mesaj metni")
                ),
                listOf("recipient", "message")
            )
        )
        // ---- Ekran kontrolü (erişilebilirlik) ----
        arr.put(
            tool(
                "read_screen",
                "Telefon ekranında o an görünen düğmeleri, yazıları, anahtarları ve metin kutularını numaralı liste olarak verir. Ekranda bir şey yapmadan önce kullan.",
                props(), emptyList()
            )
        )
        arr.put(
            tool(
                "tap",
                "Ekrandaki bir öğeye dokunur. read_screen'deki numarayı (index) veya görünen yazıyı (text) ver. Dokunduktan sonra yeni ekranı döndürür.",
                props(
                    "index" to int("read_screen listesindeki numara"),
                    "text" to str("Öğenin üzerindeki yazı, ör. 'İzin ver'"),
                    "long_press" to bool("Uzun bas")
                ),
                emptyList()
            )
        )
        arr.put(
            tool(
                "type_text",
                "Bir metin kutusuna yazı yazar (var olan yazının yerine geçer). index/target verilmezse odaktaki kutuya yazar.",
                props(
                    "value" to str("Yazılacak metin"),
                    "index" to int("Metin kutusunun numarası (isteğe bağlı)"),
                    "target" to str("Metin kutusunun etiketi/ipucu (isteğe bağlı)")
                ),
                listOf("value")
            )
        )
        arr.put(
            tool(
                "scroll", "Ekranı kaydırır. Kaydırdıktan sonra yeni ekranı döndürür.",
                props("direction" to enumStr("Yön", "down", "up", "left", "right")), listOf("direction")
            )
        )
        arr.put(
            tool(
                "system_action",
                "Sistem tuşları: geri, ana ekran, son uygulamalar, bildirimleri aç, hızlı ayarlar, güç menüsü, ekranı kilitle, ekran görüntüsü al.",
                props(
                    "action" to enumStr(
                        "Eylem", "back", "home", "recents", "notifications", "quick_settings",
                        "power_menu", "lock_screen", "screenshot"
                    )
                ),
                listOf("action")
            )
        )
        arr.put(
            tool(
                "open_settings",
                "Telefon Ayarları'nın ilgili sayfasını açar ve (ekran kontrolü açıksa) ekranı döndürür. Ardından tap ile anahtarı açıp kapatabilirsin.",
                props(
                    "page" to enumStr(
                        "Sayfa", "main", "wifi", "bluetooth", "network", "airplane", "display", "sound",
                        "battery", "location", "apps", "notifications", "dnd", "date", "language",
                        "security", "accessibility", "storage", "nfc", "hotspot", "app_info"
                    ),
                    "app_name" to str("page=app_info ise uygulamanın adı")
                ),
                listOf("page")
            )
        )
        // ---- Dolandırıcı koruması ----
        arr.put(
            tool(
                "check_number",
                "Bir telefon numarasının türünü ve risk seviyesini değerlendirir (0850, 0212, 0900, yurt dışı, gizli vb.), rehberde olup olmadığını ve daha önce kaç kez aradığını söyler. Kim olduğunu bulmak için ardından web_search kullanabilirsin.",
                props("number" to str("Telefon numarası")),
                listOf("number")
            )
        )
        arr.put(
            tool(
                "block_number",
                "Numarayı engeller; arama filtreleme açıksa bu numara bir daha çaldırmaz.",
                props("number" to str("Numara"), "label" to str("Not, ör. 'reklam' (isteğe bağlı)")),
                listOf("number")
            )
        )
        arr.put(tool("unblock_number", "Numaranın engelini kaldırır.", props("number" to str("Numara")), listOf("number")))
        arr.put(tool("list_blocked", "Engellenen numaraları listeler.", props(), emptyList()))
        // ---- Görme ----
        arr.put(
            tool(
                "look_with_camera",
                "Kamerayı açar; kullanıcı fotoğraf çekince fotoğrafı görüp soruyu cevaplarsın (ör. 'bu ne', 'bu ilacın adı ne', 'bunu çevir', 'faturada ne kadar yazıyor').",
                props("question" to str("Fotoğrafla ilgili cevaplanacak soru")),
                listOf("question")
            )
        )
        // ---- Notlar ----
        arr.put(tool("add_note", "Not kaydeder.", props("text" to str("Not metni")), listOf("text")))
        arr.put(
            tool(
                "read_notes", "Notları okur; query verilirse içinde geçenleri getirir.",
                props("query" to str("Aranacak kelime (isteğe bağlı)")), emptyList()
            )
        )
        arr.put(tool("delete_note", "Bir notu siler.", props("id" to int("Not id'si")), listOf("id")))
        // ---- Konum ve güvenlik ----
        arr.put(tool("get_location", "Telefonun şu anki konumunu ve adresini bulur.", props(), emptyList()))
        arr.put(
            tool(
                "emergency_alert",
                "ACİL DURUM: Ayarlardaki acil durum kişilerine konum linkiyle SMS gönderir. Sadece kullanıcı onayladıktan sonra user_confirmed=true ile çağır.",
                props(
                    "note" to str("Mesaja eklenecek kısa açıklama (isteğe bağlı), ör. 'düştüm, kalkamıyorum'"),
                    "user_confirmed" to bool("Kullanıcı onayladı mı?")
                ),
                listOf("user_confirmed")
            )
        )
        // Önbellek: araç listesi her istekte aynı; Claude bunu önbelleğe alır ve tekrar işleme maliyeti düşer.
        if (arr.length() > 0) {
            arr.getJSONObject(arr.length() - 1).put("cache_control", JSONObject().put("type", "ephemeral"))
        }
        if (webSearch) {
            arr.put(
                JSONObject()
                    .put("type", "web_search_20250305")
                    .put("name", "web_search")
                    .put("max_uses", 3)
            )
        }
        return arr
    }

    // ---------- Araçları çalıştırma ----------

    fun execute(name: String, input: JSONObject): ToolOutcome = try {
        when (name) {
            "find_contact" -> findContact(input)
            "make_call" -> makeCall(input)
            "read_sms" -> readSms(input)
            "send_sms" -> sendSms(input)
            "read_app_messages" -> readAppMessages(input)
            "reply_app_message" -> replyAppMessage(input)
            "set_alarm" -> setAlarm(input)
            "set_timer" -> setTimer(input)
            "open_app" -> openApp(input)
            "answer_call" -> answerCall()
            "reject_call" -> rejectCall()
            "read_call_log" -> readCallLog(input)
            "media_control" -> ToolOutcome(DeviceControl.media(ctx, input.optString("action", "toggle")))
            "set_volume" -> ToolOutcome(
                DeviceControl.setVolume(
                    ctx,
                    input.optString("stream", "media"),
                    if (input.has("percent")) input.optInt("percent") else null,
                    input.optString("change", "").ifBlank { null }
                )
            )
            "set_ringer_mode" -> ToolOutcome(
                com.asistan.app.phone.MeetingMode.setRinger(
                    ctx,
                    when (input.optString("mode", "normal")) {
                        "silent" -> android.media.AudioManager.RINGER_MODE_SILENT
                        "vibrate" -> android.media.AudioManager.RINGER_MODE_VIBRATE
                        else -> android.media.AudioManager.RINGER_MODE_NORMAL
                    }
                )
            )
            "meeting_mode" -> ToolOutcome(
                if (input.optBoolean("on", true)) com.asistan.app.phone.MeetingMode.start(ctx)
                else com.asistan.app.phone.MeetingMode.end(ctx)
            )
            "flashlight" -> ToolOutcome(DeviceControl.torch(ctx, input.optBoolean("on", true)))
            "device_status" -> ToolOutcome(DeviceControl.status(ctx))
            "read_calendar" -> readCalendar(input)
            "add_calendar_event" -> addCalendarEvent(input)
            "add_reminder" -> addReminder(input)
            "list_reminders" -> listReminders()
            "cancel_reminder" -> cancelReminder(input)
            "remember" -> {
                val f = input.optString("fact").trim()
                if (f.isEmpty()) ToolOutcome("Boş bilgi.", isError = true)
                else ToolOutcome("Hafızaya kaydedildi (id=${MemoryStore.add(ctx, f).id}).")
            }
            "forget" -> ToolOutcome(
                if (MemoryStore.remove(ctx, input.optInt("id", -1))) "Silindi." else "Bu id ile kayıt yok."
            )
            "maps" -> {
                val q = input.optString("query")
                val nav = input.optBoolean("navigate", false)
                ToolOutcome(
                    if (nav) "Yol tarifi açılacak: $q" else "Haritada aranacak: $q",
                    afterSpeech = { PhoneActions.maps(ctx, q, nav) }
                )
            }
            "whatsapp_compose" -> whatsappCompose(input)
            "look_with_camera" -> {
                val q = input.optString("question").ifBlank { "Bu ne? Kısaca anlat." }
                ToolOutcome(
                    "Kamera açılacak. Kullanıcıya kısaca 'Kamerayı açıyorum, fotoğrafı çek' de. Fotoğraf gelince ayrı bir mesajla cevaplayacaksın.",
                    afterSpeech = { openCamera(q) }
                )
            }
            "add_note" -> {
                val t = input.optString("text").trim()
                if (t.isEmpty()) ToolOutcome("Boş not.", isError = true)
                else ToolOutcome("Not kaydedildi (id=${NoteStore.add(ctx, t).id}).")
            }
            "read_notes" -> readNotes(input)
            "delete_note" -> ToolOutcome(
                if (NoteStore.remove(ctx, input.optInt("id", -1))) "Not silindi." else "Bu id ile not yok."
            )
            "read_screen" -> screen { it.readScreen() }
            "tap" -> screen { s ->
                val idx = if (input.has("index")) input.optInt("index") else null
                val txt = input.optString("text", "").ifBlank { null }
                if (idx == null && txt == null) "index veya text ver."
                else s.tap(idx, txt, input.optBoolean("long_press", false)) + "\n\nYeni ekran:\n" + afterChange(s)
            }
            "type_text" -> screen { s ->
                s.typeText(
                    if (input.has("index")) input.optInt("index") else null,
                    input.optString("target", "").ifBlank { null },
                    input.optString("value")
                )
            }
            "scroll" -> screen { s -> s.scroll(input.optString("direction", "down")) + "\n\nYeni ekran:\n" + afterChange(s) }
            "system_action" -> screen { s ->
                val a = input.optString("action")
                val r = s.global(a)
                if (a in listOf("back", "home", "recents", "notifications", "quick_settings")) r + "\n\nYeni ekran:\n" + afterChange(s) else r
            }
            "open_settings" -> openSettings(input)
            "check_number" -> {
                val r = com.asistan.app.protect.NumberRisk.assess(ctx, input.optString("number"))
                ToolOutcome(
                    "Numara: ${r.number ?: "gizli"} | Tür: ${r.category} | Risk (0-3): ${r.level}" +
                            (r.contactName?.let { " | Rehberde: $it" } ?: "") +
                            " | Daha önce arama sayısı: ${r.previousCalls}" +
                            (if (r.advice.isNotBlank()) " | Not: ${r.advice}" else "") +
                            (if (com.asistan.app.protect.BlockStore.contains(ctx, input.optString("number"))) " | ENGELLİ" else "")
                )
            }
            "block_number" -> {
                val num = input.optString("number")
                if (com.asistan.app.protect.BlockStore.add(ctx, num, input.optString("label", "")))
                    ToolOutcome(
                        "Engellendi: $num." + if (!screeningRoleHeld()) " Not: Engellemenin otomatik çalışması için Ayarlar > Arama koruması'ndan Asistan'ı arama filtreleme uygulaması yapmak gerekiyor; kullanıcıya söyle." else ""
                    )
                else ToolOutcome("Geçersiz numara.", isError = true)
            }
            "unblock_number" -> ToolOutcome(
                if (com.asistan.app.protect.BlockStore.remove(ctx, input.optString("number"))) "Engel kaldırıldı." else "Bu numara engelli değil."
            )
            "list_blocked" -> {
                val list = com.asistan.app.protect.BlockStore.load(ctx)
                ToolOutcome(
                    if (list.isEmpty()) "Engelli numara yok."
                    else list.joinToString("\n") { "${it.number}${if (it.label.isNotBlank()) " (${it.label})" else ""}" }
                )
            }
            "get_location" -> getLocation()
            "emergency_alert" -> emergencyAlert(input)
            else -> ToolOutcome("Bilinmeyen araç: $name", isError = true)
        }
    } catch (e: SecurityException) {
        ToolOutcome(
            "Gerekli izin verilmemiş (${e.message}). Kullanıcıya Asistan ayarlarındaki İzinler bölümünden izni vermesini söyle.",
            isError = true
        )
    } catch (e: Exception) {
        ToolOutcome("İşlem başarısız: ${e.message ?: e.javaClass.simpleName}", isError = true)
    }

    private fun missing(perm: String, what: String): ToolOutcome? =
        if (ContextCompat.checkSelfPermission(ctx, perm) != PackageManager.PERMISSION_GRANTED) {
            ToolOutcome(
                "$what izni verilmemiş. Kullanıcıya Asistan uygulamasında Ayarlar > İzinler bölümünden bu izni vermesini söyle.",
                isError = true
            )
        } else null

    private fun findContact(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.READ_CONTACTS, "Rehber")?.let { return it }
        val q = input.optString("query")
        val found = Contacts.search(ctx, q)
        if (found.isEmpty()) return ToolOutcome("Rehberde \"$q\" ile eşleşen kişi bulunamadı.")
        return ToolOutcome(found.joinToString("\n") { "${it.name} – ${it.label}: ${it.number}" })
    }

    /** Ad veya numarayı tek bir numaraya çevirir. Belirsizse kullanıcıya sorulacak metni döndürür. */
    private fun resolveNumber(target: String): Pair<Pair<String, String>?, ToolOutcome?> {
        if (TextUtil.looksLikeNumber(target)) {
            val name = Contacts.nameForNumber(ctx, target) ?: target
            return Pair(Pair(name, target), null)
        }
        missing(Manifest.permission.READ_CONTACTS, "Rehber")?.let { return Pair(null, it) }
        val found = Contacts.search(ctx, target)
        if (found.isEmpty()) {
            return Pair(null, ToolOutcome("Rehberde \"$target\" bulunamadı. Kullanıcıya adı tekrar sor.", isError = true))
        }
        val distinct = found.distinctBy { TextUtil.digits(it.number).takeLast(10) }
        if (distinct.size == 1) return Pair(Pair(distinct[0].name, distinct[0].number), null)
        val options = distinct.joinToString("\n") { "${it.name} – ${it.label}: ${it.number}" }
        return Pair(
            null,
            ToolOutcome(
                "Birden fazla eşleşme var, kullanıcıya hangisi olduğunu sor (numaraları okumak yerine ad ve etiketi söyle):\n$options"
            )
        )
    }

    private fun makeCall(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.CALL_PHONE, "Telefon araması")?.let { return it }
        val (resolved, problem) = resolveNumber(input.optString("contact_or_number"))
        if (resolved == null) return problem!!
        val (name, number) = resolved
        return ToolOutcome(
            "Arama hazır: $name ($number). Cevabını okuduktan sonra arama otomatik başlayacak. Kullanıcıya kısaca kimi aradığını söyle.",
            afterSpeech = { PhoneActions.placeCall(ctx, number) }
        )
    }

    private fun readSms(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.READ_SMS, "SMS okuma")?.let { return it }
        val count = input.optInt("count", 5).coerceIn(1, 20)
        val unread = input.optBoolean("unread_only", false)
        val from = input.optString("from", "").ifBlank { null }
        val list = Sms.inbox(ctx, count, unread, from)
        if (list.isEmpty()) {
            return ToolOutcome(if (unread) "Okunmamış SMS yok." else "Eşleşen SMS bulunamadı.")
        }
        return ToolOutcome(list.joinToString("\n") {
            val who = it.name ?: it.address
            val r = if (it.read) "" else " [okunmamış]"
            "${TextUtil.friendlyTime(it.date)} – $who$r: ${it.body.take(500)}"
        })
    }

    private fun sendSms(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.SEND_SMS, "SMS gönderme")?.let { return it }
        val text = input.optString("message").trim()
        if (text.isEmpty()) return ToolOutcome("Mesaj metni boş.", isError = true)
        if (!input.optBoolean("user_confirmed", false)) {
            return ToolOutcome(
                "Gönderilmedi: önce alıcıyı ve metni kullanıcıya oku, 'Göndereyim mi?' diye sor ve onay al.",
                isError = true
            )
        }
        val (resolved, problem) = resolveNumber(input.optString("recipient"))
        if (resolved == null) return problem!!
        Sms.send(ctx, resolved.second, text)
        return ToolOutcome("SMS gönderildi: ${resolved.first} kişisine.")
    }

    private fun readAppMessages(input: JSONObject): ToolOutcome {
        if (!NotificationStore.listenerConnected) {
            return ToolOutcome(
                "Bildirim erişimi kapalı. Kullanıcıya Asistan > Ayarlar > İzinler bölümünden 'Bildirim erişimi'ni açmasını söyle.",
                isError = true
            )
        }
        val app = input.optString("app", "").ifBlank { null }
        val count = input.optInt("count", 8).coerceIn(1, 20)
        val list = NotificationStore.recent(app, count)
        if (list.isEmpty()) {
            return ToolOutcome("Asistan açıldığından beri ${app ?: "uygulamalardan"} yeni mesaj bildirimi gelmedi.")
        }
        return ToolOutcome(list.joinToString("\n") {
            val group = it.conversation?.let { g -> " ($g grubunda)" } ?: ""
            val canReply = if (it.replyAction != null) "" else " [cevap verilemez]"
            "id=${it.id} | ${it.appName} | ${TextUtil.friendlyTime(it.time)} | ${it.sender}$group$canReply: ${it.text.take(500)}"
        })
    }

    private fun replyAppMessage(input: JSONObject): ToolOutcome {
        val msg = NotificationStore.get(input.optInt("message_id", -1))
            ?: return ToolOutcome("Bu id ile mesaj bulunamadı. Önce read_app_messages çağır.", isError = true)
        val text = input.optString("message").trim()
        if (text.isEmpty()) return ToolOutcome("Cevap metni boş.", isError = true)
        if (!input.optBoolean("user_confirmed", false)) {
            return ToolOutcome("Gönderilmedi: önce metni kullanıcıya oku ve onay al.", isError = true)
        }
        val action = msg.replyAction
            ?: return ToolOutcome("Bu bildirimde hızlı cevap özelliği yok. Kullanıcı uygulamayı açarak cevaplayabilir.", isError = true)
        val inputs = action.remoteInputs
            ?: return ToolOutcome("Bu bildirime cevap verilemiyor.", isError = true)
        val results = Bundle()
        for (ri in inputs) results.putCharSequence(ri.resultKey, text)
        val fillIn = Intent()
        RemoteInput.addResultsToIntent(inputs, fillIn, results)
        action.actionIntent.send(ctx, 0, fillIn)
        return ToolOutcome("${msg.appName} üzerinden ${msg.sender} kişisine cevap gönderildi.")
    }

    private fun setAlarm(input: JSONObject): ToolOutcome {
        val h = input.optInt("hour", -1)
        val m = input.optInt("minute", 0)
        if (h !in 0..23 || m !in 0..59) return ToolOutcome("Geçersiz saat.", isError = true)
        PhoneActions.setAlarm(ctx, h, m, input.optString("label", "").ifBlank { null })
        return ToolOutcome("Alarm %02d:%02d için kuruldu.".format(h, m))
    }

    private fun setTimer(input: JSONObject): ToolOutcome {
        val s = input.optInt("seconds", 0)
        if (s <= 0 || s > 24 * 3600) return ToolOutcome("Geçersiz süre.", isError = true)
        PhoneActions.setTimer(ctx, s, input.optString("label", "").ifBlank { null })
        return ToolOutcome("$s saniyelik zamanlayıcı kuruldu.")
    }

    private fun openApp(input: JSONObject): ToolOutcome {
        val q = input.optString("app_name")
        val apps = PhoneActions.findApps(ctx, q)
        if (apps.isEmpty()) return ToolOutcome("\"$q\" adında yüklü uygulama bulunamadı.", isError = true)
        if (apps.size > 1 && TextUtil.normalize(apps[0].label) != TextUtil.normalize(q)) {
            return ToolOutcome("Birden fazla uygulama eşleşti: ${apps.joinToString { it.label }}. Hangisi olduğunu sor.")
        }
        val app = apps[0]
        // Ekran kontrolü açıksa hemen aç ve ekranı göster: çok adımlı işler (ör. "WhatsApp'ta Ahmet'e yaz") yapılabilsin.
        val s = com.asistan.app.control.ScreenControlService.instance
        if (s != null) {
            PhoneActions.launchApp(ctx, app.packageName)
            return ToolOutcome("${app.label} açıldı.\n\nEkran:\n" + afterChange(s, 1500))
        }
        return ToolOutcome(
            "${app.label} açılacak.",
            afterSpeech = { PhoneActions.launchApp(ctx, app.packageName) }
        )
    }

    // ---------- Arama ----------

    private fun answerCall(): ToolOutcome {
        missing(Manifest.permission.ANSWER_PHONE_CALLS, "Aramaları yanıtlama")?.let { return it }
        CallHelper.restoreRinger(ctx)
        CallHelper.answer(ctx)
        return ToolOutcome("Arama açıldı. Kısa bir cevap verme, hiçbir şey söyleme gerekmez.")
    }

    private fun rejectCall(): ToolOutcome {
        missing(Manifest.permission.ANSWER_PHONE_CALLS, "Aramaları yanıtlama")?.let { return it }
        CallHelper.restoreRinger(ctx)
        return if (CallHelper.endCall(ctx)) ToolOutcome("Arama reddedildi/kapatıldı.")
        else ToolOutcome("Bu Android sürümünde arama kapatılamıyor (Android 9+ gerekir).", isError = true)
    }

    private fun readCallLog(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.READ_CALL_LOG, "Arama geçmişi")?.let { return it }
        val list = CallHelper.log(ctx, input.optInt("count", 5).coerceIn(1, 20), input.optBoolean("missed_only", false))
        if (list.isEmpty()) return ToolOutcome("Kayıt yok.")
        return ToolOutcome(list.joinToString("\n") {
            val who = it.name ?: Contacts.nameForNumber(ctx, it.number) ?: it.number.ifBlank { "gizli numara" }
            val dur = if (it.durationSec > 0) ", ${it.durationSec / 60} dk ${it.durationSec % 60} sn" else ""
            "${TextUtil.friendlyTime(it.date)} – ${CallHelper.typeName(it.type)} – $who$dur"
        })
    }

    // ---------- Takvim ----------

    private fun readCalendar(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.READ_CALENDAR, "Takvim")?.let { return it }
        val from = TextUtil.parseDateTime(input.optString("from")) ?: System.currentTimeMillis()
        val to = TextUtil.parseDateTime(input.optString("to"))?.takeIf { it > from } ?: (from + 24 * 3600_000L)
        val events = CalendarHelper.events(ctx, from, to)
        if (events.isEmpty()) return ToolOutcome("Bu aralıkta takvimde etkinlik yok.")
        return ToolOutcome(events.joinToString("\n") { e ->
            val time = if (e.allDay) "tüm gün" else "${TextUtil.friendlyTime(e.begin)} - ${TextUtil.friendlyTime(e.end)}"
            "$time: ${e.title}${e.location?.let { " ($it)" } ?: ""}"
        })
    }

    private fun addCalendarEvent(input: JSONObject): ToolOutcome {
        missing(Manifest.permission.WRITE_CALENDAR, "Takvime yazma")?.let { return it }
        val title = input.optString("title").trim()
        val start = TextUtil.parseDateTime(input.optString("start"))
            ?: return ToolOutcome("Başlangıç zamanı anlaşılamadı. ISO biçiminde gönder: 2026-10-16T14:00", isError = true)
        val end = TextUtil.parseDateTime(input.optString("end"))?.takeIf { it > start } ?: (start + 3600_000L)
        val id = CalendarHelper.addEvent(ctx, title, start, end, input.optString("location", "").ifBlank { null })
            ?: return ToolOutcome("Telefonda yazılabilir bir takvim bulunamadı. Google Takvim uygulamasının kurulu ve hesabın bağlı olduğundan emin ol.", isError = true)
        return ToolOutcome("Takvime eklendi (id=$id): $title, ${TextUtil.friendlyTime(start)}.")
    }

    // ---------- Hatırlatıcı ----------

    private fun addReminder(input: JSONObject): ToolOutcome {
        val text = input.optString("text").trim()
        val at = TextUtil.parseDateTime(input.optString("when"))
            ?: return ToolOutcome("Zaman anlaşılamadı. ISO biçiminde gönder: 2026-10-13T15:00", isError = true)
        if (at < System.currentTimeMillis() - 60_000) {
            return ToolOutcome("Bu zaman geçmişte kalıyor. Kullanıcıya hangi gün/saat olduğunu sor.", isError = true)
        }
        val (r, exact) = Reminders.add(ctx, text, at)
        val note = if (exact) "" else " (Not: Tam zamanlı alarm izni yok, birkaç dakika gecikebilir.)"
        return ToolOutcome("Hatırlatıcı kuruldu (id=${r.id}): ${TextUtil.friendlyTime(at)} – $text.$note")
    }

    private fun listReminders(): ToolOutcome {
        val list = Reminders.all(ctx)
        if (list.isEmpty()) return ToolOutcome("Kurulu hatırlatıcı yok.")
        return ToolOutcome(list.joinToString("\n") { "id=${it.id} | ${TextUtil.friendlyTime(it.at)} | ${it.text}" })
    }

    private fun cancelReminder(input: JSONObject): ToolOutcome {
        val r = Reminders.cancel(ctx, input.optInt("id", -1))
            ?: return ToolOutcome("Bu id ile hatırlatıcı yok.", isError = true)
        return ToolOutcome("İptal edildi: ${r.text}")
    }

    // ---------- WhatsApp ----------

    private fun whatsappCompose(input: JSONObject): ToolOutcome {
        val text = input.optString("message").trim()
        val (resolved, problem) = resolveNumber(input.optString("recipient"))
        if (resolved == null) return problem!!
        return ToolOutcome(
            "WhatsApp'ta ${resolved.first} ile sohbet mesaj yazılı halde açılacak. Kullanıcıya Gönder'e basması gerektiğini söyle.",
            afterSpeech = { PhoneActions.whatsappCompose(ctx, resolved.second, text) }
        )
    }

    // ---------- Ekran kontrolü ----------

    private fun screen(block: (com.asistan.app.control.ScreenControlService) -> String): ToolOutcome {
        val s = com.asistan.app.control.ScreenControlService.instance
            ?: return ToolOutcome(
                "Ekran kontrolü kapalı. Kullanıcıya Asistan > Ayarlar > Ekran kontrolü bölümünden açmasını söyle.",
                isError = true
            )
        return ToolOutcome(block(s))
    }

    /** Ekran değiştikten sonra kısa bekleyip yeni ekranı okur. */
    private fun afterChange(s: com.asistan.app.control.ScreenControlService, waitMs: Long = 900): String {
        try {
            Thread.sleep(waitMs)
        } catch (_: InterruptedException) {
        }
        return s.readScreen()
    }

    private fun openSettings(input: JSONObject): ToolOutcome {
        val S = android.provider.Settings.ACTION_SETTINGS
        val action = when (input.optString("page", "main")) {
            "wifi" -> android.provider.Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
            "network" -> android.provider.Settings.ACTION_WIRELESS_SETTINGS
            "airplane" -> android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "display" -> android.provider.Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> android.provider.Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "location" -> android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "apps" -> android.provider.Settings.ACTION_APPLICATION_SETTINGS
            "notifications" -> "android.settings.NOTIFICATION_SETTINGS"
            "dnd" -> "android.settings.ZEN_MODE_SETTINGS"
            "date" -> android.provider.Settings.ACTION_DATE_SETTINGS
            "language" -> android.provider.Settings.ACTION_LOCALE_SETTINGS
            "security" -> android.provider.Settings.ACTION_SECURITY_SETTINGS
            "accessibility" -> android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS
            "storage" -> android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "nfc" -> android.provider.Settings.ACTION_NFC_SETTINGS
            "hotspot" -> "android.settings.TETHER_SETTINGS"
            "app_info" -> android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            else -> S
        }
        val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (action == android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS) {
            val app = PhoneActions.findApps(ctx, input.optString("app_name")).firstOrNull()
                ?: return ToolOutcome("Uygulama bulunamadı.", isError = true)
            intent.data = android.net.Uri.parse("package:${app.packageName}")
        }
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            ctx.startActivity(Intent(S).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val s = com.asistan.app.control.ScreenControlService.instance
            ?: return ToolOutcome("Ayarlar sayfası açıldı. (Ekran kontrolü kapalı olduğu için içindeki düğmelere ben basamam; kullanıcı kendisi değiştirebilir.)")
        return ToolOutcome("Ayarlar sayfası açıldı.\n\nEkran:\n" + afterChange(s, 1300))
    }

    private fun screeningRoleHeld(): Boolean = try {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            ctx.getSystemService(android.app.role.RoleManager::class.java)
                .isRoleHeld(android.app.role.RoleManager.ROLE_CALL_SCREENING)
        } else false
    } catch (_: Exception) {
        false
    }

    // ---------- Görme ----------

    private fun openCamera(question: String) {
        AssistantState.cameraRequest.value = question
        // Uygulama arka plandaysa öne getir (kamerayı uygulama ekranı açar).
        if (!AssistantState.uiVisible.value) {
            try {
                ctx.startActivity(
                    Intent(ctx, com.asistan.app.MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            } catch (_: Exception) {
            }
        }
    }

    // ---------- Notlar ----------

    private fun readNotes(input: JSONObject): ToolOutcome {
        val q = TextUtil.normalize(input.optString("query", ""))
        val notes = NoteStore.load(ctx)
            .filter { q.isEmpty() || TextUtil.normalize(it.text).contains(q) }
            .sortedByDescending { it.created }
            .take(15)
        if (notes.isEmpty()) return ToolOutcome(if (q.isEmpty()) "Hiç not yok." else "Bununla ilgili not yok.")
        return ToolOutcome(notes.joinToString("\n") { "id=${it.id} | ${TextUtil.friendlyTime(it.created)} | ${it.text}" })
    }

    // ---------- Konum ve acil durum ----------

    private fun hasLocationPermission() =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun getLocation(): ToolOutcome {
        if (!hasLocationPermission()) {
            return ToolOutcome("Konum izni verilmemiş. Kullanıcıya Ayarlar > İzinler'den Konum iznini vermesini söyle.", isError = true)
        }
        val loc = com.asistan.app.phone.LocationHelper.current(ctx)
            ?: return ToolOutcome("Konum alınamadı. Telefonun konum servisinin açık olduğundan emin olmasını söyle.", isError = true)
        val addr = com.asistan.app.phone.LocationHelper.address(ctx, loc)
        return ToolOutcome(
            "Adres: ${addr ?: "bilinmiyor"}. Koordinat: %.5f, %.5f (doğruluk ~%d m).".format(
                java.util.Locale.US, loc.latitude, loc.longitude, loc.accuracy.toInt()
            )
        )
    }

    private fun emergencyAlert(input: JSONObject): ToolOutcome {
        if (!input.optBoolean("user_confirmed", false)) {
            return ToolOutcome("Gönderilmedi: önce kullanıcıdan onay al.", isError = true)
        }
        missing(Manifest.permission.SEND_SMS, "SMS gönderme")?.let { return it }
        val raw = AppSettings(ctx).emergencyContacts
        val targets = raw.split(",", ";", "\n").map { it.trim() }.filter { it.isNotEmpty() }
        if (targets.isEmpty()) {
            return ToolOutcome(
                "Acil durum kişisi tanımlanmamış. Kullanıcıya Ayarlar > Güvenlik bölümünden eklemesini söyle. Gerekirse hemen 112'yi aramayı teklif et.",
                isError = true
            )
        }
        val loc = if (hasLocationPermission()) com.asistan.app.phone.LocationHelper.current(ctx, timeoutSec = 10) else null
        val name = AppSettings(ctx).userName.ifBlank { "Bu telefonun sahibi" }
        val note = input.optString("note", "").trim()
        val text = buildString {
            append("ACİL DURUM! $name yardım istiyor.")
            if (note.isNotEmpty()) append(" Not: $note.")
            if (loc != null) append(" Konum: ${com.asistan.app.phone.LocationHelper.mapsLink(loc)}")
            else append(" (Konum alınamadı.)")
            append(" — Asistan")
        }
        val sent = mutableListOf<String>()
        val failed = mutableListOf<String>()
        for (t in targets) {
            val number = if (TextUtil.looksLikeNumber(t)) t else {
                val c = if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
                    Contacts.search(ctx, t).firstOrNull() else null
                c?.number
            }
            if (number == null) {
                failed.add(t)
                continue
            }
            try {
                Sms.send(ctx, number, text)
                sent.add(t)
            } catch (e: Exception) {
                failed.add(t)
            }
        }
        return ToolOutcome(
            "Acil durum mesajı gönderildi: ${sent.joinToString().ifEmpty { "kimseye" }}." +
                    (if (failed.isNotEmpty()) " Gönderilemedi: ${failed.joinToString()}." else "") +
                    (if (loc == null) " Konum eklenemedi." else " Konum eklendi.")
        )
    }

    // ---------- JSON yardımcıları ----------

    private fun enumStr(d: String, vararg values: String) =
        JSONObject().put("type", "string").put("description", d).put("enum", JSONArray(values.toList()))

    private fun tool(name: String, desc: String, properties: JSONObject, required: List<String>) =
        JSONObject()
            .put("name", name)
            .put("description", desc)
            .put(
                "input_schema",
                JSONObject()
                    .put("type", "object")
                    .put("properties", properties)
                    .put("required", JSONArray(required))
            )

    private fun props(vararg p: Pair<String, JSONObject>): JSONObject {
        val o = JSONObject()
        p.forEach { o.put(it.first, it.second) }
        return o
    }

    private fun str(d: String) = JSONObject().put("type", "string").put("description", d)
    private fun int(d: String) = JSONObject().put("type", "integer").put("description", d)
    private fun bool(d: String) = JSONObject().put("type", "boolean").put("description", d)
}
