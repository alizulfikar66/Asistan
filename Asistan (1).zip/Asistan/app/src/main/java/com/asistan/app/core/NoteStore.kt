package com.asistan.app.core

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class Note(val id: Int, val text: String, val created: Long)

/** Sesle alınan notlar ("Not al: ..."). Telefonda saklanır. */
object NoteStore {

    val items = MutableStateFlow<List<Note>>(emptyList())
    private var loaded = false

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("asistan_notes", Context.MODE_PRIVATE)

    @Synchronized
    fun load(ctx: Context): List<Note> {
        if (!loaded) {
            val arr = JSONArray(prefs(ctx).getString("items", "[]") ?: "[]")
            items.value = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Note(o.getInt("id"), o.getString("text"), o.optLong("created"))
            }
            loaded = true
        }
        return items.value
    }

    @Synchronized
    fun add(ctx: Context, text: String): Note {
        val list = load(ctx)
        val n = Note((list.maxOfOrNull { it.id } ?: 0) + 1, text.trim(), System.currentTimeMillis())
        save(ctx, (list + n).takeLast(200))
        return n
    }

    @Synchronized
    fun remove(ctx: Context, id: Int): Boolean {
        val list = load(ctx)
        if (list.none { it.id == id }) return false
        save(ctx, list.filterNot { it.id == id })
        return true
    }

    private fun save(ctx: Context, list: List<Note>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("created", it.created)) }
        prefs(ctx).edit().putString("items", arr.toString()).apply()
        items.value = list
    }
}
