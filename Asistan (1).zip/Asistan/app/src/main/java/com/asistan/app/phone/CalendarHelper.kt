package com.asistan.app.phone

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import java.util.TimeZone

data class CalEvent(
    val title: String,
    val begin: Long,
    val end: Long,
    val allDay: Boolean,
    val location: String?
)

/** Telefonun takvimini (Google Takvim vb.) okuma ve etkinlik ekleme. */
object CalendarHelper {

    fun events(ctx: Context, from: Long, to: Long, max: Int = 25): List<CalEvent> {
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
            ContentUris.appendId(it, from)
            ContentUris.appendId(it, to)
        }.build()
        val result = mutableListOf<CalEvent>()
        ctx.contentResolver.query(
            uri,
            arrayOf(
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END,
                CalendarContract.Instances.ALL_DAY,
                CalendarContract.Instances.EVENT_LOCATION
            ),
            null, null, "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { c ->
            while (c.moveToNext() && result.size < max) {
                result.add(
                    CalEvent(
                        title = c.getString(0) ?: "(başlıksız)",
                        begin = c.getLong(1),
                        end = c.getLong(2),
                        allDay = c.getInt(3) == 1,
                        location = c.getString(4)?.takeIf { it.isNotBlank() }
                    )
                )
            }
        }
        return result
    }

    /** Yazılabilir bir takvim seçer (önce birincil olanı). */
    private fun writableCalendarId(ctx: Context): Long? {
        var best: Long? = null
        var bestScore = -1
        ctx.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(
                CalendarContract.Calendars._ID,
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
                CalendarContract.Calendars.VISIBLE,
                CalendarContract.Calendars.IS_PRIMARY,
                CalendarContract.Calendars.ACCOUNT_TYPE
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val access = c.getInt(1)
                if (access < CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) continue
                var score = 0
                if (c.getInt(2) == 1) score += 1
                if (c.getInt(3) == 1) score += 4
                if (c.getString(4) == "com.google") score += 2
                if (score > bestScore) {
                    bestScore = score
                    best = c.getLong(0)
                }
            }
        }
        return best
    }

    /** @return eklenen etkinliğin kimliği veya yazılabilir takvim yoksa null */
    fun addEvent(ctx: Context, title: String, start: Long, end: Long, location: String?): Long? {
        val calId = writableCalendarId(ctx) ?: return null
        val values = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, calId)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DTSTART, start)
            put(CalendarContract.Events.DTEND, end)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            if (!location.isNullOrBlank()) put(CalendarContract.Events.EVENT_LOCATION, location)
            put(CalendarContract.Events.HAS_ALARM, 1)
        }
        val uri = ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values) ?: return null
        val eventId = ContentUris.parseId(uri)
        // 15 dakika önce bildirim
        try {
            ctx.contentResolver.insert(
                CalendarContract.Reminders.CONTENT_URI,
                ContentValues().apply {
                    put(CalendarContract.Reminders.EVENT_ID, eventId)
                    put(CalendarContract.Reminders.MINUTES, 15)
                    put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                }
            )
        } catch (_: Exception) {
        }
        return eventId
    }
}
