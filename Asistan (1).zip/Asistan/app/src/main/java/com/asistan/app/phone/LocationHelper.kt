package com.asistan.app.phone

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Telefonun konumunu bulur ve adrese çevirir. Arka plan iş parçacığında çağırın (bloklar). */
object LocationHelper {

    @SuppressLint("MissingPermission")
    fun current(ctx: Context, timeoutSec: Long = 12): Location? {
        val lm = ctx.getSystemService(LocationManager::class.java)
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        val last = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 2 * 60_000) return last
        if (providers.isEmpty()) return last

        // Ağ konumu daha hızlıdır; yoksa GPS
        val provider = if (LocationManager.NETWORK_PROVIDER in providers) LocationManager.NETWORK_PROVIDER
        else LocationManager.GPS_PROVIDER
        val latch = CountDownLatch(1)
        var result: Location? = null

        if (Build.VERSION.SDK_INT >= 30) {
            lm.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(ctx)) { loc ->
                result = loc
                latch.countDown()
            }
        } else {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    result = location
                    latch.countDown()
                }

                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            @Suppress("DEPRECATION")
            lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
        }
        latch.await(timeoutSec, TimeUnit.SECONDS)
        return result ?: last
    }

    /** "Atatürk Cd. No:5, Osmangazi/Bursa" gibi okunabilir adres. İnternet gerekebilir. */
    fun address(ctx: Context, loc: Location): String? = try {
        @Suppress("DEPRECATION")
        val list = Geocoder(ctx, TURKISH).getFromLocation(loc.latitude, loc.longitude, 1)
        list?.firstOrNull()?.getAddressLine(0)
    } catch (e: Exception) {
        null
    }

    fun mapsLink(loc: Location) =
        "https://maps.google.com/?q=%.6f,%.6f".format(java.util.Locale.US, loc.latitude, loc.longitude)
}
