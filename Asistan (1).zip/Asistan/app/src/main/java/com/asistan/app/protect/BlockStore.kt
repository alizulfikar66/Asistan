package com.asistan.app.protect

import android.content.Context
import com.asistan.app.phone.TextUtil
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class BlockedNumber(val number: String, val label: String, val added: Long)

/** Kullanıcının engellediği numaralar. Arama filtreleme açıksa bu numaralar hiç çaldırmaz. */
object BlockStore {

    val items = MutableStateFlow<List<BlockedNumber>>(emptyList())
    private var loaded = false

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("asistan_blocked", Context.MODE_PRIVATE)

    private fun key(n: String) = TextUtil.digits(n).takeLast(10)

    @Synchronized
    fun load(ctx: Context): List<BlockedNumber> {
        if (!loaded) {
            val arr = JSONArray(prefs(ctx).getString("items", "[]") ?: "[]")
            items.value = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                BlockedNumber(o.getString("number"), o.optString("label"), o.optLong("added"))
            }
            loaded = true
        }
        return items.value
    }

    fun contains(ctx: Context, number: String?): Boolean {
        if (number.isNullOrBlank()) return false
        val k = key(number)
        if (k.length < 3) return false
        return load(ctx).any { key(it.number) == k }
    }

    @Synchronized
    fun add(ctx: Context, number: String, label: String = ""): Boolean {
        val n = NumberRisk.normalize(number) ?: return false
        if (contains(ctx, n)) return true
        save(ctx, load(ctx) + BlockedNumber(n, label, System.currentTimeMillis()))
        return true
    }

    @Synchronized
    fun remove(ctx: Context, number: String): Boolean {
        val k = key(number)
        val list = load(ctx)
        if (list.none { key(it.number) == k }) return false
        save(ctx, list.filterNot { key(it.number) == k })
        return true
    }

    private fun save(ctx: Context, list: List<BlockedNumber>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("number", it.number).put("label", it.label).put("added", it.added)) }
        prefs(ctx).edit().putString("items", arr.toString()).apply()
        items.value = list
    }
}

/** Arama filtreleme servisinin gördüğü son gelen arama (numara, duyuruda kullanılır). */
object LastScreenedCall {
    @Volatile var number: String? = null
    @Volatile var time: Long = 0
    @Volatile var risk: RiskInfo? = null

    fun recent(): Boolean = System.currentTimeMillis() - time < 60_000
}
