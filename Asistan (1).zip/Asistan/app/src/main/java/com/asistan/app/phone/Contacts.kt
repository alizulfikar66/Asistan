package com.asistan.app.phone

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract

data class Contact(val name: String, val number: String, val label: String)

/** Rehberde kişi arama. Türkçe ekleri ("Ahmet'i", "annemi") tolere eder. */
object Contacts {

    private val suffixes = listOf("nin", "nun", "yi", "yu", "ye", "ya", "i", "u", "e", "a", "m")

    fun all(ctx: Context): List<Contact> {
        val result = mutableListOf<Contact>()
        val seen = HashSet<String>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE,
            ContactsContract.CommonDataKinds.Phone.LABEL
        )
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val type = c.getInt(2)
                val customLabel = c.getString(3)
                val label = ContactsContract.CommonDataKinds.Phone
                    .getTypeLabel(ctx.resources, type, customLabel).toString()
                val key = name + "|" + TextUtil.digits(number).takeLast(10)
                if (seen.add(key)) result.add(Contact(name, number, label))
            }
        }
        return result
    }

    fun search(ctx: Context, query: String): List<Contact> {
        val contacts = all(ctx)
        val base = TextUtil.normalize(query.substringBefore('\''))
        if (base.isEmpty()) return emptyList()

        // Önce olduğu gibi ara, bulamazsa Türkçe ekleri atarak tekrar dene.
        val variants = mutableListOf(base)
        for (s in suffixes) {
            if (base.endsWith(s) && base.length - s.length >= 3) variants.add(base.dropLast(s.length))
        }
        for (v in variants) {
            val found = contacts
                .map { it to score(TextUtil.normalize(it.name), v) }
                .filter { it.second > 0 }
                .sortedByDescending { it.second }
            if (found.isNotEmpty()) {
                val best = found.first().second
                return found.filter { it.second >= best - 10 }.map { it.first }.take(8)
            }
        }
        return emptyList()
    }

    private fun score(name: String, q: String): Int = when {
        name == q -> 100
        name.startsWith("$q ") || name.startsWith(q) -> 80
        name.split(" ").any { it == q } -> 75
        name.split(" ").any { it.startsWith(q) } -> 65
        name.contains(q) -> 50
        q.length >= 3 && name.length >= 3 && q.contains(name) -> 40
        else -> 0
    }

    fun nameForNumber(ctx: Context, number: String): String? {
        if (number.isBlank()) return null
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            ctx.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }
}
