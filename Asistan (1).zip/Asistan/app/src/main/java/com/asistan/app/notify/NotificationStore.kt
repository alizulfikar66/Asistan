package com.asistan.app.notify

import android.app.Notification
import kotlinx.coroutines.flow.MutableSharedFlow

/** WhatsApp, Telegram vb. uygulamalardan gelen mesaj bildirimi. */
data class AppMessage(
    val id: Int,
    val packageName: String,
    val appName: String,
    val sender: String,
    val conversation: String?,   // Grup adı (varsa)
    val text: String,
    val time: Long,
    val replyAction: Notification.Action?
)

/** Son gelen mesaj bildirimlerini bellekte tutar (en fazla 60 adet). */
object NotificationStore {

    private val items = ArrayList<AppMessage>()
    private val seen = LinkedHashSet<String>()
    private var nextId = 1

    @Volatile
    var listenerConnected = false

    /** Yeni mesaj geldiğinde yayınlanır (sesli duyuru için). */
    val incoming = MutableSharedFlow<AppMessage>(extraBufferCapacity = 16)

    @Synchronized
    fun add(
        pkg: String, app: String, sender: String, conversation: String?,
        text: String, time: Long, action: Notification.Action?
    ): AppMessage? {
        val key = "$pkg|$sender|$text|${time / 1000}"
        if (!seen.add(key)) return null
        if (seen.size > 500) seen.remove(seen.first())

        // Aynı sohbetin yeni bildirimi gelince eski mesajların cevap aksiyonunu da güncelle.
        if (action != null) {
            for (i in items.indices) {
                val m = items[i]
                if (m.packageName == pkg && m.sender == sender && m.conversation == conversation) {
                    items[i] = m.copy(replyAction = action)
                }
            }
        }
        val msg = AppMessage(nextId++, pkg, app, sender, conversation, text, time, action)
        items.add(msg)
        while (items.size > 60) items.removeAt(0)
        return msg
    }

    @Synchronized
    fun recent(app: String?, count: Int): List<AppMessage> {
        val q = app?.lowercase()?.trim().orEmpty()
        return items
            .filter { q.isEmpty() || it.appName.lowercase().contains(q) || it.packageName.contains(q) }
            .sortedByDescending { it.time }
            .take(count)
    }

    @Synchronized
    fun get(id: Int): AppMessage? = items.firstOrNull { it.id == id }
}
