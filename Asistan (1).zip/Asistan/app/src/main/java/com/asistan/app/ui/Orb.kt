package com.asistan.app.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import com.asistan.app.core.Status

/** Siri benzeri, duruma göre renk ve hareket değiştiren küre. */
@Composable
fun Orb(status: Status, level: Float, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "orb")
    val pulse by inf.animateFloat(
        initialValue = 0.94f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val fastPulse by inf.animateFloat(
        initialValue = 0.96f, targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(420, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "fast"
    )
    val rotation by inf.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(
            tween(if (status == Status.THINKING) 1400 else 6000, easing = LinearEasing)
        ),
        label = "rot"
    )
    val lvl by animateFloatAsState(level, label = "level")

    val colors: List<Color> = when (status) {
        Status.IDLE -> listOf(Palette.violet, Palette.pink, Palette.violet, Palette.cyan)
        Status.WAKE_LISTENING -> listOf(Palette.teal, Palette.violet, Palette.cyan, Palette.teal)
        Status.LISTENING -> listOf(Palette.cyan, Palette.teal, Palette.violet, Palette.cyan)
        Status.THINKING -> listOf(Palette.pink, Palette.violet, Palette.cyan, Palette.pink)
        Status.SPEAKING -> listOf(Palette.orange, Palette.pink, Palette.violet, Palette.orange)
    }
    val scale = when (status) {
        Status.LISTENING -> 0.95f + lvl * 0.3f
        Status.SPEAKING -> fastPulse
        Status.THINKING -> 1f
        else -> pulse
    }

    Canvas(modifier) {
        val r = size.minDimension / 2f * 0.62f * scale
        // Dış parıltı
        drawCircle(
            brush = Brush.radialGradient(
                listOf(colors[0].copy(alpha = 0.45f), colors[1].copy(alpha = 0.12f), Color.Transparent),
                center = center, radius = r * 1.6f
            ),
            radius = r * 1.6f, center = center
        )
        // Dönen renkli gövde
        rotate(rotation, center) {
            drawCircle(brush = Brush.sweepGradient(colors + colors.first(), center), radius = r, center = center)
        }
        // Yumuşak iç gölge
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color.Transparent, Color.Black.copy(alpha = 0.25f)),
                center = center, radius = r
            ),
            radius = r, center = center
        )
        // Parlama
        val hl = center + Offset(-r * 0.32f, -r * 0.36f)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.55f), Color.Transparent),
                center = hl, radius = r * 0.55f
            ),
            radius = r * 0.55f, center = hl
        )
    }
}
