package com.asistan.app.protect

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CallLog
import androidx.core.content.ContextCompat
import com.asistan.app.phone.Contacts
import com.asistan.app.phone.TextUtil

/**
 * Bilinmeyen bir numaranın ne kadar şüpheli olduğunu tahmin eder.
 * level: 0 = normal, 1 = dikkat, 2 = şüpheli, 3 = yüksek risk
 */
data class RiskInfo(
    val level: Int,
    val category: String,      // "0850 kurumsal hat", "yurt dışı" ...
    val advice: String,        // Kullanıcıya söylenecek kısa açıklama
    val number: String?,       // Okunabilir biçimde numara
    val contactName: String? = null,
    val previousCalls: Int = 0
)

object NumberRisk {

    // Yurt dışı "cevapsız arama" (wangiri) dolandırıcılığında sık görülen ülke kodları
    private val highRiskCountryCodes = listOf(
        "225", "243", "222", "223", "224", "226", "227", "228", "229", "231", "232", "233", "234",
        "236", "237", "238", "239", "240", "241", "242", "244", "245", "248", "250", "251", "252",
        "253", "254", "255", "256", "257", "261", "262", "263", "264", "265", "266", "267", "268",
        "269", "371", "372", "375", "381", "382", "383", "387", "673", "675", "676", "677", "678",
        "679", "682", "685", "686", "688", "690", "691", "692", "870", "881", "882", "883"
    )

    private val cityCodes = mapOf(
        "212" to "İstanbul Avrupa", "216" to "İstanbul Anadolu", "312" to "Ankara", "232" to "İzmir",
        "224" to "Bursa", "242" to "Antalya", "322" to "Adana", "332" to "Konya", "342" to "Gaziantep",
        "262" to "Kocaeli", "222" to "Eskişehir", "352" to "Kayseri", "362" to "Samsun",
        "462" to "Trabzon", "412" to "Diyarbakır", "258" to "Denizli", "264" to "Sakarya",
        "266" to "Balıkesir", "236" to "Manisa", "324" to "Mersin", "422" to "Malatya", "442" to "Erzurum"
    )

    /** Türk numaralarını "0XXX XXX XX XX" biçimine getirir; diğerlerini "+.." olarak bırakır. */
    fun normalize(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val trimmed = raw.trim()
        var d = TextUtil.digits(trimmed)
        if (d.isEmpty()) return null
        if (trimmed.startsWith("+")) {
            if (d.startsWith("90") && d.length == 12) return "0" + d.drop(2)
            return "+$d"
        }
        if (d.startsWith("00")) {
            d = d.drop(2)
            if (d.startsWith("90") && d.length == 12) return "0" + d.drop(2)
            return "+$d"
        }
        if (d.startsWith("90") && d.length == 12) return "0" + d.drop(2)
        if (d.length == 10 && !d.startsWith("0")) return "0$d"
        return d
    }

    /** Sesli okumaya uygun: "0850 123 45 67" */
    fun spoken(n: String): String =
        if (n.length == 11 && n.startsWith("0")) "${n.substring(0, 4)} ${n.substring(4, 7)} ${n.substring(7, 9)} ${n.substring(9)}"
        else n

    fun assess(ctx: Context, raw: String?): RiskInfo {
        val n = normalize(raw)
            ?: return RiskInfo(2, "gizli numara", "Numarasını gizleyerek arıyor. Tanımadığın gizli numaralara dikkat et.", null)

        // Rehberde kayıtlıysa güvenli
        val name = if (has(ctx, Manifest.permission.READ_CONTACTS)) Contacts.nameForNumber(ctx, raw ?: n) else null
        if (name != null) return RiskInfo(0, "rehberde kayıtlı", "", spoken(n), contactName = name)

        val prev = previousCalls(ctx, n)
        val blocked = BlockStore.contains(ctx, n)
        if (blocked) return RiskInfo(3, "engellediğin numara", "Bu numarayı daha önce engellemiştin.", spoken(n), previousCalls = prev.total)

        val base: RiskInfo = when {
            n.startsWith("+") -> {
                val cc = n.drop(1)
                if (highRiskCountryCodes.any { cc.startsWith(it) })
                    RiskInfo(3, "riskli yurt dışı numarası",
                        "Yurt dışından, dolandırıcılıkta sık kullanılan bir ülke kodundan arıyor. Açma ve geri arama; geri aramak çok pahalıya patlayabilir.", n)
                else RiskInfo(2, "yurt dışı numarası",
                    "Yurt dışı numarası. Tanımadığın yurt dışı aramalarına geri dönme.", n)
            }
            n.startsWith("0900") -> RiskInfo(3, "0900 ücretli hat",
                "0900 yüksek ücretli bir hat. Kesinlikle geri arama.", spoken(n))
            n.startsWith("0888") -> RiskInfo(2, "0888 özel ücretli hat",
                "0888 ücretli özel hizmet hattı, dikkatli ol.", spoken(n))
            n.startsWith("0850") -> RiskInfo(1, "0850 kurumsal hat",
                "0850 kurumsal hat: bankalar ve şirketler kullanır ama reklam ve dolandırıcılık aramaları da çok gelir.", spoken(n))
            n.startsWith("444") && n.length == 7 -> RiskInfo(1, "444 kurumsal hat",
                "444'lü kurumsal numara; genelde şirketler ve çağrı merkezleri.", spoken(n))
            n.length == 11 && (n.startsWith("0212") || n.startsWith("0216")) -> RiskInfo(1,
                "${cityCodes[n.substring(1, 4)]} sabit hattı",
                "İstanbul sabit hattı: çağrı merkezleri ve telefon dolandırıcıları bu hatları sık kullanır. Normal bir arama da olabilir.",
                spoken(n))
            n.length == 11 && n.startsWith("05") -> RiskInfo(0, "cep telefonu", "", spoken(n))
            n.length == 11 && n.startsWith("0") && cityCodes.containsKey(n.substring(1, 4)) ->
                RiskInfo(0, "${cityCodes[n.substring(1, 4)]} sabit hattı", "", spoken(n))
            n.length < 7 -> RiskInfo(1, "kısa numara", "Kısa bir numara; genelde kurumsal veya servis numarası.", n)
            else -> RiskInfo(1, "bilinmeyen numara", "", spoken(n))
        }
        // Daha önce de aradıysa ve hiç konuşulmadıysa riski biraz artır
        if (prev.answered == 0 && prev.total >= 3 && base.level < 3) {
            return base.copy(
                level = base.level + 1,
                advice = (base.advice + " Bu numara daha önce ${prev.total} kez aramış ama hiç konuşmamışsın.").trim(),
                previousCalls = prev.total
            )
        }
        return base.copy(previousCalls = prev.total)
    }

    private data class Prev(val total: Int, val answered: Int)

    private fun previousCalls(ctx: Context, n: String): Prev {
        if (!has(ctx, Manifest.permission.READ_CALL_LOG)) return Prev(0, 0)
        val tail = TextUtil.digits(n).takeLast(10)
        var total = 0
        var answered = 0
        try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DURATION),
                null, null, "${CallLog.Calls.DATE} DESC"
            )?.use { c ->
                var scanned = 0
                while (c.moveToNext() && scanned++ < 300) {
                    if (TextUtil.digits(c.getString(0) ?: "").takeLast(10) != tail) continue
                    total++
                    if (c.getLong(2) > 0) answered++
                }
            }
        } catch (_: Exception) {
        }
        return Prev(total, answered)
    }

    private fun has(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    /** Gelen aramada söylenecek cümle. */
    fun announcement(r: RiskInfo): String {
        if (r.contactName != null) return "${r.contactName} arıyor."
        if (r.number == null) return "Gizli numara arıyor. ${r.advice}"
        val head = "Kayıtlı olmayan bir numara arıyor: ${r.number}, ${r.category}."
        val warn = when (r.level) {
            3 -> " Dikkat, yüksek risk! ${r.advice}"
            2 -> " Şüpheli olabilir. ${r.advice}"
            1 -> if (r.advice.isNotBlank()) " ${r.advice}" else ""
            else -> ""
        }
        return head + warn
    }
}
