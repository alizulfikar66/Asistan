package com.asistan.app.protect

import android.app.NotificationManager
import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import androidx.core.app.NotificationCompat
import com.asistan.app.AsistanApp
import com.asistan.app.R
import com.asistan.app.core.AppSettings

/**
 * Android'in resmi arama filtreleme servisi. Rehberde olmayan numaralar telefon
 * çalmadan önce buraya gelir: engellenenler reddedilir, riskliler sessize alınabilir.
 * Kullanıcının Ayarlar'dan Asistan'ı "arama filtreleme uygulaması" yapması gerekir.
 */
class SpamScreeningService : CallScreeningService() {

    override fun onScreenCall(details: Call.Details) {
        val incoming = Build.VERSION.SDK_INT < 29 ||
                details.callDirection == Call.Details.DIRECTION_INCOMING
        if (!incoming) {
            respondToCall(details, CallResponse.Builder().build())
            return
        }

        val number = details.handle?.schemeSpecificPart
        val risk = try {
            NumberRisk.assess(this, number)
        } catch (e: Exception) {
            RiskInfo(0, "bilinmiyor", "", number)
        }
        LastScreenedCall.number = number
        LastScreenedCall.risk = risk
        LastScreenedCall.time = System.currentTimeMillis()

        val s = AppSettings(this)
        val blocked = BlockStore.contains(this, number)
        val reject = blocked || (s.autoRejectHighRisk && risk.level >= 3)

        val resp = CallResponse.Builder()
        if (reject) {
            resp.setDisallowCall(true)
                .setRejectCall(true)
                .setSkipCallLog(false)
                .setSkipNotification(true)
        } else if (s.silenceRisky && risk.level >= 2 && Build.VERSION.SDK_INT >= 29) {
            resp.setSilenceCall(true)
        }
        respondToCall(details, resp.build())

        if (reject) notifyBlocked(risk, blocked)
    }

    private fun notifyBlocked(risk: RiskInfo, wasBlocked: Boolean) {
        val why = if (wasBlocked) "engellediğin numara" else risk.category
        val n = NotificationCompat.Builder(this, AsistanApp.REMINDER_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("🛡️ Arama engellendi")
            .setContentText("${risk.number ?: "Gizli numara"} ($why)")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .build()
        try {
            getSystemService(NotificationManager::class.java)
                .notify((System.currentTimeMillis() % 100000).toInt() + 20000, n)
        } catch (_: SecurityException) {
        }
    }
}
